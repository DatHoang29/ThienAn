<template>
  <div class="right-panel" :class="{ 'collapsed': isPanelCollapsed }">
    <!-- Collapse Toggle Button -->
    <div class="collapse-toggle" @click="togglePanel">
      <el-icon>
        <component :is="isPanelCollapsed ? 'ele-ArrowLeft' : 'ele-ArrowRight'" />
      </el-icon>
    </div>

    <!-- Panel Content -->
    <div class="panel-content" v-show="!isPanelCollapsed">
      <!-- Add Item Header -->
      <div class="item-management">
        <el-form :model="state.ruleForm" ref="ruleFormRef" :show-message="false" :inlineMessage="true" :inline="true">
          <el-form-item :label="$t('lz.label.tmsMapLocation.itemGroup')" prop="itemGroup">
            <el-select v-model="state.queryParams.itemGroup" 
                 :placeholder="$t('lz.label.base.pleaseSelect', {input:'nhóm'})"
                  filterable 
                  clearable class="w100">
              <el-option v-for="item in state.itemGroup" :key="item.code" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>
          
          <!-- Type/Item -->
          <el-form-item prop="itemId">
            <el-cascader v-model="state.queryParams.itemId" :options="filteredItemData"
              :placeholder="$t('lz.label.base.pleaseSelect', {input:'dữ liệu'})" :props="{
                value: 'id',
                label: 'name',
                children: 'children',
                disabled: 'disabled',
                emitPath: false
              }" clearable class="w100">
              <template #default="{ node, data }">
                <span :class="{ 'text-disabled': data.disabled }">{{ data.name }}</span>
                <span v-if="data.children && data.children.length">
                  ({{ data.children.length }})
                </span>
                <span v-if="data.disabled" class="text-muted">
                  ({{ $t('lz.label.base.used')}})
                </span>
              </template>
            </el-cascader>
          </el-form-item>

          <!-- Button Save -->             
          <el-form-item>
             <el-button type="primary" @click="handleAddItem" v-if="state.queryParams.itemGroup !== 'zone'"
               :disabled="!state.queryParams.itemId">
                {{ $t('lz.button.tmsMapLocation.addToMap') }}
             </el-button>
             <el-button v-else @click="handleStartDrawingPolygon"> {{ $t('lz.button.tmsMapLocation.drawPolygon') }} </el-button>
             <el-button type="primary" @click="handleSave">
              {{ $t('lz.button.base.save') }}
             </el-button>
         </el-form-item>   
         
        </el-form>
      </div>


      <el-tabs v-model="activeTab">        
        <!-- Table Tab -->
        <el-tab-pane :label="$t('lz.label.tms.location')" name="table">
          <div class="table-container">
            <div class="card-header">
              <span></span>
              <div class="search-controls">
                <el-input v-model="tableSearch" :placeholder="$t('lz.label.tmsMapLocation.searchByNameOrType')" clearable
                  @clear="handleSearchClear">
                  <template #prefix>
                    <el-icon>
                      <Search />
                    </el-icon>
                  </template>
                </el-input>
              </div>
            </div>

            <el-tabs v-model="activeName" class="demo-tabs"  @tab-click="handleClickTabAccordion">
              <div v-for="(value, index) in state.listEquipmentType">
                <el-tab-pane v-bind:label="value.name" v-bind:name="value.code">
                  <!-- state.listDataTable-->
                  <div v-for="element in filteredTableData"  :key="element.equipmentType">   
                      <el-card style="max-width: 100%; margin-bottom: 10px;">
                          <div class="card-header accordion " @click="handleHeaderAccordionClick">
                                <span>{{ element.equipmentType }}</span>
                          </div>
                          <div v-for="value in element.listFilter"  :key="value.id">
                            <el-row  :class="['mb5', 'panel-accordion', `filter_${element.equipmentType}`]" :data-equipmentType="element.equipmentType">
                              <el-col :xs="6" :sm="6" :md="6" :lg="6" :xl="6">
                                <span>{{ value.name }}</span>
                              </el-col>
                              <el-col :xs="10" :sm="10" :md="10" :lg="10" :xl="10">
                                <template v-if="value.geometryType === 'Point'">                      
                                    <el-input-number v-model="value.lat" :min="0"
                                     :precision="6" :step="0.0001" size="small"
                                      placeholder="$t('lz.label.tmsMapLocation.latitude')" @change="(val: any) => handleLocationUpdate(value, val, 'lat')" />
                                    <el-input-number v-model="value.lng" :min="0"
                                      :precision="6" :step="0.0001" size="small"
                                      placeholder="$t('lz.label.tmsMapLocation.longitude')" @change="(val: any) => handleLocationUpdate(value, val, 'lng')" />
                                  </template>

                                <!-- For Polygon features -->
                                <template v-else-if="value.geometryType === 'Polygon'">
                                  <div class="location-controls">
                                    <el-input-number :model-value="value.topLeft.lat" :min="0"
                                       :precision="6" :step="0.0001" size="small"
                                      placeholder="$t('lz.label.tmsMapLocation.latitude')" @change="(val: any) => handlePolygonUpdate(value, val, 'lat')" />
                                    <el-input-number :model-value="value.topLeft.lng" :min="0"
                                      :precision="6" :step="0.0001" size="small"
                                    placeholder="$t('lz.label.tmsMapLocation.longitude')" @change="(val: any) => handlePolygonUpdate(value, val, 'lng')" />
                                  </div>
                                </template>          
                              </el-col>
                              <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                                <div class="action-buttons">
                                    <el-tooltip :content="$t('lz.button.tmsMapLocation.locateOnMap')">
                                      <el-button size="small" type="primary" @click="handleLocateOnMap(value)" :icon="Search" />
                                    </el-tooltip>
                                    <template v-if="value.geometryType === 'Polygon'">
                                      <el-tooltip :content="$t('lz.button.base.edit')">
                                        <el-button size="small" type="warning" @click="handleEditOnMap(value)" :icon="Edit" />
                                      </el-tooltip>
                                    </template>
                                    <el-tooltip :content="$t('lz.button.tmsMapLocation.moveOnMap')">
                                      <el-button size="small" type="info" @click="handleMoveOnMap(value)" :icon="Position" />
                                    </el-tooltip>
                                    <el-tooltip :content="$t('lz.button.base.delete')">
                                      <el-button size="small" type="danger" @click="handleDelete(value)" :icon="Delete" />
                                    </el-tooltip>
                                </div>       
                              </el-col>
                            </el-row>                  
                          </div>  
                    </el-card>
                  </div>
                  
                </el-tab-pane>
              </div>                  
            </el-tabs>   
          </div>
        </el-tab-pane>

    <!-- Config Tab -->
    <el-tab-pane :label="$t('lz.label.tms.config')" name="configMap">
          <div class="geojson-container">
            <div>
           
                <!-- Latitude and Longitude -->
                <el-card style="max-width: 100%; margin-bottom: 10px;">
                    <div class="card-header accordion ">
                          <span>{{ $t('lz.label.tmsMapLocation.editLocation') }}</span>
                    </div>
                    <div>
                      <!-- input latitude -->
                      <el-row :style="{marginTop:'15px', padding: '10px'}">  
                          <el-col :span="20">
                            <div>
                              <el-row style="align-items: center; justify-content: space-between;">
                                <el-col  :xs="5" :sm="5" :md="5" :lg="5" :xl="5" >
                                  <p>{{ $t('lz.label.tmsMapLocation.latitude') }}</p>
                                </el-col>                             
                                <el-col  :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
                                  <el-input-number class="w-100" v-model="state.defaultValue.latitude" 
                                  :controls="false" :precision="6" :min="0" readonly  />
                                </el-col>   
                                <el-col  :xs="4" :sm="4" :md="4" :lg="4" :xl="4" >
                                  <p>{{ $t('lz.label.tmsMapLocation.adjust') }}</p>
                                </el-col>                                                  
                                <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                                  <el-input-number v-model="state.queryParams.latitude" class="w-100" 
                                    :precision="6" :step="0.0001" :min="0" size="small"
                                  placeholder="$t('lz.label.tmsMapLocation.longitude')" @change="(val:any) => handleLocationConfigUpdate(val, 'latitude')"/>
                                </el-col>                    
                              </el-row>                 
                            </div>
                          </el-col>              
                        
                          <el-col :span="4">
                            <el-button size="small" type="primary"  @click="(event:MouseEvent) => handleSetConfig(event, 'latitude')">{{ $t('lz.button.tmsMapLocation.setConfig') }}</el-button>
                          </el-col>            
                     </el-row>
                     
                      <!-- input longtitude -->
                      <el-row :style="{marginTop:'15px', padding: '10px'}">  
                          <el-col :span="20">
                            <div>
                              <el-row style="align-items: center; justify-content: space-between;">
                                <el-col  :xs="5" :sm="5" :md="5" :lg="5" :xl="5" >
                                  <p>{{ $t('lz.label.tmsMapLocation.longitude') }}</p>
                                </el-col>                             
                                <el-col  :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
                                  <el-input-number class="w-100" v-model="state.defaultValue.longtitude" :min="0"
                                    :controls="false" :precision="6" readonly  />
                                </el-col>     
                                <el-col  :xs="4" :sm="4" :md="4" :lg="4" :xl="4" >
                                  <p>{{ $t('lz.label.tmsMapLocation.adjust') }}</p>
                                </el-col>                                                  
                                <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                                  <el-input-number v-model="state.queryParams.longtitude" class="w-100" 
                                  :precision="6" :step="0.0001" :min="0" size="small"
                                  placeholder="$t('lz.label.tmsMapLocation.longitude')" @change="(val:any) => handleLocationConfigUpdate(val, 'longtitude')"/>
                                </el-col>                    
                              </el-row>                 
                            </div>
                          </el-col>              
                        
                          <el-col :span="4">
                            <el-button size="small" type="primary"  @click="(event:MouseEvent) => handleSetConfig(event, 'longtitude')">{{ $t('lz.button.tmsMapLocation.setConfig') }}</el-button>
                          </el-col>            
                     </el-row>
                      <!--================-->                                 
                    </div>                    
                </el-card>    

              <!-- Max Zoom and Min Zoom -->
              <el-card style="max-width: 100%; margin-bottom: 10px;">
                    <div class="card-header accordion ">
                          <span>{{ $t('lz.label.tmsMapLocation.editMaxAndMinZoom') }}</span>
                    </div>
                    <div>
                        <!-- input  Max Zoom -->
                        <el-row :style="{marginTop:'15px', padding: '10px'}">  
                          <el-col :span="20">
                            <div>
                              <el-row style="align-items: center; justify-content: space-between;">
                                <el-col  :xs="5" :sm="5" :md="5" :lg="5" :xl="5" >
                                  <p>{{ $t('lz.label.tmsMapLocation.maxZoom') }}</p>
                                </el-col>                             
                                <el-col  :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
                                  <el-input-number class="w-100" v-model="state.defaultValue.maxZoom" 
                                  :controls="false" :precision="1" :min="0" readonly  />
                                </el-col>   
                                <el-col  :xs="4" :sm="4" :md="4" :lg="4" :xl="4" >
                                  <p>{{ $t('lz.label.tmsMapLocation.adjust') }}</p>
                                </el-col>                                                  
                                <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                                  <el-input-number v-model="state.queryParams.maxZoom" class="w-100"  
                                    :precision="1" :step="0.5" :min="0" size="small"
                                    placeholder="$t('lz.label.tmsMapLocation.maxZoom')" @change="(val:any) => handleLocationConfigUpdate(val, 'maxZoom')"/>
                                </el-col>                    
                              </el-row>                 
                            </div>
                          </el-col>  
                          <el-col :span="4">
                            <el-button size="small" type="primary"  @click="(event:MouseEvent) => handleSetConfig(event, 'maxZoom')">{{ $t('lz.button.tmsMapLocation.setConfig') }}</el-button>
                          </el-col>            
                     </el-row>
                    <!--================-->   

                      <!-- input  Min Zoom -->
                      <el-row :style="{marginTop:'15px', padding: '10px'}">  
                          <el-col :span="20">
                            <div>
                              <el-row style="align-items: center; justify-content: space-between;">
                                <el-col  :xs="5" :sm="5" :md="5" :lg="5" :xl="5" >
                                  <p>{{ $t('lz.label.tmsMapLocation.minZoom') }}</p>
                                </el-col>                             
                                <el-col  :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
                                  <el-input-number class="w-100"  v-model="state.defaultValue.minZoom" 
                                  :controls="false" :precision="1" :min="0" readonly  />
                                </el-col>   
                                <el-col  :xs="4" :sm="4" :md="4" :lg="4" :xl="4" >
                                  <p>{{ $t('lz.label.tmsMapLocation.adjust') }}</p>
                                </el-col>                                                  
                                <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                                  <el-input-number v-model="state.queryParams.minZoom" class="w-100" 
                                    :precision="1" :step="0.5" size="small" :min="0"
                                    placeholder="$t('lz.label.tmsMapLocation.minZoom')" @change="(val:any) => handleLocationConfigUpdate(val, 'minZoom')"/>
                                </el-col>                    
                              </el-row>                 
                            </div>
                          </el-col>  
                          <el-col :span="4">
                            <el-button size="small" type="primary"  @click="(event:MouseEvent) => handleSetConfig(event, 'minZoom')">{{ $t('lz.button.tmsMapLocation.setConfig') }}</el-button>
                          </el-col>            
                     </el-row>
                    <!--================-->   
          
                    </div>                  
                    <div>                    
                    </div>  
                </el-card>


                <el-card style="max-width: 100%; margin-bottom: 10px;">
                    <div class="card-header accordion ">
                       <span> {{ $t('lz.label.tmsMapLocation.editDefaultZoom') }}</span>
                    </div>
                    <div>
                      <!-- Zoom Default -->
                      <el-row :style="{marginTop:'15px', padding: '10px'}">  
                          <el-col :span="20">
                            <div>
                              <el-row style="align-items: center; justify-content: space-between;">
                                <el-col  :xs="5" :sm="5" :md="5" :lg="5" :xl="5" >
                                  <p>{{ $t('lz.label.tmsMapLocation.defaultZoom') }}</p>
                                </el-col>                             
                                <el-col  :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
                                  <el-input-number class="w-100" v-model="state.defaultValue.defaultZoom" 
                                  :controls="false" :precision="1" :min="0" readonly  />
                                </el-col>   
                                <el-col  :xs="4" :sm="4" :md="4" :lg="4" :xl="4" >
                                  <p>{{ $t('lz.label.tmsMapLocation.adjust') }}</p>
                                </el-col>                                                  
                                <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="8">
                                  <el-input-number v-model="state.queryParams.defaultZoom" class="w-100"  
                                    :precision="1" :step="0.5" :min="0" size="small"
                                    placeholder="$t('lz.label.tmsMapLocation.defaultZoom')" @change="(val:any) => handleLocationConfigUpdate(val, 'defaultZoom')"/>
                                </el-col>                    
                              </el-row>                 
                            </div>
                          </el-col>  
                          <el-col :span="4">
                            <el-button size="small" type="primary"  @click="(event:MouseEvent) => handleSetConfig(event, 'defaultZoom')">{{ $t('lz.button.tmsMapLocation.setConfig') }}</el-button>
                          </el-col>            
                     </el-row>
                    <!--================-->   
                     
                    </div>
                </el-card>
          </div>
          </div>
        </el-tab-pane>

        <!-- GeoJSON Tab -->
        <el-tab-pane :label="$t('lz.label.tmsMapLocation.geoJson')" name="geojson">
          <div class="geojson-container">
            <pre class="geojson-content">{{ JSON.stringify(geoJsonData, null, 2) }}</pre>
          </div>
        </el-tab-pane>
       
      </el-tabs>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, reactive, onMounted, watch, PropType } from 'vue'
import { Search, Delete, Edit, Position } from '@element-plus/icons-vue'
import { getAPI } from '/@/utils/axios-utils'
import { SysConfigDataApi } from '/@/api-services/cfgSystem'
import { ElMessageBox, ElMessage, ElForm, TabsPaneContext } from 'element-plus'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import {
  TmsEquipmentApi,
  TmsZoneApi,
  TmsWorkUnitApi,
  TmsEquipmentTypeApi,
  TmsMapLocationApi
} from '/@/api-services/tms'
import { useThemeConfig } from '/@/stores/themeConfig'
import { useMapStore } from '/@/stores/mapStore'
import { UpdateTmsMapLocationInput } from '/@/api-services/tms';
import { useI18n } from 'vue-i18n'
import { watchDebounced } from '@vueuse/core'


// Import 2 thư viện này mới vẽ được polygon trên zone
import '@geoman-io/leaflet-geoman-free';
import '@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css';

// Import transform helper
import { transformWorkUnitData, transformZonesData, transformEquipmentData } from '../transformDataHelper'
import { lazyImg } from '/@/utils/other'
import { min } from 'xe-utils'
 


const themeConfig = useThemeConfig()
const mapStore = useMapStore()

// ===== Setup & State =====
const { t: $t } = useI18n();
const ruleFormRef = ref<InstanceType<typeof ElForm>>();

const props = defineProps({
  mapId: String,
  geoJsonData: {
    type: Object,
    required: true
  },
  markersLayer: L.layerGroup() as L.LayerGroup<L.Marker>,
  polygonsLayer: L.layerGroup() as L.LayerGroup<L.Polygon>,
  maxZoom: 0 as any | number,
  minZoom: 0 as any | number,
  latitude: 0 as any | number,
  longtitude: 0 as any | number,
  defaultZoom: 0 as any | number,
  previousGeoJsonFeature:{
    type: Array,
    require: true
  },
  previousFeatureGeoJsonDataZone:{
    type: Array,
    require: true
  },
  map: null as L.Map | null
})

const emit = defineEmits([
  //   'update-location',
  //   'update-polygon-location',
  'locate-on-map',
  'start-editing',
  'start-moving',
  'confirm-delete',
  'add-item',
  'render-map',
  'handle-save',
  'handle-start-drawing-polygon',
  'mark-unsaved'
])


const state = reactive({
queryParams: {
    itemGroup: undefined as string | undefined,
    itemId: undefined as string | undefined | null,
    mapId: undefined,
    maxZoom: 0 as number | undefined,
    minZoom: 0 as number | undefined,
    latitude: 0 as number | undefined,
    longtitude: 0 as number | undefined,
    defaultZoom: 0 as number | undefined
  },
  itemGroup: [] as any,
  itemList: [] as any,
  equipmentTypeList: [] as any,
  equipmentList: [] as any,
  zoneList: [] as any,
  zoneTypeList: [] as any,
  workUnitTypeList: [] as any,
  workUnitList: [] as any,
  unsavedChanges: new Set<string>(),
  tileLayer: null as L.TileLayer | null,
  imageOverlay: null as L.ImageOverlay | null,
  currentMode: null as 'edit' | 'move' | null,
  highlightLayer: null as L.Layer | null,
  activeFeatureId: null as string | null,
  editingLayer: null as any,
  originalCoordinates: null as any,
  currentCoordinates: null as any,
  markersLayer: props.markersLayer,
  polygonsLayer: props.polygonsLayer,
  ruleForm: {} as UpdateTmsMapLocationInput,
  activeTabItemGroup: '' as any,
  listEquipmentType: [] as any,
  //inputSearchDataTable: '' as string,
  listDataTable: [] as any,
  defaultValue: {
    latitude: 0,
    longtitude: 0,
    minZoom:0,
    maxZoom:0,
    defaultZoom:0
  }
  //listActiveTabItemGroup: [] as any
})

// assign ref to detect
const isPanelCollapsed = ref(false)
const activeTab = ref('table')
const activeName = ref('device')
const tableSearch = ref('')
const inputSearchDataTable = ref('')

// const ruleFormRef = ref<InstanceType<typeof ElForm>>();
watch(() => props.markersLayer, (newVal) => {
  state.markersLayer = newVal
})

watch(() => props.polygonsLayer, (newVal) => {
  state.polygonsLayer = newVal
})

watch(() => props.maxZoom, (newVal) => {
  state.queryParams.maxZoom = newVal as number
})

watch(() => props.minZoom, (newVal) => {
  state.queryParams.minZoom = newVal as number
})

watch(() => props.latitude, (newVal) => {  
  state.queryParams.latitude = newVal as number
})

watch(() => props.longtitude, (newVal) => {
  state.queryParams.longtitude = newVal as number
})

watch(() => props.defaultZoom, (newVal) => {
  state.queryParams.defaultZoom = newVal as number
})

watch(() =>  state.queryParams.defaultZoom, (newVal) => { 
  console.log("watch once - LOCATION EDIT")
  state.defaultValue.defaultZoom =  state.queryParams.defaultZoom as number
  state.defaultValue.minZoom =  state.queryParams.minZoom as number
  state.defaultValue.maxZoom =  state.queryParams.maxZoom as number 
  state.defaultValue.latitude =  state.queryParams.latitude as number
  state.defaultValue.longtitude = state.queryParams.longtitude as number
}, {once: true})


onMounted(async () => {
  console.log("Location Edit - onMounted", )
  await loadData();

  // Handle item group change
  handleItemGroupChange();

  // active tab device first
  state.activeTabItemGroup ='device' 

})

async function loadData() {
  // Fetch other data after map is loadeds
  await mapStore.fetchItemGroupList();
  state.itemGroup = mapStore.itemGroupList;

  // Get list code equiment type
  if(state.itemGroup && state.itemGroup.length > 0){
    state.listEquipmentType = state.itemGroup.filter((item: any) => {
      if(item.code && !Number(item.code)){
        return { 
          equipmentTypeName: item?.name,
          equipmentTypeCode: item?.code
        }
      }
    })
  }

  await mapStore.fetchEquipmentTypeList();
  state.equipmentTypeList = mapStore.equipmentTypeList;

  await mapStore.fetchZoneTypeList();
  state.zoneTypeList = mapStore.zoneTypeList;

  await mapStore.fetchWorkUnitTypeList();
  state.workUnitTypeList = mapStore.workUnitTypeList;
}

/**
 * handleSaveConfig
 */
const handleSetConfig = (event:MouseEvent,  field:'latitude'|'longtitude'|'maxZoom'|'minZoom'|'defaultZoom') => {
    switch(field){
      case 'latitude':
        state.defaultValue.latitude = state.queryParams.latitude as number
        return;
      case 'longtitude':
        state.defaultValue.longtitude = state.queryParams.longtitude as number
        return;
      case 'maxZoom':
        state.defaultValue.maxZoom = state.queryParams.maxZoom as number
        return;
      case 'minZoom':
        state.defaultValue.minZoom = state.queryParams.minZoom as number
        return;
      case 'defaultZoom':
        state.defaultValue.defaultZoom = state.queryParams.defaultZoom as number
        return;
    }
}

/**
 * handleHeaderAccordionClick
 */
const handleHeaderAccordionClick = (event:MouseEvent) => {
  // 1. Type Assertion (Casting)
  const target = event?.target as HTMLElement; 
  target.classList.toggle("active-accordion");

  // 2. Get the next sibling element
  const nextSibling = target.nextElementSibling as HTMLElement

  // 3.Get data-equipmentType
  let dataEquipmentType = nextSibling.getAttribute('data--equipmentType')
  if(dataEquipmentType == undefined)
  {
   // Get next sibling to find data-equipmentType
   const childWithAttribute = nextSibling.querySelector('[data-equipmentType]')
   if(childWithAttribute){
     dataEquipmentType = childWithAttribute.getAttribute('data-equipmentType')
   }
  }

  // 4. Get all panel accordion have class common
  const panelAccordionAll = document.querySelectorAll(`.filter_${dataEquipmentType}`)

  // 5. toggle dislay panel
  panelAccordionAll.forEach((el) => {
   el?.classList.toggle("d-none-accordion")
  })  
}

/**
 * Handle click tab
 */
 const handleClickTabAccordion = (tab: TabsPaneContext, event: Event) => {
  //console.log(tab, event)
  const props = {...tab.props}
  //console.log("props", props)
  state.activeTabItemGroup = props?.name
}

/**
 * Handle zoom
 */
const handleLocationConfigUpdate = (val:any, field:'maxZoom'| 'minZoom' | 'defaultZoom' | 'latitude' | 'longtitude') => {
    //console.log("handleZoomUpdate", val)
    if(field == 'minZoom')
    {
      state.queryParams.minZoom = val
      props.map.setMinZoom(val)
      props.map.setView([state.queryParams.latitude, state.queryParams.longtitude], val)  
    }
    else if(field == 'maxZoom')
    {
      state.queryParams.maxZoom = val   
      props.map.setMaxZoom(val)  
      props.map.setView([state.queryParams.latitude, state.queryParams.longtitude], val)     
    }
    else if(field == 'defaultZoom')
    {
      state.queryParams.defaultZoom = val   
      props.map.setView([state.queryParams.latitude, state.queryParams.longtitude], val)    
    }
    else if(field == 'latitude'){
      state.queryParams.latitude = val   
      props.map.setView([state.queryParams.latitude, state.queryParams.longtitude],  state.queryParams.defaultZoom)  
    }
    else if(field == 'longtitude'){
      state.queryParams.longtitude = val   
      props.map.setView([state.queryParams.latitude, state.queryParams.longtitude],  state.queryParams.defaultZoom)  
    }
}


// ===== Equipment Type Management =====
/**
 * Handles changes to equipment type selection and loads corresponding data
 */
const handleItemGroupChange = () => {
  //console.log("handleItemGroupChange")
  watch(() => state.queryParams.itemGroup, async (itemGroup: any) => {
    //console.log("itemGroup", itemGroup)      
    if (!itemGroup) return;
    state.itemList = [];
    try {
      switch (itemGroup) {
        case 'device': {

          // Load equipment data
          const equipmentResponse = await getAPI(TmsEquipmentApi).apiTmsTmsequipmentListGet();

          const equipmentData = equipmentResponse?.data?.result || [];
          //console.log("equipmentData", equipmentData)
          // Transform data into grouped structure
          state.itemList = transformEquipmentData(equipmentData, state.equipmentTypeList, isIdInGeoJson);
          //console.log(state.itemList)
          break;
        }
        case 'zone': {
          // Load zones data
          const zonesResponse = await getAPI(TmsZoneApi).apiTmsTmszoneListGet();
          const zonesData = zonesResponse?.data?.result || [];

          // Transform data into grouped structure
          state.itemList = await transformZonesData(zonesData, isIdInGeoJson);
          break;
        }
        case 'unit': {
          // Load work unit data
          const workUnitResponse = await getAPI(TmsWorkUnitApi).apiTmsTmsworkunitListGet();
          const workUnitData = workUnitResponse?.data?.result || [];

          // Transform data into grouped structure
          state.itemList = await transformWorkUnitData(workUnitData, isIdInGeoJson);
          break;
        }
        default:
          console.warn(`Unhandled object type: ${itemGroup}`);
          state.itemList = [];
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      state.itemList = [];
    }
  });
};


// ===== Form Submission =====
/**
 * Submits the form to create new map location
 */
const handleSave = async () => {
  const stringifyGeoJson = JSON.stringify(props.geoJsonData)
  //console.log("stringifyGeoJson", stringifyGeoJson)
  emit('handle-save', {
    geoJson: JSON.stringify(props.geoJsonData),
    status: 1,
    maxZoom: state.defaultValue.maxZoom,
    minZoom: state.defaultValue.minZoom,
    latitude: state.defaultValue.latitude,
    longtitude: state.defaultValue.longtitude
  })
};


// Toggle panel visibility
const togglePanel = () => {
  isPanelCollapsed.value = !isPanelCollapsed.value
}

// Clear search input
const handleSearchClear = () => {
  tableSearch.value = ''
}


// Transform GeoJSON data into table data
const tableData = computed(() => {
  return props.geoJsonData?.features.map((feature: any) => {
    //console.log("tableData - feature", feature)
    const itemDetails = mapStore.getItemDetails(feature.properties?.id, feature.properties?.itemGroup)
    const baseData = {
      id: feature.properties?.id,
      name: itemDetails.name || $t('lz.label.tmsMapLocation.unNamed'),
      geometryType: feature.geometry.type,
      itemGroup: feature.properties?.itemGroup,
      equipmentType: itemDetails?.type
    }

    if (feature.geometry.type === 'Point') {
      const [lng, lat] = feature.geometry.coordinates
      return {
        ...baseData,
        lat,
        lng
      }
    } else {
      const coordinates = feature.geometry.coordinates[0]
      const [firstLng, firstLat] = coordinates[0]
      return {
        ...baseData,
        topLeft: { lat: firstLat, lng: firstLng }
      }
    }
  })
})

/**
 * useDebounce to input search
*/
watchDebounced(tableSearch, () => {
  //console.log("watchDebounced - tableSearch", tableSearch)
  inputSearchDataTable.value = tableSearch.value;
}, { debounce: 1000, maxWait: 5000 })


//   console.log("renderDataTable")
//   console.log(state.listDataTable )

//   console.log("renderDataTable -  tableData.value")
//   console.log( tableData.value )

//   const search = state.inputSearchDataTable.toLowerCase().trim()

//   let listTableSearch: any
//   if (!search)
//   {
//     listTableSearch = tableData.value
//   } 
//   else{
//     listTableSearch = tableData.value.filter((item: any) => {
//     const nameMatch = item.name?.toLowerCase().includes(search)
//     const typeMatch = item.geometryType?.toLowerCase().includes(search)
//     return nameMatch || typeMatch
//   })
//   }

//   if(state.activeTabItemGroup != "")
//   {
//     const listFilter =  listTableSearch.filter((item:any) =>  item?.itemGroup ==  state.activeTabItemGroup)
//     //console.log("listFilter", listFilter)
//     const arrayReturn = [] as any
//     const listEquipmentTypeAfterFilter = listFilter.map((item:any) => item.equipmentType)

//     // Create unique list equipment type
//     const lisDistinctEquipmentType  = [...new Set(listEquipmentTypeAfterFilter)]
    
//     // Foreach unique list equipment type => Get list display based on equipment type
//     lisDistinctEquipmentType.forEach((element:any) => 
//     {
//         const listFilterDisplayBasedOnEquipmentType = listFilter.filter((item:any) => item?.equipmentType == element )
//         arrayReturn.push({
//             equipmentType: element,
//             listFilter: [...listFilterDisplayBasedOnEquipmentType]
//         })
//     });
//     console.log("arrayReturn ", arrayReturn )
//     state.listDataTable = [...arrayReturn]
//   } 
//   console.log("state.activeTabItemGroup ", state.activeTabItemGroup )
//   console.log("renderDataTable - after")
//   console.log(state.listDataTable )
// }


// Filter table data based on search input
const filteredTableData = computed(() => {
  //console.log("filteredTableData")
  //let listFilter:any

  //console.log("inputSearchDataTable", inputSearchDataTable.value)

  const search = inputSearchDataTable.value.toLowerCase().trim()

  let listTableSearch: any
  if (!search || search == '')
  {
    listTableSearch = tableData.value
  } 
  else{
    listTableSearch = tableData.value.filter((item: any) => 
    {
        const nameMatch = item.name?.toLowerCase().includes(search)
        const typeMatch = item.geometryType?.toLowerCase().includes(search)
        return nameMatch || typeMatch
    })
  }
  if(state.activeTabItemGroup != "")
  {
    const listFilter =  listTableSearch.filter((item:any) =>  item?.itemGroup ==  state.activeTabItemGroup)
    //console.log("listFilter", listFilter)
    const arrayReturn = [] as any
    const listEquipmentTypeAfterFilter = listFilter.map((item:any) => item.equipmentType)

    // Create unique list equipment type
    const lisDistinctEquipmentType  = [...new Set(listEquipmentTypeAfterFilter)]
    
    // Foreach unique list equipment type => Get list display based on equipment type
    lisDistinctEquipmentType.forEach((element:any) => 
    {
        const listFilterDisplayBasedOnEquipmentType = listFilter.filter((item:any) => item?.equipmentType == element )
        arrayReturn.push({
            equipmentType: element,
            listFilter: [...listFilterDisplayBasedOnEquipmentType]
        })
    });
    return arrayReturn
  } 
})

//console.log("LocationEditor - filteredTableData", filteredTableData)

/**
 * Computed property for filtered item data
 */
const filteredItemData = computed(() => {
  //console.log("filteredItemData", state.itemList)
  const list = state.itemList.map((group: any) => ({
    ...group,
    children: group.children.map((item: any) => ({
      ...item,
      disabled: isIdInGeoJson(item.id)
    }))
  }));
  //console.log("filteredItemData - list",list)
  return list 
});


// ===== Map State Management =====
/**
 * Checks if an ID exists in the GeoJSON data
 */
const isIdInGeoJson = (id: string): boolean => {
  if (!id || id.startsWith('type_')) return false;

  //console.log("isIdInGeoJson - props.previousGeoJsonFeature", props.previousGeoJsonFeature)

  // Check in list previous first
  if(props.previousGeoJsonFeature && props.previousGeoJsonFeature.length > 0) 
  {
    const isIdExistInListPrevious = props.previousGeoJsonFeature.some((feature: any) =>
        feature.properties?.id === id
    );
    console.log("isIdInGeoJson - isIdExistInListPrevious", isIdExistInListPrevious)

    if(isIdExistInListPrevious){
      return true;
    }
  }
   // Check in list previous first
  if(props.previousFeatureGeoJsonDataZone && props.previousFeatureGeoJsonDataZone.length > 0) 
  {
    const isIdExistInListPrevious = props.previousFeatureGeoJsonDataZone.some((feature: any) =>
        feature.properties?.id === id
    );  

    if(isIdExistInListPrevious){
      return true;
    }
  }
  
  return props.geoJsonData.features.some((feature: any) =>
    feature.properties?.id === id
  );
};


// Handle location updates
const handleLocationUpdate = (row: any, value: number, field: 'lat' | 'lng') => {
  //console.log("handleLocationUpdate")
  //console.log("handleLocationUpdate - row", row)
  //console.log("handleLocationUpdate - value", value)
  //console.log("handleLocationUpdate - field", field)
  if (row.geometryType === 'Point') {
    const feature = props.geoJsonData?.features.find((f: any) => f.properties?.id === row.id);
    if (!feature) return;

    // Update the row data first
    row[field] = value;

    // Update the feature coordinates
    if (field === 'lat') {
      feature.geometry.coordinates[1] = value;
    } else {
      feature.geometry.coordinates[0] = value;
    }

    // Update marker position on the map
    state.markersLayer?.eachLayer((layer: any) => {
      if (layer.feature?.properties?.id === row.id ||
        (layer.options && layer.options.id === row.id)) {
        layer.setLatLng([row.lat, row.lng]);
      }
    });

    emit('mark-unsaved', row.id);
  }
  else if (row.geometryType === 'Polygon') {
    handlePolygonUpdate(row, value, field);
  }

  //   emit('update-location', row, value, field)
}

const handlePolygonUpdate = (row: any, value: number, field: 'lat' | 'lng') => {
  // //console.log("handlePolygonUpdate - row", row)
  // //console.log("handlePolygonUpdate - value", value)
  // //console.log("handlePolygonUpdate - field",  row.topLeft[field])
  const feature = props.geoJsonData.features.find((f: any) => f.properties?.id === row.id);
  if (!feature || feature.geometry.type !== 'Polygon') return;


  const diff = value - row.topLeft[field];
  ////console.log("handlePolygonUpdate - diff", diff)
  const polygonCoords = feature.geometry.coordinates[0];
  const updatedCoords = polygonCoords.map((coord: number[]) => {
    const newCoord = [...coord];
    if (field === 'lat') {
      newCoord[1] += diff;
    } else {
      newCoord[0] += diff;
    }
    return newCoord;
  });

  feature.geometry.coordinates[0] = updatedCoords;

  // Update the polygon on the map
  // //console.log("Before loop - Update the polygon on the map", state.polygonsLayer)

  state.polygonsLayer?.eachLayer((layer: any) => {
    // //console.log("trong for loop the polygon on the map", layer)

    // //console.log("trong for loop the polygon on the map - feature", layer.feature)
    // //console.log("trong for loop the polygon on the map - options", layer.options)
    if (layer.feature?.properties?.id === row.id ||
      (layer.options && layer.options.id === row.id)) {

      // //console.log("Update the polygon on the map", state.polygonsLayer)
      const latLngs = updatedCoords.map(([lng, lat]: number[]) => [lat, lng]);
      layer.setLatLngs(latLngs);
    }
  });

  // Update the row's topLeft coordinates
  row.topLeft[field] = value;
  emit('mark-unsaved', row.id);

  // emit('update-polygon-location', row, value, field)
}

// ===== Map Navigation =====
/**
 * Locates and highlights a feature on the map
 */
const handleLocateOnMap = (row: any) => {
  highlightFeature(row.id, 1500);
};

// ===== Feature Editing Controls =====
/**
 * Starts editing mode for a feature
 */
const handleEditOnMap = (row: any) => {
  //console.log('start-editing')
  //console.log(row)
  emit('start-editing', row)
};

/**
 * Starts moving mode for a feature
 */
const handleMoveOnMap = (row: any) => {
  emit('start-moving', row)
};




// Add new function to finish editing/moving
const finishEditing = () => {
  if (!state.currentMode || !state.editingLayer) return;

  if (state.currentMode === 'edit') {
    (state.editingLayer as any).pm?.disable();
  } else if (state.currentMode === 'move') {
    if (state.editingLayer instanceof L.Marker) {
      (state.editingLayer as L.Marker).dragging?.disable();
    } else {
      (state.editingLayer as any).pm?.disable();
    }
  }

  state.currentMode = null;
  state.activeFeatureId = null;
  state.editingLayer = null;
  state.originalCoordinates = null;
  state.currentCoordinates = null;
  emit('render-map');
  //   renderGeoJson();
};

/**
 * Highlights a feature on the map
 */
const highlightFeature = (id: string, duration?: number) => {
  // Don't create highlight if we're in edit mode
  if (state.currentMode === 'edit') return;

  // Clear existing highlight
  clearHighlight();

  const feature = props.geoJsonData.features.find((f: any) => f.properties?.id === id);

  if (!feature || !props.map) return;
  if (feature.geometry.type === 'Point') {
    const [lng, lat] = feature.geometry.coordinates;
    state.highlightLayer = L.circle([lat, lng], {
      color: themeConfig.themeConfig.primary,
      fillColor: themeConfig.themeConfig.primary,
      fillOpacity: 0.3,
      radius: 50,
      weight: 2,
      className: 'highlight-pulse'
    }).addTo(props.map);

    props.map.setView([lat, lng], props.map.getZoom());
  } else if (feature.geometry.type === 'Polygon') {
    const coords = feature.geometry.coordinates[0].map(([lng, lat]: number[]) => [lat, lng]);
    state.highlightLayer = L.polygon(coords, {
      color: themeConfig.themeConfig.primary,
      weight: 3,
      opacity: 1,
      fillColor: themeConfig.themeConfig.primary,
      fillOpacity: 0.3,
      className: 'highlight-pulse'
    }).addTo(props.map);

    props.map.fitBounds(state.highlightLayer.getBounds());
  }
  emit('render-map');
  // Clear highlight after duration if specified
  if (duration) {
    setTimeout(() => {
      clearHighlight();
    }, duration);
  }
};


// Add cleanup for highlight when needed
const clearHighlight = () => {
  if (state.highlightLayer) {
    props.map.removeLayer(state.highlightLayer);
    state.highlightLayer = null;
  }
  emit('render-map');
};

// ===== Change Tracking =====
/**
 * Marks a feature as having unsaved changes
 */
const markUnsaved = (id: string) => {
  state.unsavedChanges.add(id);
  emit('render-map', {
    activeLayerId: id
  })
};

/**
 * Clears all unsaved changes tracking
 */
const clearUnsavedChanges = () => {
  state.unsavedChanges.clear();
  //   renderGeoJson();
};



// ===== Feature Deletion =====
/**
 * Shows confirmation dialog for feature deletion
 */
const handleDelete = (row: any): void => {
  ElMessageBox.confirm(
   $t('lz.message.base.confirmDelete', { name: row.name }),
    $t('lz.message.base.warning'),
    {
      confirmButtonText: $t('lz.button.base.confirm'),
      cancelButtonText: $t('lz.button.base.cancel'),
      type: 'warning',
      dangerouslyUseHTMLString: true,
      message: `
        <p>${$t('lz.message.tmsLocation.thisWillDelteItem')}:</p>
        <ul>
          <li><strong>${$t('lz.entity.base.name')}:</strong> ${row.name}</li>
          <li><strong>${$t('lz.entity.base.type')}:</strong> ${row.geometryType}</li>
          ${row.geometryType === 'Point'
          ? `<li><strong>${$t('lz.entity.tmsMapLocation.location')}:</strong> ${row.lat}, ${row.lng}</li>`
          : ''}
        </ul>
      `,
    }
  )
    .then(() => {
      removeFeatureById(row.id);
      ElMessage({
        type: 'success',
        message: `${$t('lz.message.base.deleteSuccess')} "${row.name}"`,
      });
    })
    .catch(() => {
      ElMessage({
        type: 'info',
        message: $t('lz.message.base.deleteCancel'),
      });
    });
};

/**
 * Removes a feature by its ID
 */
const removeFeatureById = (id: string) => {
  const featureToRemove = props.geoJsonData.features.find((feature: any) => feature.properties?.id === id);

  props.geoJsonData.features = props.geoJsonData.features.filter((feature: any) => feature.properties?.id !== id);

  state.markersLayer.eachLayer((layer: any) => {
    if (layer.feature?.properties?.id === id) {
      state.markersLayer.removeLayer(layer);
    }
  });

  state.polygonsLayer.eachLayer((layer: any) => {
    if (layer.feature?.properties?.id === id) {
      state.polygonsLayer.removeLayer(layer);
    }
  });
  emit('render-map');
  //   renderGeoJson();
  //console.log('Removed feature:', featureToRemove);
};

/*
// Thêm item trên map
*/
const handleAddItem = () => {
  //console.log("handleAddItem - LocationEditor - queryParams - itemId", state.queryParams.itemId)
  emit('add-item', {
    group: state.queryParams.itemGroup,
    id: state.queryParams.itemId
  })
  state.queryParams.itemId = '' // Reset selection after adding
}

/*
// Vẽ zone trên map
*/
const handleStartDrawingPolygon = () => {
  //console.log("TypeId", state.queryParams.itemId)
  if (props.map) {
    emit('handle-start-drawing-polygon', {
      typeId: state.queryParams.itemId,
      group: state.queryParams.itemGroup,
    })
  } else {
    //console.log("Map doesn't initial")
  }

}

const handleResetTypeIdEqualNull = () => {
  state.queryParams.itemId = '';
}

const handleGetItemId = () => {
  return state.queryParams.itemId;
}

const handleGetItemGroup = () => {
  return state.queryParams.itemGroup;
}

// function $t(arg0: string): import("element-plus").MessageParamsWithType {
//   throw new Error('Function not implemented.')
// }

defineExpose({
  ruleFormRef,
  itemGroup: state.queryParams.itemGroup,
  itemId: state.queryParams.itemId,
  handleResetTypeIdEqualNull,
  handleItemGroupChange,
  handleGetItemId,
  handleGetItemGroup
});

</script>


<style scoped>

:deep(.highlight-pulse) {
  animation: highlightPulse 1.5s ease-in-out infinite;
}

:deep(.highlight-pulse path) {
  animation: highlightPulse 1.5s ease-in-out infinite;
}

.right-panel {
  position: absolute;
  top: 0;
  right: 0;
  width: 700px;
  height: 100%;
  background: white;
  border-left: 1px solid #dcdfe6;
  transition: all 0.3s ease;
  z-index: 1000;
  box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
}

.collapse-toggle {
  position: absolute;
  left: -30px;
  top: 50%;
  transform: translateY(-50%);
  background: white;
  padding: 8px;
  border-radius: 4px 0 0 4px;
  border: 1px solid #dcdfe6;
  border-right: none;
  cursor: pointer;
  box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
}

.panel-content {
  flex: 1;
  overflow-y: auto;
  /* Change from 'hidden' to 'auto' */
  display: flex;
  flex-direction: column;
  padding: 0 10px;
  /* Add some padding */
}

/* Add these new styles */
.el-tabs {
  height: calc(100% - 70px);
  display: flex;
  flex-direction: column;
}

:deep(.el-tabs__content) {
  flex: 1;
  overflow: auto;
}

:deep(.el-tab-pane) {
  height: 100%;
}

.table-container {
  height: 100%;
  overflow: auto;
  /* Add scroll for table container */
}

.collapsed {
  transform: translateX(100%);
}

.card-header {
  padding: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.search-controls {
  width: 200px;
}

.location-controls {
  display: flex;
  gap: 8px;
}

.action-buttons {
  display: flex;
  gap: 8px;
}

.geojson-container {
  height: 100%;
  overflow: auto;
  padding: 10px;
}

.geojson-content {
  margin: 0;
  white-space: pre-wrap;
  word-wrap: break-word;
}

.item-management {
  padding: 10px;
  border-bottom: 1px solid #dcdfe6;
}

.demo-tabs > .el-tabs__content {
  padding: 32px;
  color: #6b778c;
  font-size: 32px;
  font-weight: 600;
}

.accordion {
  background-color: #eee;
  color: #444;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
  transition: 0.4s;
}

.active, .accordion:hover {
  background-color: #ccc;
}

.accordion:after {
  content: '\2212';
  color: #777;
  font-weight: bold;
  float: right;
  margin-left: 5px;
}

.active-accordion:after {
  content: "\002B";
}

.panel-accordion {
  margin-top: 10px;
  padding: 0px 18px;
  background-color: white;
  transition: max-height 0.2s ease-out;
}

.d-none-accordion {
  display: none;
}


</style>