<template>
  <div class="map-controls">    
    <!-- Map Selection -->
    <el-form :model="queryParams" label-width="auto">
      <el-row class="mb5 is-justify-space-between"  >    <!--:style="{backgroundColor: 'white', border:'1px solid red',  padding: '5px' }"-->
        <el-col lass="mb5" :xs="7" :sm="7" :md="7" :lg="7" :xl="7">
          <el-form-item prop="mapId">
              <el-select 
                v-model="queryParams.mapId" 
                filterable 
                class="w200" 
                @change="handleMapChange"             
              >
                <el-option 
                  v-for="item in mapList" 
                  :key="item.id" 
                  :label="item.name" 
                  :value="item.id" 
                />
              </el-select>
           </el-form-item>
        </el-col>
        
    </el-row>

      <!-- Filter Dropdown -->     
      <el-form-item>
        <el-popover
          placement="bottom-start"
          :width="200"
          trigger="click"
        >
          <template #reference>
            <div>
              <el-tooltip :content="$t('lz.button.tmsMapLocation.filterOnMap')"  placement="right">
                <el-button icon="ele-Filter" circle type="white">  </el-button>           
              </el-tooltip>  
            </div>                    
          </template> 

            <!-- Filter Content -->
            <div class="filter-content">
            <div v-for="group in state.listFilter" :key="group.value" class="filter-group">             
               <el-checkbox
                v-model="group.checked"
                :indeterminate="group.indeterminate"
                @change="handleGroupChange(group)"
              >
                {{ group.label }}
              </el-checkbox>
              <div class="filter-items">
                <el-checkbox
                  v-for="item in group.children"
                  :key="item.value"
                  v-model="item.checked"
                  @change="handleItemChange(group)"
                >
                  {{ item.label }}
                </el-checkbox>
              </div>     
            </div>
          </div>
        </el-popover>
      </el-form-item>
   
    </el-form>

    <!-- Control Buttons -->
    <div class="control-buttons">
      <el-tooltip :content="$t('lz.button.tmsMapLocation.zoomIn')"  placement="right">
        <el-button @click="$emit('zoom-in')" icon="ele-ZoomIn" circle></el-button>
      </el-tooltip>
      <el-tooltip :content="$t('lz.button.tmsMapLocation.zoomOut')"  placement="right">
        <el-button @click="$emit('zoom-out')" icon="ele-ZoomOut" circle></el-button>
      </el-tooltip>
      <el-tooltip :content="$t('lz.button.base.refresh')"  placement="right">
        <el-button @click="$emit('refresh')" icon="ele-Refresh" circle></el-button>
      </el-tooltip>
      
    
    
    </div>
  </div>

    <!-- <div class="finish-button-container" v-if="state.currentMode">
          <el-button type="primary" @click="finishEditing">
            <el-icon><Check /></el-icon>
            Finish {{ state.currentMode === 'edit' ? 'Editing' : 'Moving' }}
          </el-button>
    </div> -->
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, watch } from 'vue'
import { getAPI } from '/@/utils/axios-utils'
import { TmsMapApi, TmsMapOutput } from '/@/api-services/tms'
import { Filter } from '@element-plus/icons-vue'
import { useMapStore } from '/@/stores/mapStore'
import { number } from 'echarts'


interface Item {
  label: string;
  value: string;
  checked: boolean;
}

interface ItemGroup {
  label: string;
  value: string;
  checked: boolean;
  indeterminate: boolean;
  children: Item[];
}

const emit = defineEmits(
    ['refresh', 'zoom-in', 'zoom-out', 'map-change', 'filter-change', 
  'get-geo-json-data', 'get-current-mode']
)
const mapList = ref<TmsMapOutput[]>([])

const mapStore = useMapStore()

// variable for select map
const queryParams = reactive({
  mapId: undefined,
})

// let objItemGroup = {
//   label: '',
//   value: '',
//   checked: true,
//   indeterminate: false,
//   children: [] as any
// }

const props = defineProps({
  geoJsonData: [] as any,
  selectedMapId: '' as any
})

const state = reactive({
  itemGroup: [] as any,
  itemList: [] as any,
  equipmentTypeList: [] as any,
  equipmentList: [] as any,
  zoneList: [] as any,
  zoneTypeList: [] as any,
  workUnitTypeList: [] as any,
  workUnitList: [] as any,
  geoDataJson:[] as any,
  listFilter:[] as any
})

let itemGroups : ItemGroup[] = [];


// const itemGroups = ref([
//   {
//     label: 'Equipment',
//     value: 'device',
//     checked: true,
//     indeterminate: false,
//     children: [
//       { label: 'Camera', value: 'camera', checked: true },
//       { label: 'Sensor', value: 'sensor', checked: true },
//       { label: 'Gate', value: 'gate', checked: true }
//     ]
//   },
//   {
//     label: 'Zones',
//     value: 'zone',
//     checked: true,
//     indeterminate: false,
//     children: [
//       { label: 'Parking', value: 'parking', checked: true },
//       { label: 'Storage', value: 'storage', checked: true }
//     ]
//   },
//   {
//     label: 'Work Units',
//     value: 'unit',
//     checked: true,
//     indeterminate: false,
//     children: [
//       { label: 'Construction', value: 'construction', checked: true },
//       { label: 'Maintenance', value: 'maintenance', checked: true }
//     ]
//   }
// ])

const handleGroupChange = (group: any) => {
 if(group.children && group.children.length > 0){''
    group.children.forEach((item: any) => {
      item.checked = group.checked
    })
  }  
  emitFilterChange(group)
}

const handleItemChange = (group: any) => {
  const checkedCount = group.children.filter((item: any) => item.checked).length
  group.checked = checkedCount === group.children.length
  group.indeterminate = checkedCount > 0 && checkedCount < group.children.length  
  emitFilterChange(group)
}

const emitFilterChange = (group: any = undefined) => {
  const filters = state.listFilter.reduce((acc: any, element:any) => {
    //console.log("emitFilterChange", acc)
    acc[element?.value] = group?.children.filter((item : any) => item.checked) .map((item: any) => item.value)
    return acc
  }, {} )

  // Continue filter with group was selected
  if(group)
  {
    // Lấy loại equipmentType được filter trong 3 loại ('device', 'unit', 'zone')
    const { value } = group

    // Tạo 1 object và assign giá trị của equipmentType được filter
    const objectFilter = {} as any
    objectFilter[`${value}`] = JSON.parse(JSON.stringify(filters[`${value}`]))    

    // Emit xử lý cho component cha Index xử lý
    emit('filter-change', objectFilter)
  }
  else{
    emit('filter-change', filters)
  }  
}

const fetchMapList = async () => {
  try {
    const response = await getAPI(TmsMapApi).apiTmsTmsmapListGet()
    mapList.value = response?.data?.result || []
    //console.log("fetchMapList - mapList.value", mapList.value)
  } catch (error) {
    console.error('Error fetching map list:', error)
  }
}

const handleMapChange = () => {
  emit('map-change', queryParams.mapId)
}

// Convert data to itemGroups
const transformData = (listItemGroup:any, listEquipmentType:any, listZone:any, listWorkUnit: any) => {
  listItemGroup?.forEach((item: any) => {
    switch(item?.code){
      case 'device':
        const objItemGroup:ItemGroup = {
          label : item?.name,
          value : item?.code,
          checked: true,
          indeterminate: true,
          children: []
        }   
        listEquipmentType.forEach((equipment: any) => {
            const objTemp = {
              label: equipment?.name,
              value: equipment?.id,
              checked: true
            };
            objItemGroup.children.push(objTemp);
        })
        //console.log("itemGroups", objItemGroup)
       itemGroups.push(objItemGroup)
        break;
      case 'zone':      
      // Chỉ hiển thị zone
        const objItemGroup_2:ItemGroup = {
          label :  item?.name,
          value : item?.code,
          checked: true,
          indeterminate: true,
          children: [ {
              label: item?.name,
              value:item?.code,
              checked: true
            }]
        }           
        // listZone.forEach((equipment: any) => {
        //     const objTemp = {
        //       label: equipment?.name,
        //       value: equipment?.id,
        //       checked: true
        //     };
        //     objItemGroup_2.children.push(objTemp);
        // })
        //console.log("itemGroups", objItemGroup_2)
        itemGroups.push(objItemGroup_2)
        break;
      case 'unit':
        const objItemGroup_3:ItemGroup = {
          label :  item?.name,
          value : item?.code,
          checked: true,
          indeterminate: true,
          children: []
        }   
        listWorkUnit.forEach((equipment: any) => {
            const objTemp = {
              label: equipment?.name,
              value: equipment?.id,
              checked: true
            };
            objItemGroup_3.children.push(objTemp);
        })
        //console.log("itemGroups", objItemGroup_3)
        itemGroups.push(objItemGroup_3)
        break;
    }
  })
  state.listFilter = [...itemGroups];
  console.log("transformData-itemGroups", itemGroups)
}

// function Update Item 
function UpdateItemGroup(listGeoJsonData: any){
  if(listGeoJsonData && listGeoJsonData.length > 0)
  {
    console.log("UpdateItemGroup - listGeoJsonData - IF", listGeoJsonData)

    const copyListGeoJsonDat = JSON.parse(JSON.stringify(listGeoJsonData))
    const listItemGroupInListGeoJsonData = copyListGeoJsonDat.map((geoDataJson:any) => 
    {
      if(geoDataJson?.properties?.itemGroup !== undefined){
        return geoDataJson?.properties?.itemGroup
      }
    })

    // Lấy list unique itemGroup để filter zone
    const listItemGroupInListGeoJsonDataUnique = [...new Set(listItemGroupInListGeoJsonData)]
    //console.log("listItemGroupInListGeoJsonDataUnique", listItemGroupInListGeoJsonDataUnique)

    // Lấy tất cả id của device
    const listDevice = listGeoJsonData.map((geoDataJson:any) => 
    {
      if(geoDataJson?.properties?.itemGroup == 'device'){
        return geoDataJson?.properties?.id
      }
    })
    .filter((item:any) => item != undefined)
    //console.log("listDevice",listDevice)

     // Lấy tất cả id của unit
    const listUnit = listGeoJsonData.map((geoDataJson:any) => 
    {
      if(geoDataJson?.properties?.itemGroup == 'unit'){
         return geoDataJson?.properties?.id
      }
    })
    .filter((item:any) => item != undefined)
    console.log("listUnit",listUnit)

    // Assign lại array children của itemGroups  

    // Lấy EquipemntTypeId
    const listEuipmentTypeId = [] as any
    mapStore.equipmentList.forEach((equipment) => 
    { 
      if(listDevice.includes(equipment?.id) && !listEuipmentTypeId.includes(equipment?.equipmentTypeId))
      {
        listEuipmentTypeId.push(equipment?.equipmentTypeId)
      }
    })    

    // Assign lại itemGroups cho listFilterUpdate
    //console.log("itemGroups",itemGroups)
    const listitemGroupsCopy = JSON.parse(JSON.stringify(itemGroups))
    //console.log("listitemGroupsCopy",listitemGroupsCopy)

     // Loop state.listFilter lấy các data có trong geoJsonData   
     const listFilterUpdate = listitemGroupsCopy.map((item:any) => 
     {
        if(item.value == 'device' && listEuipmentTypeId.length > 0  && item.children.length > 0){
          console.log("listFilterUpdate - device")
          item.children = item.children.filter((itemChildren:any) => {
            if(listEuipmentTypeId.includes(itemChildren?.value)){
                return itemChildren
              }
          })
          return item
        }
        if(item.value == 'unit' && listUnit.length > 0  && item.children.length > 0){
          console.log("listFilterUpdate - unit")
          item.children = item.children.filter((itemChildren:any) => {
              if(listUnit.includes(itemChildren?.value)){
                return itemChildren
              }
          })
          return item
        }
        if(item.value == 'zone' && listItemGroupInListGeoJsonDataUnique.includes(item.value)){
          console.log("listFilterUpdate - zone")
          item.children = [{
            label :  'Zone-N',
            value : 'zone',
            checked: true,
            indeterminate: true,
            children: [{
                label: 'Zone-N',
                value: 'zone',
                checked: true
              }]
          }]
          return item
        }
    }).filter((item: any) => item!=undefined) 
    //console.log("listFilterUpdate",listFilterUpdate)
    state.listFilter = [...listFilterUpdate]
    // Assign state.listFilter
   
    //console.log("state.listFilter", state.listFilter)
  }
  else{
    // state.listFilter = [ {
    //       label :  'Zone-N',
    //       value : 'zone',
    //       checked: true,
    //       indeterminate: true,
    //       children: [ {
    //           label: 'Zone-N',
    //           value: 'zone',
    //           checked: true
    //         }]
    //     }]

      state.listFilter = []
  }
}

// Load data from map store
async function loadData() {
    // Fetch other data after map is loaded
    await mapStore.fetchItemGroupList();
    state.itemGroup = mapStore.itemGroupList;
    
    await mapStore.fetchEquipmentTypeList();
    state.equipmentTypeList = mapStore.equipmentTypeList;

    // await mapStore.fetchZoneList();
    // state.zoneList = mapStore.zoneList;

    await mapStore.fetchWorkUnitList();
    state.workUnitList = mapStore.workUnitList;

    // Convert data to show dropdown in filter map
    transformData(state.itemGroup,  state.equipmentTypeList, state.zoneList, state.workUnitList);
}

watch(() => props.geoJsonData,(newVal, oldValue)=>{
  if(newVal != oldValue){
    console.log("Dữ liệu GeoJsonData From Index Component - newVal != oldValue", newVal)
    //state.geoDataJson = [...props.geoJsonData];  
    // Update lại item group
    UpdateItemGroup(newVal)
  }
})

// Initialize filters on mount
onMounted(async() => {
  await loadData();
  fetchMapList()
  emitFilterChange()

  // Assign selectedMapId
  queryParams.mapId = props.selectedMapId

  // if(props.maxZoom && props.minZoom){
  //   queryParams.maxZoom = props.maxZoom
  //   queryParams.minZoom = props.minZoom
  // }
  //emit("get-geo-json-data");
  //console.log("Dữ liệu GeoJsonData From Index Component", props.geoJsonData)
})

</script>

<style scoped>
.map-controls {
  position: absolute;
  top: -10px;
  left: 10px;
  z-index: 1000;
  width: 500px;
  /* background: white; */
  padding: 10px;
  border-radius: 4px;
  /* box-shadow: 0 2px 5px rgba(0,0,0,0.2); */
}

.control-buttons {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 10px;
}

.el-button {
  width: 35px;
  height: 35px;
  opacity: 0.5;
  transition: opacity 0.3s, transform 0.3s;
  margin-left: 0px!important;
}

.el-button:hover {
  opacity: 1;
  transform: scale(1.1);
}

.w100 {
  width: 200px;
}

.filter-content {
  max-height: 300px;
  overflow-y: auto;
}

.filter-group {
  margin-bottom: 10px;
}

.filter-items {
  margin-left: 20px;
  display: flex;
  flex-direction: column;
  gap: 5px;
}
</style> 