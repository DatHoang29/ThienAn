<template>
  <div class="map-container">

    <div class="finish-button-container" v-if="state.currentMode">
          <el-button type="primary" @click="finishEditing">
            <el-icon><Check /></el-icon>
            {{ $t('lz.label.base.finish') }}  {{ state.currentMode === 'edit' ? $t('lz.label.base.editing') : $t('lz.label.base.moving') }}
          </el-button>
    </div>

    <div id="map" ref="mapContainer"></div>

    <LocationEditor
      v-if="showLocationEditor"
      :geoJsonData="state.geoJsonData"
      :previousGeoJsonFeature="state.previousFeatureGeoJsonData"
      :previousFeatureGeoJsonDataZone="state.previousFeatureGeoJsonDataZone"
      :markersLayer="state.markersLayer"
      :polygonsLayer="state.polygonsLayer"
      :highlightLayer="state.highlightLayer"
      :map="state.map"
      ref="locationEditorRef"
      :mapId="selectedMapId"
      :max-zoom="state.mapViewState.maxZoom"
      :min-zoom="state.mapViewState.minZoom"
      :latitude="state.mapViewState.center[0]"
      :longtitude="state.mapViewState.center[1]"
      :default-zoom="state.mapViewState.zoom"
      @start-editing="handleStartEditing"
      @start-moving="handleStartMoving"
      @render-map="renderGeoJson"
      @add-item="handleAddItem"     
      @handle-save="handleSave"
      @handle-start-drawing-polygon="handleStartDrawingPolygon"
      @mark-unsaved="handleMarkUnsaved"
    />

    <!--
      <ModalEditFeature  ref="modalEditRef" :edit-dialog-visible="state.editDialogVisible"
              :editFeature="state.editFeature" @save-edit-modal="handleSaveEditModal" 
              @remove-feature-modal="handleRemoveFeatureModal"/> 
    -->   

    </div>   

  
</template>

<script setup lang="ts">
import { ref, onMounted, watch, reactive, computed } from 'vue'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import {getAPI } from '/@/utils/axios-utils'
import {TmsMapApi, TmsMapLocationApi,UpdateTmsMapLocationInput } from '/@/api-services/tms'
import Image from '/@/assets/toll-road.png'
import LocationEditor from './LocationEditor.vue'
import { useThemeConfig } from '/@/stores/themeConfig'
import { ElMessage, ElMessageBox } from 'element-plus'
import {useMapStore} from '/@/stores/mapStore'
import ModalEditFeature from './ModalEditFeature.vue'

// Import 2 thư viện này mới vẽ được polygon trên zone
import '@geoman-io/leaflet-geoman-free';
import '@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css';

import { IMapItemAction } from '/@/types/interfaces'
import { TmsEquipmentType, TmsMapLocationRefType, TmsTrafficInfoMap } from '/@/types/enums'
import { useI18n } from 'vue-i18n'

// Import function gen random
import {generateRandomNumber} from '/@/utils/randomHelper.js'

// Import broadcast lắng nghe sự kiện
import { useIncidentMonitor } from '/@/stores/incidentMonitor'
import { useMonitorVms } from '/@/stores/monitorVms'

import { TmsZoneStatusApi } from '/@/api-services/tms'
import {useBaseConfig} from '/@/stores/baseConfig'
import { BaseConfigTypeEnum } from '/@/types/enums'
import { get } from 'sortablejs'

const getOpConfigByGroupCode = useBaseConfig().getOpConfigListByGroupCode;

const { t: $t } = useI18n();
//const modalEditRef = ref<InstanceType<typeof ModalEditFeature> | null>(null);
interface MapViewState {
  center: [number, number];
  zoom: number;
  maxZoom: number,
  minZoom: number
}

let stateFromChild;

const mapStore = useMapStore()
const themeConfig = useThemeConfig()

// Khai báo lắng nghe sự kiện
const incidentMonitor = useIncidentMonitor();

// Khai báo lắng nghe sự kiện vms trả về
const vmsMonitor = useMonitorVms();

const props = defineProps({
  selectedMapId: {
    type: String,
    default: undefined
  },
  showLocationEditor: {
    type: Boolean,
    default: false
  },
  filters:{
    type:Object
  },
  lastNameUrl: '' as any
})

// Khai báo biến ref để truy cập component Location Edit
const locationEditorRef = ref();
const emit = defineEmits(['item-action', 'return-geo-json-data', 'refreshMap'])


const state = reactive({
  queryParams:{
      itemId: null as any,
      itemGroup: null as any
    },
  editingLayer: null as any, // Store reference to the editing layer
  unsavedChanges: new Set<string>(),
  map: null as L.Map | null as any,
  highlightLayer: null as L.Layer | null,
  markersLayer: ref(L.layerGroup() as L.LayerGroup<L.Marker>),
  polygonsLayer: ref(L.layerGroup() as L.LayerGroup<L.Polygon>),
  tileLayer: null as L.TileLayer | null,
  imageOverlay: null as L.ImageOverlay | null,
  geoJsonData: {
    type: "FeatureCollection",
    features: [] as any[],
  },
  drawingItem: null as any  ,
  editDialogVisible: false,
  editFeature: {
    id: '',
    status: '',
    strokeColor: '#000000',
    strokeWidth: 2,
    strokeOpacity: 1,
    fillOpacity: 1,
    type: '',
    layer: null as L.Layer | null,
  },
  currentCoordinates: null as any,
  ruleForm: {} as UpdateTmsMapLocationInput,
  currentMode: null as 'edit' | 'move' | null,
  originalCoordinates: null as any,
  activeFeatureId: null as string | null,
  filterDeviceItems:{} as any,
  previousFeatureGeoJsonData : [] as any | null,
  previousFeatureGeoJsonDataZone : [] as any | null,
  curentFeatureGeoJsonWasFilter : [] as any,
  lastNameUrl: null as string | null,
  mapViewState: {
    center: [0, 0] as [number, number],
    zoom: 0,
    maxZoom: 0,
    minZoom: 0
  } as MapViewState,
  tmsLocationMapId: '' as string | undefined | null,
  mapId: '' as string | undefined | null,
  listIdZoneInEventType: [] as any ,
  randomFourNumber: 1234 as number | undefined,
  listVmsCurrent: [] as any,
  listZoneStatus: [] as any,
  trafficStatusConfig: [] as any
});


/**
 * Enhanced objectRender interface
 */
 interface RenderMap {
  id: string,
  itemGroups: any;
  hasUnsavedChanges: boolean;
  itemDetails: ItemDetails;
}


// Dùng để render lại hình
const listVmsCurrentComputed = computed(() => {
  const arrayReturn = [...state.listVmsCurrent]
  return arrayReturn
})

//  Chạy khi khởi tạo xong component
onMounted(async () => {  
   console.log("Leaflet Map")
   await mapStore.loadData()       
   await handleLoadZoneStatus();
   
  //  listVmCurrentRef.value = [...mapStore.vmsCurrentList] as any

  //ReturnGeoDataJsonToComponentIndex();  
})


const initializeMap = async () => {

  if (state.map) {
    state.map.remove()
    state.map = null
  }

  // Create new map instance
  state.map = L.map('map', {
    center: [0, 0],
    zoom: 1,
    crs: L.CRS.Simple,
    zoomControl: false,
    attributionControl: false,
    maxZoom: 18,
    minZoom: 1,
    zoomSnap: 0.5,   // Zoom in increments of 0.25
    zoomDelta: 0.5, // Zoom with controls in increments of 0.5
    wheelPxPerZoomLevel: 80 // Slower mouse wheel zoom
    
  })


  state.markersLayer = L.layerGroup().addTo(state.map)
  state.polygonsLayer = L.layerGroup().addTo(state.map)

  //state.map.on('zoomend', renderGeoJson);
  state.map.on('pm:create', handlePmCreate);
  // state.map.on('pm:create', (e:Event) => {
  //   handlePmCreate(e)
  // });

   // You can also listen for zoom changes
   state.map.on('zoomend', function() {
      var updatedZoom = state.map.getZoom();

      state.mapViewState.zoom = updatedZoom
      //console.log("Updated zoom level:", updatedZoom);
    });


  // Listen event mouseup get location lat and lng
  state.map.on('mouseup', function(e){
    //console.log("state.map-drag", e.latlng)
    state.mapViewState.center = [e.latlng.lat, e.latlng.lng]
  })


  return new Promise(resolve => {
    state.map?.whenReady(() => {
      resolve(true)
    })
  })
}

// Add new function to finish editing/moving
const finishEditing = () => {
  if (!state.currentMode || !state.editingLayer) return;

  if (state.currentMode === 'edit') {
    (state.editingLayer as any).pm?.disable();
  } 
  else if (state.currentMode === 'move') 
  {
    if (state.editingLayer instanceof L.Marker) {
      (state.editingLayer as L.Marker).dragging?.disable();
    } 
    else {
      (state.editingLayer as any).pm?.disable();
    }
  }

  state.currentMode = null;
  state.activeFeatureId = null;
  state.editingLayer = null;
  state.originalCoordinates = null;
  state.currentCoordinates = null;

  renderGeoJson();
};

/**
 * Handles creation of new features through Leaflet Geoman
 */
const handlePmCreate = (e: any, typeId: string = '', itemGroup: string = ''): void => {

  const { layer } = e;
  const geoJson = layer.toGeoJSON();
  const id = locationEditorRef.value?.handleGetItemId();

  if (!id) {
    layer.remove();
    return;
  }

  if (layer instanceof L.Polygon) {
    const coords = layer.getLatLngs()[0].map((latLng: L.LatLng) => [latLng.lng, latLng.lat]);
    geoJson.geometry.coordinates = [coords];
    geoJson.properties = { 
      id,
      itemGroup:  locationEditorRef.value?.handleGetItemGroup(),
      strokeColor: 'black', 
      strokeWidth: 1, 
      strokeOpacity: 1,
      fillOpacity: 0.5
    };

    state.geoJsonData.features.push(geoJson);
    state.polygonsLayer.addLayer(layer);

    // Sự kiện on click show modal
    //layer.on('click', () => showEditModal(layer, id, 'Polygon'));
    
    locationEditorRef.value?.handleResetTypeIdEqualNull();
    locationEditorRef.value?.handleItemGroupChange();
  }
};

const clearHighlight = () => {
    if (state.highlightLayer) {
    state.map.removeLayer(state.highlightLayer);
    state.highlightLayer = null;
  }
};

/**
 * Render icon marker in VMS
 */
const renderIconMarkerInVMS = (feature: any = null, equipment: any = null) => {

  const currentVms =   mapStore.vmsCurrentList.find((item: any)=> item.equipmentId === feature.properties.id);    
  const iconMarker = L.divIcon({
       className: 'custom-div-icon', // Add your custom class here
       html: `
         <div style="text-align: center; background-color: transparent; margin-left: -45px">
           <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 841.89 490.28"
             style="height: 3vw; width: 6vw; scale: 2;max-width: 200px">
             <g>
                 <linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="10.124" y1="294.8612" x2="831.7664" y2="294.8612">
                     <stop offset="0.1275" style="stop-color:#6CB0D0" />
                     <stop offset="0.2104" style="stop-color:#9ABDD5" />
                     <stop offset="0.2972" style="stop-color:#BCC6D8" />
                     <stop offset="0.3773" style="stop-color:#D2CCD9" />
                     <stop offset="0.4475" style="stop-color:#DFD0DA" />
                     <stop offset="0.5001" style="stop-color:#E3D1DB" />
                     <stop offset="0.5407" style="stop-color:#E0CFDA" />
                     <stop offset="0.59" style="stop-color:#D6CAD9" />
                     <stop offset="0.6438" style="stop-color:#C6C2D7" />
                     <stop offset="0.7008" style="stop-color:#ADB6D4" />
                     <stop offset="0.7603" style="stop-color:#87A6CF" />
                     <stop offset="0.8211" style="stop-color:#4992C9" />
                     <stop offset="0.8422" style="stop-color:#228BC7" />
                 </linearGradient>
                 <path   style="background:black;fill: ${equipment.equipmentState === 1 ? 'url(#SVGID_1_)' : '#E30613'};"
                       d="M786.38,168.79H55.51c-25.07,0-45.39,20.32-45.39,45.39v161.37c0,25.07,20.32,45.39,45.39,45.39h730.87c25.07,0,45.39-20.32,45.39-45.39V214.18C831.77,189.11,811.45,168.79,786.38,168.79z M811.52,375.54c0,13.86-11.28,25.14-25.14,25.14H55.51c-13.86,0-25.14-11.28-25.14-25.14V214.18c0-13.86,11.28-25.14,25.14-25.14h730.87c13.86,0,25.14,11.28,25.14,25.14V375.54z" />
                 
                 <image xlink:href="${state.queryParams.itemId === feature.properties.id ? undefined : (currentVms ? mapStore.baseUrl +'/'+ currentVms.url : '')}" x="40" y="200" width="760.88" height="200"></image>
                 
                 <g>
                     <path style="fill:#7CC1A0;" d="M106.13,168.79H55.51c-25.07,0-45.39,20.32-45.39,45.39l0,50.62c0,2.8-2.27,5.06-5.06,5.06S0,267.6,0,264.8v-50.62c0-30.61,24.9-55.52,55.51-55.52h50.62c2.8,0,5.06,2.27,5.06,5.06S108.93,168.79,106.13,168.79z" />
                     <path style="fill:#7CC1A0;" d="M735.76,168.79h50.62c25.07,0,45.39,20.32,45.39,45.39l0,50.62c0,2.8,2.27,5.06,5.06,5.06s5.06-2.27,5.06-5.06v-50.62c0-30.61-24.9-55.52-55.51-55.52h-50.62c-2.8,0-5.06,2.27-5.06,5.06S732.96,168.79,735.76,168.79z" />
                     <path style="fill:#7CC1A0;" d="M106.13,420.93H55.51c-25.07,0-45.39-20.32-45.39-45.39l0-50.62c0-2.8-2.27-5.06-5.06-5.06S0,322.12,0,324.92l0,50.62c0,30.61,24.9,55.52,55.51,55.52h50.62c2.8,0,5.06-2.27,5.06-5.06S108.93,420.93,106.13,420.93z" />
                     <path style="fill:#7CC1A0;" d="M735.76,420.93h50.62c25.07,0,45.39-20.32,45.39-45.39l0-50.62c0-2.8,2.27-5.06,5.06-5.06s5.06,2.27,5.06,5.06v50.62c0,30.61-24.9,55.52-55.51,55.52h-50.62c-2.8,0-5.06-2.27-5.06-5.06S732.96,420.93,735.76,420.93z" />
                 </g>
             </g>
         </svg>                
         </div>
       `,
       iconSize: [32, 42],  // Total size of the icon + label
       iconAnchor: [16, 32], // Anchor point of the icon
       popupAnchor: [0, -32] // Anchor point of the popup
    });
    return iconMarker
}


const renderPolygon = async (feature: any, hasUnsavedChanges: boolean, itemDetails: any) => {
  const id = feature.properties?.id;
  const coords = feature.geometry.coordinates[0].map( ([lng, lat]: number[]) => [lat, lng] ) 
  const colorBorderPolygon = getComputedStyle(document.documentElement).getPropertyValue('--el-color-success');
  const polygon = L.polygon(coords, {
            color: colorBorderPolygon,
            weight: feature.properties?.strokeWidth || 2,
            opacity: feature.properties?.strokeOpacity || 0.2,
            fillOpacity: feature.properties?.fillOpacity || 0.3,
            //fillColor: themeConfig.themeConfig.primary,
            fillColor: colorBorderPolygon,
            dashArray: hasUnsavedChanges ? '5, 10' : undefined,
            id: feature.properties?.id || undefined,
            smoothFactor: 1 
        })    

        // If this polygon is being moved, enable dragging
        if (state.currentMode === 'move' && id === state.activeFeatureId) {
          setTimeout(() => {
              (polygon as any).pm.enableLayerDrag();          
              polygon.on('pm:dragend', (e: any) => {
                //console.log("event dragend polygon")
                const updatedCoords = polygon.getLatLngs()[0].map((latLng: L.LatLng) => [latLng.lng, latLng.lat]);
                feature.geometry.coordinates = [updatedCoords];
                state.currentCoordinates = [updatedCoords];
                handleMarkUnsaved(id);
              });
          }, 0);
        }      
              
        // Cho traffic info
        // Lấy danh sách incident map zone 
        if(props.lastNameUrl != "mapSample" && props.lastNameUrl != '')
        {                
          const selectedZoneId = feature.properties.id;
          
          // Get zone in mapStore
          const zone = mapStore.zoneList.find((item:any) => item?.id == selectedZoneId)    

          //TODO: 2025/02/07 SonTH - Trạng thái giao thông
          await handleZoneStatus(polygon)
          
          const isExistIncidentZoneDataExistInTrafficInfoList = mapStore.incidentZoneDataExistInTrafficInfoList && mapStore.incidentZoneDataExistInTrafficInfoList.length > 0

          //Hiển thị icon sự kiện sự cố trong zone
          //console.log("RENDER JSON - mapStore.incidentZoneDataExistInTrafficInfoList",mapStore.incidentZoneDataExistInTrafficInfoList)
          if(isExistIncidentZoneDataExistInTrafficInfoList)
          {           
            let initLatIconAnchor = 35
            let initLngIconAnchor = 35
            let increaseLng = 0.0010
            let increaseLat = 0.0001

            mapStore.incidentZoneDataExistInTrafficInfoList.forEach((item:any) => { 
              // Check if the feature's properties id is in the list of incidents        

              if (item.listZoneId && item.listZoneId.length > 0 && item.listZoneId.includes(feature.properties.id)) 
              {                   
                const eventType = mapStore.eventTypeList.find((eventType:any) => eventType?.id == item.eventTypeId)             
            
                // Lấy icon hiển thị sự kiện, sự cố
                const iconUrl = mapStore.baseUrl + '/' + eventType?.url + '?&t=' +  state.randomFourNumber;

                // console.log("polygonl", polygon.getLatLngs())
                // const arrLatLngs = polygon.getLatLngs();
                // const latSetUp = arrLatLngs[0][3];
                // console.log("polygonl", latSetUp)
                
                const iconPolygon = L.icon({
                    iconUrl: iconUrl,
                    iconSize: [48, 48],
                    iconAnchor: [initLatIconAnchor, initLngIconAnchor],
                    popupAnchor: [0, 16]
                })     

                // inscrease lat icon anchor
                // initLatIconAnchor += inscreaseIconAnchor
                // initLngIconAnchor += inscreaseIconAnchor

                //console.log("fetchIncidentZoneData - iconUrl", iconUrl)

                // const iconDiv = L.divIcon({
                //   className: 'polygon-icon',                  
                //   html: `
                //     <div id="ImageIncident_${incidentId}" style="width:32px; height:32px; position: absolute; transform: translate(-50%, -50%);">
                //       <img  src="${iconUrl}" />
                //     </div>
                //   `,
                //   iconSize: [32, 32]
                // });

                // Set border color red when have incident
                polygon.setStyle({
                    color: '#FF0000',       // Red border
                    weight: 5,             // 5 pixels thick
                    opacity: 0.8,          // Slightly transpare
                    fillOpacity: 0.9,      // Semi-transparent fill
                    dashArray: '5, 5'    // Dashed border - creates a dashed line with 5-pixel dashes and 10-pixel gaps
                });

                const coordianateOfZone = feature.geometry.coordinates[0][0]
              
                // Create a new marker for each incident
                const bounds = polygon.getBounds();
                const center = bounds.getCenter();

                L.marker([center.lat + increaseLat, center.lng + increaseLng],
                {
                  icon: iconPolygon,
                  _zIndex: 1000
                }).addTo(state.polygonsLayer as any);

                increaseLat += 0.0002
                increaseLng += 0.0009
              }                  

            });
          }  
        }
        else
        {
            const bounds = polygon.getBounds();
            const center = bounds.getCenter();

            // Add label
            L.marker([center.lat - 0.0001, center.lng], {
              icon: L.divIcon({
                className: `polygon-label ${hasUnsavedChanges ? 'unsaved' : ''}`,
                html: `
                  <div class="polygon-label-content">
                    <div class="polygon-name text-dark" style='color:black; margin-top:10px'>${itemDetails.name}${hasUnsavedChanges ? '*' : ''}</div>
                  </div>
                `
              })
            }).addTo(state.polygonsLayer as any);
        }

      
        //SONTH thêm hành động vào item
        addItemAction(polygon, feature);
        state.polygonsLayer?.addLayer(polygon)

        // Sự kiện on click show modal
        // if(props.lastNameUrl && props.lastNameUrl == "mapSample" && props.lastNameUrl != '' && state.currentMode !== 'move')
        // {
        //   polygon.on('click', () => showEditModal(polygon, id, 'Polygon'));
        // }   
}

/**
 * Render icon marker not in VMS
 */
 const renderIconMarkerNotInVMS = (feature:any, objectRender: RenderMap) => {

    const itemDetails = objectRender.itemDetails;

    const selectedEquipmentId = feature.properties.id;
    //const incidentZoneData = await getAPI(TmsTrafficInfoApi).apiTmsTrafficinfoGetequipmenttypebyequipmentidEquipmentIdGet(selectedEquipmentId);
    const equipemnt = mapStore.equipmentList.find((equipment:any) => equipment.id == selectedEquipmentId);
    const equipemntType = mapStore.equipmentTypeList.find((equipmentType :any) => equipmentType?.id == equipemnt?.equipmentTypeId);

    // Lấy url Image
    const iconUrlImage = mapStore.baseUrl +'/'+ itemDetails?.iconUrl + '?&t=' +  state.randomFourNumber;


    // Lấy icon url dựa trên trạng thái thiết bị
    let iconUrlBaseOnStatusEquipment;

    // Kiểm url để render
    const isLastNameUrlOrEmpty = props.lastNameUrl == "mapSample" || props.lastNameUrl == ''

    // Cho tmsMapLocation
    if(isLastNameUrlOrEmpty)
    {
      iconUrlBaseOnStatusEquipment =  equipemntType?.equipmentType?.defaultIcon;
    }

    // Cho TrafficInfo
    else
    {
      switch(equipemnt?.equipmentState)
      {
        case 1:
          iconUrlBaseOnStatusEquipment = mapStore.baseUrl +'/'+ equipemntType?.activeIcon + '?&t=' +  state.randomFourNumber;
          break; 
        case 2:
          iconUrlBaseOnStatusEquipment = mapStore.baseUrl +'/'+ equipemntType?.inactiveIcon + '?&t=' +  state.randomFourNumber;                
          break; 
        default:
          iconUrlBaseOnStatusEquipment = mapStore.baseUrl +'/'+ equipemntType?.faultIcon + '?&t=' +  state.randomFourNumber;;              
          break;
      }          
    }

    
    ///
    const iconMarker = L.icon({
        iconUrl: isLastNameUrlOrEmpty ? iconUrlImage  : iconUrlBaseOnStatusEquipment,
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32]
    })           
    ///
    return iconMarker
 }


/**
 * Render icon marker in unit
 */
 const renderIconMarkerInUnitType = (objectRender: RenderMap) => {     

      // Get item detail
      const itemDetails = objectRender.itemDetails;

      // Get icon work_unit_type from config params
      const valueFromSysConfigWorkUnitType = mapStore.workUnitTypeList.find(m => m.code == itemDetails?.type)?.value

      if(valueFromSysConfigWorkUnitType && valueFromSysConfigWorkUnitType != '')
      {
        itemDetails.iconUrl = valueFromSysConfigWorkUnitType
        //console.log("itemDetails", itemDetails)
      }

      const iconUrlImage = mapStore.baseUrl +'/'+ itemDetails?.iconUrl + '?&t=' +  state.randomFourNumber;

      const iconMarker = L.icon({
             iconUrl: (iconUrlImage == '') ? Image : iconUrlImage,
             iconSize: [32, 32],
             iconAnchor: [16, 32],
             popupAnchor: [0, -32]
         })           

      return iconMarker
 }

 /**
 * Add marker
 */
const addMarkerToMap = (feature: any,  iconMarker: L.DivIcon | L.Icon<L.IconOptions>, objectRender: RenderMap) => {

  const id = objectRender.id;
  const hasUnsavedChanges = objectRender.hasUnsavedChanges;
  const itemDetails = objectRender.itemDetails;

  const [lng, lat] = feature.geometry.coordinates

  const marker = L.marker([lat, lng], {
      icon: iconMarker,
      draggable: false,
      id: feature.properties?.id
    })

 // Add label with details from itemDetails
 L.marker([lat - 0.0001, lng], {
       icon: L.divIcon({
         className: `marker-label ${hasUnsavedChanges ? 'unsaved' : ''}`,
         html: `
           <div class="marker-label-content pb-10" >
             <div class="marker-name text-dark" style='color:black; margin-top:10px;transform: translate(-50px, -50px);width: 135px;white-space: pre-line'>${itemDetails.name}${hasUnsavedChanges ? '*' : ''}</div>
             ${itemDetails.measurement ? 
               `<div class="marker-measurement" style='color:black; margin-top:10px'>${itemDetails.measurement} ${itemDetails.unit || ''}</div>` 
               : ''}
           </div>
         `
       })
     }).addTo(state.markersLayer);

  // Check current mode is move then add event dragend
  if (state.currentMode === 'move' && id === state.activeFeatureId)
  {
      marker.options.draggable = true;
      marker.on('dragend', (event: any) => {
        const position = event.target.getLatLng();
        updateMarkerPositionInGeoJSON(id, position )
        handleMarkUnsaved(id);
      });            
  }

  // Add event click handler for show modal edit
  // else
  // {
  //   
  //   if(props.lastNameUrl && props.lastNameUrl == "mapSample" && props.lastNameUrl != '')
  //   {
  //     marker.on('click', () => showEditModal(marker, id, 'Point'));   
  //   }     
  // }
  //console.log(marker) 
  //SONTH add item action
  addItemAction(marker, feature)
  state.markersLayer?.addLayer(marker)
}

// Function to get a specific marker layer by its coordinates
function getMarkerLayer(lat: number, lng: number): L.Marker | null {
    let foundMarker: L.Marker | null = null;
    state.markersLayer.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
            const markerLatLng = layer.getLatLng();
            if (markerLatLng.lat === lat && markerLatLng.lng === lng) {
                foundMarker = layer;
            }
        }
    });
    return foundMarker;
}

/**
 * Render marker in VMS
**/

 const renderMarkerVMS = (isLastNameUrlOrEmpty: boolean, feature: any) => { 
      const objectRenderMap : RenderMap = {
          id: '',
          itemGroups: null as any,
          hasUnsavedChanges: false as boolean,
          itemDetails: {} as ItemDetails
        }

      const idFeature = feature.properties?.id;
      const itemGroupInFeature = feature.properties?.itemGroup;

      objectRenderMap.id = idFeature;
      objectRenderMap.itemGroups = itemGroupInFeature;
      objectRenderMap.hasUnsavedChanges = state.unsavedChanges.has(idFeature);
      objectRenderMap.itemDetails =mapStore.getItemDetails(idFeature, itemGroupInFeature);

      // Refresh iconMarker
      
       // Check lấy icon hiển thị trên map
       let iconMarker;
       ////
       // Get equipment type and icon
       
       if (feature.properties.itemGroup == TmsMapLocationRefType.Equipment)
       {
         const selectedEquipmentId = feature.properties.id;
         //const incidentZoneData = await getAPI(TmsTrafficInfoApi).apiTmsTrafficinfoGetequipmenttypebyequipmentidEquipmentIdGet(selectedEquipmentId);
         const equipemnt = mapStore.equipmentList.find((equipment:any) => equipment.id == selectedEquipmentId);
         const equipemntType = mapStore.equipmentTypeList.find((equipmentType :any) => equipmentType?.id == equipemnt?.equipmentTypeId);      
          
          // Get current map to check mode map
         const currentMap = mapStore.mapList.find(item => item.id === props?.selectedMapId);
                     
        // Nếu thiết bị là VMS
        if (currentMap && currentMap?.mode === TmsTrafficInfoMap.Vms
             && equipemntType?.code === TmsEquipmentType.Vms ) 
        {
            // Get latitude and longtitude
            const [lng, lat] = feature.geometry.coordinates

            // remove marker VMS exist before add new            
            const specificMarkerVMS = getMarkerLayer(lat, lng) as L.Layer;
            state.markersLayer.removeLayer(specificMarkerVMS);                  
            
            // Remove label marker VMS
            const labelMarkerVMS = getMarkerLayer(lat - 0.0001, lng) as L.Layer;
            if(labelMarkerVMS)
            {
              //console.log("labelMarkerVMS", labelMarkerVMS)
              state.markersLayer.removeLayer(labelMarkerVMS);      
            }

            // Render iconMarker to display Image in VMS
            iconMarker = renderIconMarkerInVMS(feature, equipemnt);
            // Khai báo tạo marker để add vào map
            addMarkerToMap(feature, iconMarker, objectRenderMap);
        }            
       }     
      
 }

/**
 * Render marker
 */
 const renderMarker = (isLastNameUrlOrEmpty: boolean, feature: any) => {
      const objectRenderMap : RenderMap = {
          id: '',
          itemGroups: null as any,
          hasUnsavedChanges: false as boolean,
          itemDetails: {} as ItemDetails
        }

      const idFeature = feature.properties?.id;
      const itemGroupInFeature = feature.properties?.itemGroup;

      objectRenderMap.id = idFeature;
      objectRenderMap.itemGroups = itemGroupInFeature;
      objectRenderMap.hasUnsavedChanges = state.unsavedChanges.has(idFeature);
      objectRenderMap.itemDetails =mapStore.getItemDetails(idFeature, itemGroupInFeature);

      // const id = feature.properties?.id;
      // const itemGroup = feature.properties?.itemGroup;
      // const hasUnsavedChanges = state.unsavedChanges.has(id);
      // const itemDetails = mapStore.getItemDetails(id, itemGroup);

     // console.log("workUnitTypeList", mapStore.workUnitTypeList);

      // Get icon work_unit_type from config params
      const valueFromSysConfigWorkUnitType = mapStore.workUnitTypeList.find(m => m.code == objectRenderMap.itemDetails?.type)?.value

      if(valueFromSysConfigWorkUnitType && valueFromSysConfigWorkUnitType != '')
      {
        objectRenderMap.itemDetails.iconUrl = valueFromSysConfigWorkUnitType
        //console.log("itemDetails", itemDetails)
      }
      
      const iconUrlImage = mapStore.baseUrl +'/'+ objectRenderMap.itemDetails?.iconUrl + '?&t=' +  state.randomFourNumber;     

       // Check lấy icon hiển thị trên map
       let iconMarker;
       ////
       // Get equipment type and icon
       
       if (feature.properties.itemGroup == TmsMapLocationRefType.Equipment)
       {
         const selectedEquipmentId = feature.properties.id;
         //const incidentZoneData = await getAPI(TmsTrafficInfoApi).apiTmsTrafficinfoGetequipmenttypebyequipmentidEquipmentIdGet(selectedEquipmentId);
         const equipemnt = mapStore.equipmentList.find((equipment:any) => equipment.id == selectedEquipmentId);
         const equipemntType = mapStore.equipmentTypeList.find((equipmentType :any) => equipmentType?.id == equipemnt?.equipmentTypeId);      
          
          // Get current map to check mode map
         const currentMap = mapStore.mapList.find(item => item.id === props?.selectedMapId);
                     
        // Nếu thiết bị là VMS
        if (currentMap && currentMap?.mode === TmsTrafficInfoMap.Vms
             && equipemntType?.code === TmsEquipmentType.Vms ) 
        {
            // Render iconMarker to display Image in VMS
            iconMarker = renderIconMarkerInVMS(feature, equipemnt);
        }           
        else
        {
             iconMarker = renderIconMarkerNotInVMS(feature, objectRenderMap);

             // Lấy icon url dựa trên trạng thái thiết bị
            //  let iconUrlBaseOnStatusEquipment;

            //  // Cho tmsMapLocation
            //  if(isLastNameUrlOrEmpty)
            //  {
            //    iconUrlBaseOnStatusEquipment =  equipemntType?.equipmentType?.defaultIcon;
            //  }

            //  // Cho TrafficInfo
            //  else
            //  {
            //    switch(equipemnt?.equipmentState)
            //    {
            //      case 1:
            //        iconUrlBaseOnStatusEquipment = mapStore.baseUrl +'/'+ equipemntType?.activeIcon + '?&t=' +  state.randomFourNumber;
            //        break; 
            //      case 2:
            //        iconUrlBaseOnStatusEquipment = mapStore.baseUrl +'/'+ equipemntType?.inactiveIcon + '?&t=' +  state.randomFourNumber;                
            //        break; 
            //      default:
            //        iconUrlBaseOnStatusEquipment = mapStore.baseUrl +'/'+ equipemntType?.faultIcon + '?&t=' +  state.randomFourNumber;;              
            //        break;
            //    }          
            //  }

            //   ///
            //   iconMarker = L.icon({
            //       iconUrl: isLastNameUrlOrEmpty ? iconUrlImage  : iconUrlBaseOnStatusEquipment,
            //       iconSize: [32, 32],
            //       iconAnchor: [16, 32],
            //       popupAnchor: [0, -32]
            //   })           
              ///
           }
           /////
       }
       // Nếu là work_unit_type
       else
       {
          //console.log("Vào icon default - UNIT")
         ///
         iconMarker = renderIconMarkerInUnitType(objectRenderMap);        
         ///
       }
        // Khai báo tạo marker để add vào map
        addMarkerToMap(feature, iconMarker, objectRenderMap);

        // const [lng, lat] = feature.geometry.coordinates
        // const marker = L.marker([lat, lng], {
        //     icon: iconMarker,
        //     draggable: false,
        //     id: feature.properties?.id
        //   })

        //   // Add label with details from itemDetails
        //   L.marker([lat - 0.0001, lng], {
        //     icon: L.divIcon({
        //       className: `marker-label ${hasUnsavedChanges ? 'unsaved' : ''}`,
        //       html: `
        //         <div class="marker-label-content pb-10" >
        //           <div class="marker-name text-dark" style='color:black; margin-top:10px;transform: translate(-50px, -50px);width: 135px;white-space: pre-line'>${itemDetails.name}${hasUnsavedChanges ? '*' : ''}</div>
        //           ${itemDetails.measurement ? 
        //             `<div class="marker-measurement" style='color:black; margin-top:10px'>${itemDetails.measurement} ${itemDetails.unit || ''}</div>` 
        //             : ''}
        //         </div>
        //       `
        //     })
        //   }).addTo(state.markersLayer);

        //   // Check current mode is move then add event dragend
        //   if (state.currentMode === 'move' && id === state.activeFeatureId)
        //   {
        //      marker.options.draggable = true;
        //      marker.on('dragend', (event: any) => {
        //        const position = event.target.getLatLng();
        //        updateMarkerPositionInGeoJSON(id, position )
        //        handleMarkUnsaved(id);
        //      });            
        //   }
        //   else
        //   {
        //     // Add event click handler for show modal edit
        //     if(props.lastNameUrl && props.lastNameUrl == "mapSample" && props.lastNameUrl != '')
        //     {
        //       marker.on('click', () => showEditModal(marker, id, 'Point'));   
        //     }     
        //   }
        //   //console.log(marker) 
        //   //SONTH add item action
        //   addItemAction(marker, feature)
        //   state.markersLayer?.addLayer(marker)
 }

/**
 * Render lại map
 */
const renderGeoJson = async (item: any = null ) => {  
  handleLoadZoneStatus();

  // Check tồn tại map và các layer
  if (!state.map || !state.markersLayer || !state.polygonsLayer) return

  state.markersLayer.clearLayers()
  state.polygonsLayer.clearLayers() 
  clearHighlight() 

  // Lấy dữ liệu eventType trước khi vô vòng lặp
  //await mapStore.fetchEventTypeData();

  //console.log("renderGeoJson- mapStore.incidentZoneDataExistInTrafficInfoList", mapStore.incidentZoneDataExistInTrafficInfoList)

  // Create variable check condition before loop
  const isExistIncidentZoneDataExistInTrafficInfoList = mapStore.incidentZoneDataExistInTrafficInfoList && mapStore.incidentZoneDataExistInTrafficInfoList.length > 0
  //TODO: truyền vào dạng màn hình đang xử lý
  const isLastNameUrlOrEmpty = props.lastNameUrl == "mapSample" || props.lastNameUrl == ''

  // Loop trong dữ liệu geoJsonDat để setup map
  state.geoJsonData.features.forEach(async (feature: any) => {      
    try
    {
      const id = feature.properties?.id;
      const itemGroup = feature.properties?.itemGroup;
      const hasUnsavedChanges = state.unsavedChanges.has(id);
      const itemDetails = mapStore.getItemDetails(id, itemGroup);

     // console.log("workUnitTypeList", mapStore.workUnitTypeList);

      // Get icon work_unit_type
      const valueFromSysConfigWorkUnitType = mapStore.workUnitTypeList.find(m => m.code == itemDetails?.type)?.value

      if(valueFromSysConfigWorkUnitType && valueFromSysConfigWorkUnitType != '')
      {
        itemDetails.iconUrl = valueFromSysConfigWorkUnitType
        //console.log("itemDetails", itemDetails)
      }
      
      //Xử lý hiển thị marker - Icon thiết bị, item, ...
      if (feature.geometry.type === 'Point') 
      {
        renderMarker(isLastNameUrlOrEmpty, feature)       
      //   const selectedEquipmentId = feature.properties.id;
      //   const equipment = mapStore.equipmentList.find(item => item.id === selectedEquipmentId);

      //   // Check lấy icon hiển thị trên map
      //   let iconMarker;
      //   ////
      //   // Get equipment type and icon
        
      //   if (feature.properties.itemGroup == TmsMapLocationRefType.Equipment)
      //   {
      //     //const incidentZoneData = await getAPI(TmsTrafficInfoApi).apiTmsTrafficinfoGetequipmenttypebyequipmentidEquipmentIdGet(selectedEquipmentId);
      //     const equipemnt = mapStore.equipmentList.find((equipment:any) => equipment.id == selectedEquipmentId);
      //     const equipemntType = mapStore.equipmentTypeList.find((equipmentType :any) => equipmentType?.id == equipemnt?.equipmentTypeId);
        
      //     // Lấy icon url dựa trên trạng thái thiết bị
      //     let iconUrlBaseOnStatusEquipment;

      //     // Cho tmsMapLocation
      //     if(isLastNameUrlOrEmpty)
      //     {
      //       iconUrlBaseOnStatusEquipment =  equipemntType?.equipmentType?.defaultIcon;
      //     }
      //      // Cho TrafficInfo
      //     else
      //     {
      //       switch(equipemnt?.equipmentState)
      //       {
      //         case 1:
      //           iconUrlBaseOnStatusEquipment = mapStore.baseUrl +'/'+ equipemntType?.activeIcon + '?&t=' +  state.randomFourNumber;
      //           break; 
      //         case 2:
      //           iconUrlBaseOnStatusEquipment = mapStore.baseUrl +'/'+ equipemntType?.inactiveIcon + '?&t=' +  state.randomFourNumber;                
      //           break; 
      //         default:
      //           iconUrlBaseOnStatusEquipment = mapStore.baseUrl +'/'+ equipemntType?.faultIcon + '?&t=' +  state.randomFourNumber;;              
      //           break;
      //       }          
      //     }
            
      //      const currentMap = mapStore.mapList.find(item => item.id === props?.selectedMapId);

      //      const currentVms =   mapStore.vmsCurrentList.find((item: any)=> item.equipmentId === feature.properties.id);   
          
            
      //      // Nếu thiết bị là VMS
      //     if (currentMap && currentMap?.mode === TmsTrafficInfoMap.Vms
      //        && equipemntType?.code === TmsEquipmentType.Vms ) 
      //     {

      //       //console.log("LEAFMAP - curentMap.mode", currentMap?.mode)
      //       //console.log("LEAFMAP - currentVms", currentVms)
          
      //       // Render iconMarker to display Image in VMS
      //       iconMarker = renderIconMarkerInVMS(feature, equipemnt, currentVms);

      //       //   iconMarker = L.divIcon({
      //       //   className: 'custom-div-icon', // Add your custom class here
      //       //   html: `
      //       //     <div style="text-align: center; background-color: transparent; margin-left: -45px">
      //       //       <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 841.89 490.28"
      //       //         style="height: 3vw; width: 6vw; scale: 2;max-width: 200px">
      //       //         <g>
      //       //             <linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="10.124" y1="294.8612" x2="831.7664" y2="294.8612">
      //       //                 <stop offset="0.1275" style="stop-color:#6CB0D0" />
      //       //                 <stop offset="0.2104" style="stop-color:#9ABDD5" />
      //       //                 <stop offset="0.2972" style="stop-color:#BCC6D8" />
      //       //                 <stop offset="0.3773" style="stop-color:#D2CCD9" />
      //       //                 <stop offset="0.4475" style="stop-color:#DFD0DA" />
      //       //                 <stop offset="0.5001" style="stop-color:#E3D1DB" />
      //       //                 <stop offset="0.5407" style="stop-color:#E0CFDA" />
      //       //                 <stop offset="0.59" style="stop-color:#D6CAD9" />
      //       //                 <stop offset="0.6438" style="stop-color:#C6C2D7" />
      //       //                 <stop offset="0.7008" style="stop-color:#ADB6D4" />
      //       //                 <stop offset="0.7603" style="stop-color:#87A6CF" />
      //       //                 <stop offset="0.8211" style="stop-color:#4992C9" />
      //       //                 <stop offset="0.8422" style="stop-color:#228BC7" />
      //       //             </linearGradient>
      //       //             <path   style="background:black;fill: ${equipment.equipmentState === 1 ? 'url(#SVGID_1_)' : '#E30613'};"
      //       //                   d="M786.38,168.79H55.51c-25.07,0-45.39,20.32-45.39,45.39v161.37c0,25.07,20.32,45.39,45.39,45.39h730.87c25.07,0,45.39-20.32,45.39-45.39V214.18C831.77,189.11,811.45,168.79,786.38,168.79z M811.52,375.54c0,13.86-11.28,25.14-25.14,25.14H55.51c-13.86,0-25.14-11.28-25.14-25.14V214.18c0-13.86,11.28-25.14,25.14-25.14h730.87c13.86,0,25.14,11.28,25.14,25.14V375.54z" />
                        
      //       //             <image xlink:href="${state.queryParams.itemId === feature.properties.id ? undefined : (currentVms ? mapStore.baseUrl +'/'+ currentVms.url : '')}" x="40" y="200" width="760.88" height="200"></image>
                        
      //       //             <g>
      //       //                 <path style="fill:#7CC1A0;" d="M106.13,168.79H55.51c-25.07,0-45.39,20.32-45.39,45.39l0,50.62c0,2.8-2.27,5.06-5.06,5.06S0,267.6,0,264.8v-50.62c0-30.61,24.9-55.52,55.51-55.52h50.62c2.8,0,5.06,2.27,5.06,5.06S108.93,168.79,106.13,168.79z" />
      //       //                 <path style="fill:#7CC1A0;" d="M735.76,168.79h50.62c25.07,0,45.39,20.32,45.39,45.39l0,50.62c0,2.8,2.27,5.06,5.06,5.06s5.06-2.27,5.06-5.06v-50.62c0-30.61-24.9-55.52-55.51-55.52h-50.62c-2.8,0-5.06,2.27-5.06,5.06S732.96,168.79,735.76,168.79z" />
      //       //                 <path style="fill:#7CC1A0;" d="M106.13,420.93H55.51c-25.07,0-45.39-20.32-45.39-45.39l0-50.62c0-2.8-2.27-5.06-5.06-5.06S0,322.12,0,324.92l0,50.62c0,30.61,24.9,55.52,55.51,55.52h50.62c2.8,0,5.06-2.27,5.06-5.06S108.93,420.93,106.13,420.93z" />
      //       //                 <path style="fill:#7CC1A0;" d="M735.76,420.93h50.62c25.07,0,45.39-20.32,45.39-45.39l0-50.62c0-2.8,2.27-5.06,5.06-5.06s5.06,2.27,5.06,5.06v50.62c0,30.61-24.9,55.52-55.51,55.52h-50.62c-2.8,0-5.06-2.27-5.06-5.06S732.96,420.93,735.76,420.93z" />
      //       //             </g>
      //       //         </g>
      //       //     </svg>                
      //       //     </div>
      //       //   `,
      //       //   iconSize: [32, 42],  // Total size of the icon + label
      //       //   iconAnchor: [16, 32], // Anchor point of the icon
      //       //   popupAnchor: [0, -32] // Anchor point of the popup
      //       // });
      //       ////
      //      }
            
      //      else
      //      {
      //         ///
      //         iconMarker = L.icon({
      //             iconUrl: isLastNameUrlOrEmpty ? iconUrlImage  : iconUrlBaseOnStatusEquipment,
      //             iconSize: [32, 32],
      //             iconAnchor: [16, 32],
      //             popupAnchor: [0, -32]
      //         })           
      //         ///
      //      }
      //      /////
      //  }
      //  // Nếu là work_unit_type
      //  else
      //  {
      //     //console.log("Vào icon default - UNIT")

      //    ///
      //    iconMarker = L.icon({
      //        iconUrl: (iconUrlImage == '') ? Image : iconUrlImage,
      //        iconSize: [32, 32],
      //        iconAnchor: [16, 32],
      //        popupAnchor: [0, -32]
      //    })           
      //    ///
      //  }
      //   // Khai báo tạo marker để add vào map
      //   const [lng, lat] = feature.geometry.coordinates
      //   const marker = L.marker([lat, lng], {
      //       icon: iconMarker,
      //       draggable: false,
      //       id: feature.properties?.id
      //     })


      //     // Add label with details from itemDetails
      //     L.marker([lat - 0.0001, lng], {
      //       icon: L.divIcon({
      //         className: `marker-label ${hasUnsavedChanges ? 'unsaved' : ''}`,
      //         html: `
      //           <div class="marker-label-content pb-10" >
      //             <div class="marker-name text-dark" style='color:black; margin-top:10px;transform: translate(-50px, -50px);width: 135px;white-space: pre-line'>${itemDetails.name}${hasUnsavedChanges ? '*' : ''}</div>
      //             ${itemDetails.measurement ? 
      //               `<div class="marker-measurement" style='color:black; margin-top:10px'>${itemDetails.measurement} ${itemDetails.unit || ''}</div>` 
      //               : ''}
      //           </div>
      //         `
      //       })
      //     }).addTo(state.markersLayer);

      //     if (state.currentMode === 'move' && id === state.activeFeatureId)
      //     {
      //        marker.options.draggable = true;
      //        marker.on('dragend', (event: any) => {
      //          const position = event.target.getLatLng();
      //          updateMarkerPositionInGeoJSON(id, position )
      //          handleMarkUnsaved(id);
      //        });            
      //     }
      //     else
      //     {
      //       // Add click handler for editing
      //       if(props.lastNameUrl && props.lastNameUrl == "mapSample" && props.lastNameUrl != ''){
      //       marker.on('click', () => showEditModal(marker, id, 'Point'));   
      //     }     
      //     }
      //     //////console.log(marker) 
      //     //SONTH add item action
      //     addItemAction(marker, feature)
      //     state.markersLayer?.addLayer(marker)
                  
      }
      // Xử lý hiển thị polygon - zone
      else if (feature.geometry.type === 'Polygon') 
      {
        renderPolygon(feature,hasUnsavedChanges,itemDetails);     
      }
    
      // If this is the active feature (being edited or moved)
    if (feature.properties?.id === item?.activeLayerId && state.currentMode) 
    {        
      setTimeout(() => {
        state.polygonsLayer.eachLayer((layer: any) => {
        if (layer.feature?.properties?.id === item?.activeLayerId || 
              layer.options?.id === item?.activeLayerId) 
        {
            // Update layer with current coordinates if available
            if (state.currentCoordinates && feature.geometry.type === 'Polygon') {
              const latLngs = state.currentCoordinates[0].map(([lng, lat]: number[]) => [lat, lng]);
              layer.setLatLngs(latLngs);

            }

            // Re-enable the appropriate mode
            if (state.currentMode === 'edit') {
              layer.pm.enable({
                allowSelfIntersection: false,
                preventMarkerRemoval: true,
                mode: 'Edit',
                vertexStyle: {
                  color: '#ff4444',
                  fillColor: '#ff4444',
                  fillOpacity: 1,
                  radius: 6,
                  weight: 2
                },
                middleMarkerStyle: {
                  color: '#4444ff',
                  fillColor: '#4444ff',
                  fillOpacity: 1,
                  radius: 4,
                  weight: 2
                }
              });

              // Reattach edit event listeners
              layer.on('pm:vertexadded pm:vertexremoved pm:vertexclick pm:markerdragend', (e: any) => {
                const updatedCoords = e.target.getLatLngs()[0].map((latLng: L.LatLng) => [latLng.lng, latLng.lat]);
                feature.geometry.coordinates = [updatedCoords];
                state.currentCoordinates = [updatedCoords];
                handleMarkUnsaved(item?.activeLayerId);
              });

            } 
            else if (state.currentMode === 'move') {
                layer.pm.enable({
                  allowSelfIntersection: false,
                  preventMarkerRemoval: true,
                  draggable: true,
                  snappable: false,
                  snapDistance: 0,
                  tooltips: false,
                  requireSnapToFinish: false,
                  allowEditing: false,
                  allowRemoval: false,
                  allowRotation: false,
                  allowCutting: false,
                  allowSplitting: false,
                  addVertexOn: 'none',
                  removeVertexOn: 'none',
                  removeVertexPolygon: false,
                });
              }
            
             state.editingLayer = layer;
            }
         });
        }, 0);
     }    
    }
    catch(error)
    {
      console.log("error", error)
    }
  
    // Kêt thúc foreach
  })

}

/*
  Load danh sách trạng thái zone
  Author: SonTH
  Date: 2025/02/27
*/
const handleLoadZoneStatus = async () => {
  const response = await getAPI(TmsZoneStatusApi).apiTmsTmszonestatusListGet();
  state.listZoneStatus = response.data.result;
  // state.trafficStatusConfig = getOpConfigByGroupCode('operation_config');
}

/*
 Xử lý Trạng thái giao thông
 Author: SonTH
 Date: 2025/02/27
 */
const handleZoneStatus = async ( polygon: any) => {

  // if(state.listZoneStatus.length == 0)
  // {
  //   await handleLoadZoneStatus();
  // }
  //console.log("handleZoneStatus - state.listZoneStatus", polygon)
  //lấy thông tin zone status bởi zone id
  const zoneStatus = state.listZoneStatus.find((item: any) => item.zoneId == polygon.options.id)
  //Load css color from var(--el-color-primary)
  const color = getComputedStyle(document.documentElement).getPropertyValue('--el-color-success');
  const dangerColor = getComputedStyle(document.documentElement).getPropertyValue('--el-color-danger');
  const warningColor = getComputedStyle(document.documentElement).getPropertyValue('--el-color-warning');

  polygon.setStyle({
    smoothFactor: 1,
    weight: 3,
    opacity: 0.9,
    fillOpacity: 0.7,
  })
  if(zoneStatus == null)
  {
    polygon.setStyle({
      fillColor:  color,
      color: color,
    }); 
  }else{
    switch(zoneStatus?.condition){
      case 'slow':
      polygon.setStyle({                
        fillColor:  warningColor,
        color: warningColor,
      }); 
      break;

      case 'congestion':
        polygon.setStyle({                    
          fillColor:  dangerColor,
          color: dangerColor,
        }); 
        break;

      case 'normal':
        polygon.setStyle({                    
          fillColor:  color,
          color: color,
        }); 
        break;

      default:
        polygon.setStyle({                    
          fillColor:  color,
          color: color,
        }); 
        break;
    }   
  }

  //handle traffic status event

  // var stackedIcon = L.divIcon({
  //               className: 'custom-stack-icon',
  //               html: `
  //                   <div class="custom-stack-icon">
  //                       <img src="https://cdn-icons-png.flaticon.com/128/252/252025.png" style="width: 12px; height: 12px;" class="icon-1">
  //                   </div>
  //               `,
  //               iconSize: [32, 32],
  //               iconAnchor: [0, 12] // Adjust anchor so it aligns correctly
  //           });
  //           const bounds2 = polygon.getBounds();
  //           const center2 = bounds2.getCenter() ;
  //           L.marker([center2.lat , center2.lng - 0.001],
  //               {
  //                 icon: stackedIcon,
  //               }).addTo(state.polygonsLayer as any);

}




// Add item action to item on map
const addItemAction = (marker: any, feature: any) => {
  //on click
  marker.on('click', () => emit('item-action', { action: 'click', itemId: feature.properties?.id, itemGroup: feature.properties?.itemGroup} as IMapItemAction));
  //on mouseover
  marker.on('mouseover', () => emit('item-action', { action: 'mouseover', itemId: feature.properties?.id, itemGroup: feature.properties?.itemGroup} as IMapItemAction));
  //on dblclick
  marker.on('dblclick', () => emit('item-action', { action: 'dblclick', itemId: feature.properties?.id, itemGroup: feature.properties?.itemGroup} as IMapItemAction));
  //on rightclick
  marker.on('rightclick', () => emit('item-action', { action: 'rightclick', itemId: feature.properties?.id, itemGroup: feature.properties?.itemGroup} as IMapItemAction));
  //on mouseout
  marker.on('mouseout', () => emit('item-action', { action: 'mouseout', itemId: feature.properties?.id, itemGroup: feature.properties?.itemGroup} as IMapItemAction));
}


const clearLayers = () => {
  if (state.tileLayer && state.map) {
    state.map?.removeLayer(state.tileLayer)
    state.tileLayer = null
  }
  if (state.imageOverlay && state.map) {
    state.map?.removeLayer(state.imageOverlay)
    state.imageOverlay = null
  }
  if (state.markersLayer) {
    state.markersLayer.clearLayers()
  }
  if (state.polygonsLayer) {
    state.polygonsLayer.clearLayers()
  }
}

const loadMapData = async (mapId: string) => {
  if (!mapId || !state.map) return

  try {
    clearLayers()
    const tmsMapLocationResponse = await getAPI(TmsMapLocationApi).apiTmsTmsmaplocationListGet()
    const tmsMapLocation = tmsMapLocationResponse?.data?.result?.find((item: any) => item.mapId === mapId)

    if(mapStore.mapList && mapStore.mapList.length < 1){
      await mapStore.fetchMapList();
    }
    const map_config = mapStore.mapList.find((item:any) => item.id == mapId)   

    if (!map_config) {
      console.error('Map configuration not found')
      return
    }

    const mapUrl = map_config.url
    if (!mapUrl) {
      console.error('Invalid map URL')
      return
    }

    // Parse saved view state with default values
    let viewState : MapViewState = {
      center: [10.89484, 107.47839] as [number, number],
      zoom: 14,
      maxZoom: 18,
      minZoom: 1
    }

    // Lấy view sate gồm tọa độ và chỉ số zoom
    if (tmsMapLocation?.config && tmsMapLocation.config != null) {
      try {
        const savedState = JSON.parse(tmsMapLocation.config)
        console.log("loadMap - savedState", savedState )

        if (savedState && 
            Array.isArray(savedState.center) && 
            savedState.center.length === 2 && 
            typeof savedState.zoom === 'number'
          )
          {
              viewState = {
                  center: savedState.center,
                  zoom: savedState.zoom,
                  minZoom: savedState.minZoom != undefined ? savedState.minZoom : savedState.zoom,
                  maxZoom: savedState.maxZoom != undefined ? savedState.maxZoom : savedState.zoom
              }
          }
      } catch (e) {
        console.warn('Invalid view state in map.remark:', e)
      }
    }

    // asign view state 
    state.mapViewState = {...viewState}

    //console.log("loadMap - state.mapViewState", state.mapViewState )

    switch (map_config.type) {
      case 'offline': { // Offline map
        await loadOnlineMap(map_config, viewState)
        break
      }
      case 'online': { // Online map
        await loadOnlineMap(map_config, viewState)
        break
      }
      case 'image': { // Image map
        await loadImageMap(map_config, viewState)
        break
      }
      default:
        console.error('Unsupported map type:', map_config.type)
        return
    }

    //console.log("loadMap - locationResponse - start")

    // Load GeoJSON data
    const locationResponse = await getAPI(TmsMapLocationApi).apiTmsTmsmaplocationDatalistIdGet(mapId)
    //console.log("loadMap - locationResponse", locationResponse)
    const mapLocationData = locationResponse?.data?.result?.[0]    
    state.tmsLocationMapId = mapLocationData?.id

    if (mapLocationData?.geoJsonContent && mapLocationData.geoJsonContent != null) {
      state.geoJsonData = JSON.parse(mapLocationData.geoJsonContent)
      await new Promise(resolve => setTimeout(resolve, 150))
      renderGeoJson()
    } 
    else 
    {     
      state.geoJsonData = { type: "FeatureCollection", features: [] }      
      renderGeoJson()
    }

     // Return Geo data json into component map control
     ReturnGeoDataJsonToComponentIndex();  

  } catch (error) {
    console.error('Failed to load map data:', error)
  }
}

const loadOnlineMap = async (map_config: any, viewState: MapViewState) => {
  state.map!.options.crs = L.CRS.EPSG3857

  const minZoom = (viewState.minZoom != undefined) ? viewState.minZoom : 1
  const maxZoom = (viewState.minZoom != undefined) ? viewState.maxZoom : 18

  state.tileLayer = L.tileLayer(map_config.url, {
    minZoom: minZoom,
    maxZoom: maxZoom
  })

  //console.log("state.tileLayer", state.tileLayer)

  state.tileLayer.addTo(state.map!)

  state.map!.setMinZoom(minZoom)
  state.map!.setMaxZoom(maxZoom)
  state.map!.setMaxBounds(undefined)
  state.map!.setView(viewState.center, viewState.zoom, { animate: false })
}

const loadImageMap = async (map_config: any, viewState: any) => {
  state.map!.options.crs = L.CRS.Simple

  // Calculate image bounds
  const width = map_config.width || 1000
  const height = map_config.height || 1000
  const southWest = state.map!.unproject([0, height], 0)
  const northEast = state.map!.unproject([width, 0], 0)
  const bounds = new L.LatLngBounds(southWest, northEast)

  // Create and add image overlay
  const imageMap = mapStore.baseUrl + '/' + map_config.url + '?&t='

  state.imageOverlay = L.imageOverlay(imageMap, bounds)
  state.imageOverlay.addTo(state.map!)

  // Set zoom constraints
  const maxZoom = Math.ceil(Math.log2(Math.max(width, height) / 256)) + 1
  state.map!.setMinZoom(-2)
  state.map!.setMaxZoom(maxZoom)

  // Set initial view
  if (map_config.remark && viewState.center) {
    state.map!.setView(viewState.center, viewState.zoom, { animate: false })
  } else {
    state.map!.fitBounds(bounds, { 
      padding: [50, 50],
      maxZoom: maxZoom - 2
    })
    
    // Save initial center and zoom after fitting bounds
    const center = state.map!.getCenter()
    const zoom = state.map!.getZoom()
    viewState.center = [center.lat, center.lng]
    viewState.zoom = zoom
  }

  // Allow dragging beyond bounds but with elastic bounce
  state.map!.setMaxBounds(bounds.pad(0.5))
  state.map!.on('drag', () => {
    state.map!.panInsideBounds(bounds, { animate: false })
  })
}

// Add method to save current view state
const saveViewState = () => {
  if (!state.map || !props.selectedMapId) return

  const center = state.map.getCenter()
  const zoom = state.map.getZoom()
  
  return {
    center: [center.lat, center.lng],
    zoom: zoom
  }
}

const zoomIn = () => {
  state.map?.zoomIn()
}

const zoomOut = () => {
  state.map?.zoomOut()}

function filterFeaturesByItemGroup(itemGroup: string, listIdFilter:any[]){

  // console.log("filterFeaturesByItemGroup-itemGroup", itemGroup)
  // console.log("state.previousFeatureGeoJsonDataZone?", state.previousFeatureGeoJsonDataZone)

    // Get list id in feature json with item group is device
    const listIdInFeatureGeoJson = state.geoJsonData.features.map((feature:any) => {
       if(feature?.properties?.itemGroup == itemGroup){
         return feature?.properties?.id
      }         
    }).filter((item:any) => item != undefined)
    //console.log("listIdInFeatureGeoJson", listIdInFeatureGeoJson)

      // Get list id in previous feature json with item group is device
     // Check exist object in list previous feature json
     const listIdInPreviousFeatureGeoJson = [] as any;
     if(Object.keys(state.previousFeatureGeoJsonData).length !==0){
       state.previousFeatureGeoJsonData.map((feature:any) => {
         if(feature?.properties?.itemGroup == itemGroup){
          listIdInPreviousFeatureGeoJson.push( feature?.properties?.id)
         } 
       })
     }

      // Filter in geoJsonData
      // Remove item if equipmentId not in listIdFilter
    listIdInFeatureGeoJson.forEach((equipmentId:any) => 
    {
       if(!listIdFilter.includes(equipmentId) && equipmentId!= undefined )
       {
         // remove feature from geoJson
         // 1. Find the index equipment to remove
         const indexToRemove = state.geoJsonData?.features.findIndex(feature => 
           feature?.properties.id == equipmentId && feature?.properties?.itemGroup == itemGroup
         );
         
         // 2. Store previouse object remove
         const featureToRemove = state.geoJsonData?.features[indexToRemove];
         ////console.log("featureToRemove",featureToRemove)

         // check not exist in previousFeatureGeoJsonData
         // Then add to list previousFeatureGeoJsonData
         if(listIdInPreviousFeatureGeoJson.length > 0 && !listIdInPreviousFeatureGeoJson.includes(featureToRemove?.properties?.id))
         {
           state.previousFeatureGeoJsonData.push(featureToRemove)         
         } 
         else if(listIdInPreviousFeatureGeoJson.length == 0)
         {
           state.previousFeatureGeoJsonData.push(featureToRemove)
         }

         // 3. remove item from array geoJsonData
         if(indexToRemove > -1)
         {
           state.geoJsonData?.features.splice(indexToRemove, 1)
         }
       }
    })

    //console.log("state.previousFeatureGeoJsonDataZone - AFTER", state.previousFeatureGeoJsonData)
    //console.log("state.previousFeatureGeoJsonDataZone - AFTER - ZONE", state.previousFeatureGeoJsonDataZone)

    // Restore items was remove 
    if(listIdInPreviousFeatureGeoJson && listIdInPreviousFeatureGeoJson.length > 0)
    {
      listIdInPreviousFeatureGeoJson.forEach((equipmentId:any) => {
        if(listIdFilter.includes(equipmentId) && equipmentId!= undefined )
        {
          // remove feature from geoJson
          // 1. Find the feature to add
          const featureToAdd = state.previousFeatureGeoJsonData.find((feature:any) => feature?.properties.id == equipmentId 
                                                                        && feature?.properties?.itemGroup == itemGroup);
          
          // 2. Check if featureGeoJson not include id then add to list geoJsonData
          if(!listIdInFeatureGeoJson.includes(featureToAdd?.properties?.id))
          {
            state.geoJsonData.features.push(featureToAdd)   
          }      

          // 3. Remove into list previousFeatureGeoJsonData
          if(state.previousFeatureGeoJsonData && state.previousFeatureGeoJsonData.length > 0)
          {
             // find index to remove
            const indexToRemove = state.previousFeatureGeoJsonData.findIndex((feature:any) => feature?.properties.id == equipmentId 
                                                                                && feature?.properties?.itemGroup == itemGroup);

            // remove from array previous feature
            state.previousFeatureGeoJsonData.splice(indexToRemove, 1)
          }  
        }
      })
    }       
}

// Watch filer change
watch(() => props.filters, async(newFilter, oldFilter) => { 
  
  // Gen lại random number
  state.randomFourNumber = generateRandomNumber(5);

  if(newFilter != oldFilter){
    state.filterDeviceItems = {...newFilter}
  }

  // Check filterDeviceItems exist change
  if(Object.keys(state.filterDeviceItems).length !== 0){

   // console.log("state.filterDeviceItems", state.filterDeviceItems)

    // Loop every key to get 
    for(const key in state.filterDeviceItems){
      switch(key){
        case 'device':        
        // Get list id equipment exist in filter device
          const listIdInEquipmentTypeFilter_device = mapStore.equipmentList.map((equipment) => {         
            if(equipment.equipmentTypeId != undefined && state.filterDeviceItems.device && state.filterDeviceItems.device.includes(equipment?.equipmentTypeId))
            {
              return equipment?.id
            }
          }).filter((item:any) => item != undefined);
          //console.log("listIdInEquipmentTypeFilter", listIdInEquipmentTypeFilter_device)
          filterFeaturesByItemGroup('device', listIdInEquipmentTypeFilter_device)
          break;
        case 'zone':      
          // Zone được chọn
          if(newFilter?.zone && newFilter?.zone.length > 0 && newFilter?.zone['0'] == 'zone'){
              // Kiểm tra list GeoJson có list polygon hay không
              const isHaveAnyPolygonInFeatures = state.geoJsonData?.features?.some((feature:any) => feature.properties.itemGroup == 'zone')

              // Kiểm tra list previous có 
              if(!isHaveAnyPolygonInFeatures && state.previousFeatureGeoJsonDataZone && state.previousFeatureGeoJsonDataZone.length > 0)
              {            
                state.geoJsonData.features = [...state.geoJsonData.features, ...state.previousFeatureGeoJsonDataZone]
                state.previousFeatureGeoJsonDataZone = []
              }
          }

          // Không tick chọn zone
          else
          {
            //console.log("ZONE - ko TICK")
             // Lưu tất cả feature polygon vào previousFeatureGeoJsonData
            // 1. Lấy tất feature polygon       
            const listFeaturesPolygon = state.geoJsonData?.features.map((feature:any) => {
              if(feature?.properties?.itemGroup == 'zone'){
                return feature
              }
            }).filter((item:any) => item!=undefined);
            //console.log("listFeaturesPolygon", listFeaturesPolygon)

            // 2. store in state previousFeatureGeoJsonData
           // Kiểm tra list previousFeatureGeoJsonData có list polygon hay không
           const isHaveAnyPolygonInFeaturesPreviousZone = state.previousFeatureGeoJsonDataZone?.features?.some((feature:any) => feature.properties.itemGroup == 'zone')
           const isExistListPreviousZone = state.previousFeatureGeoJsonDataZone?.features?.length > 0

           //console.log("state.previousFeatureGeoJsonDataZone?", state.previousFeatureGeoJsonDataZone)
           //console.log("state.previousFeatureGeoJsonDataZone?", isHaveAnyPolygonInFeaturesPreviousZone)


            // if(!isHaveAnyPolygonInFeaturesPrevious && isExistListPrevious)
            // {
            //   state.previousFeatureGeoJsonDataZone = [...state.previousFeatureGeoJsonData?.features, ...listFeaturesPolygon];
            // }       
            // else if(!isHaveAnyPolygonInFeaturesPrevious)
            // {
            //   state.previousFeatureGeoJsonDataZone = [...listFeaturesPolygon]
            // } 

            if(!isHaveAnyPolygonInFeaturesPreviousZone && isExistListPreviousZone)
            {
              state.previousFeatureGeoJsonDataZone = [...state.previousFeatureGeoJsonDataZone?.features,...listFeaturesPolygon];
            }   
            else if(!isHaveAnyPolygonInFeaturesPreviousZone && listFeaturesPolygon.length > 0)
            {
              state.previousFeatureGeoJsonDataZone = [...listFeaturesPolygon]
            } 

           // console.log("state.previousFeatureGeoJsonDataZone?", state.previousFeatureGeoJsonDataZone)

            // 3. Lấy tất cả features ko phải polygon
            const listFeatureNotIncludePolygon = state.geoJsonData?.features.map((feature:any) => {      
              if(feature?.properties?.itemGroup != 'zone' && feature !== undefined){
                return {...feature}
              }
            }).filter((item: any) => item != undefined);
            //console.log("listFeatureNotIncludePolygon", listFeatureNotIncludePolygon)

            // 4. Thay đổi list geoJsonData gốc
            // Assign lại danh sách không chứa zone
            state.geoJsonData.features = [...listFeatureNotIncludePolygon]; 

            // if(state.previousFeatureGeoJsonData?.features?.length > 0)
            // {
            //   const listFeatureNotIncludePolygonInListPrevious = state.previousFeatureGeoJsonData?.features.map((feature:any) => {      
            //   if(feature?.properties?.itemGroup != 'zone' && feature !== undefined){
            //     return {...feature}
            //   }
            //   }).filter((item: any) => item != undefined);

            //   state.geoJsonData.features = [...listFeatureNotIncludePolygon, ...listFeatureNotIncludePolygonInListPrevious]; 
            // }
            // else{
            //     //state.geoJsonData?.features.splice(0,  state.geoJsonData?.features.length);
            //   state.geoJsonData.features = [...listFeatureNotIncludePolygon]; 
            // }
          

          }        
          break;
        case 'unit':   
        ////console.log("state.previousFeatureGeoJsonDataZone? - UNIT", state.previousFeatureGeoJsonDataZone)
         const listIdInWorkUnitFilter_unit= mapStore.workUnitList.map((unit) => {     
            //////console.log("filterDeviceItems",unit)    
            if(state.filterDeviceItems.unit && state.filterDeviceItems.unit.includes(unit?.id)){            
              return unit?.id
            }
          }) 
          ////console.log("listIdInEquipmentTypeFilter", listIdInEquipmentTypeFilter_unit)
          filterFeaturesByItemGroup('unit', listIdInWorkUnitFilter_unit)   
          break;

        case 'event':        
          // Lấy list zone có tai nạn
          const listIdZoneInEventType = mapStore.incidentZoneDataExistInTrafficInfoList.map((item) => {
            if(state.filterDeviceItems.event.includes(item?.eventTypeId)){
              return item.zoneId
            }
          })
         state.listIdZoneInEventType = [...listIdZoneInEventType]      
      }
    }
  }
  renderGeoJson();
}, { deep: true })

/**
 * Trả dữ liệu GeoDataJson về cho compoent Index để truyền qua component MapControl
 */
const ReturnGeoDataJsonToComponentIndex = () => {  
  let isExistZone = false;
  const featureGeoJsonDataNotIncludePolyGon = state.geoJsonData?.features.map((feature : any) => {
    if(feature?.properties.itemGroup != 'zone'){
      
      return feature;
    }else{
      isExistZone = true;
    }
  }).filter((item) => item != undefined)

  if(isExistZone != undefined && isExistZone){
    featureGeoJsonDataNotIncludePolyGon.push({
      properties:{
        itemGroup: "zone"
      }
    })
  }

  //console.log("ReturnGeoDataJsonToComponentIndex - featureGeoJsonDataNotIncludePolyGon", featureGeoJsonDataNotIncludePolyGon)
  emit('return-geo-json-data', featureGeoJsonDataNotIncludePolyGon)
}

// Watch selectMapId change
watch(() => props.selectedMapId, async (newMapId : any, oldMapId : any) => { 

  console.log("selectedMapId - newMapId", newMapId)
  console.log("selectedMapId - oldMapId", oldMapId)
  

  // Gen lại random number
  state.randomFourNumber = generateRandomNumber(4);

  state.mapId = newMapId
  if (newMapId !== oldMapId && oldMapId != undefined) 
  {
    // Handle map changes with unsaved changes     
    if (state.unsavedChanges.size > 0) 
    {
        state.mapId = oldMapId;
        try {
          await ElMessageBox.confirm(
            $t('lz.message.tmsLocation.confirmUnsavedChange'),
            $t('lz.label.base.unsavedChange'),
            {
              confirmButtonText: $t('lz.button.base.save'),
              cancelButtonText: $t('lz.button.base.cancel'),
              type: 'warning',
            }
          );
          const stringifyGeoJson = JSON.stringify(state.geoJsonData)
          await handleSave({geoJson:stringifyGeoJson, status:1, maxZoom:state.mapViewState.maxZoom, minZoom:state.mapViewState.minZoom, 
                longtitude:state.mapViewState.center[0], latitude:state.mapViewState.center[1]});    
          //await loadMapData(newMapId);
          console.log("Load data unsavedChanges")
        } 
        catch (e) {
          state.unsavedChanges.clear();
          await loadMapData(newMapId);
        }
    } 
  }
  if(newMapId) 
  {
    // Kiểm tra zoneList đã có trong mapStore chưa
    // Nếu chưa gọi lại 1 lần nữa
    if(mapStore && mapStore.zoneList && mapStore.zoneList.length < 1)
    {
      await mapStore.fetchZoneList();
    }
    // Reinitialize map on change
    await initializeMap() 
    console.log("Load data 2")

    // Kiểm tra đường dẫn lấy hình
    if(mapStore.baseUrl == '' || mapStore.baseUrl == null || mapStore.baseUrl == undefined){
      try {
        await mapStore.fetchSystemSysconfigFileserverGet();
      } 
      catch (error) {
        console.error("Error initializing map fetch file server:", error);
        // Handle the error appropriately, e.g., display an error message to the user
      }
    }

    // Fetch danh sách lấy hình cho VMS
    await mapStore.fetchVmsCurrentListGet();

    // Lấy danh sách loại sự kiện
    await mapStore.fetchEventTypeData();

    // Lấy danh sách vùng zone xảy ra sự kiện sự cố.
    await mapStore.fetchIncidentZoneDataExistInTrafficInfo() 

    // Load lại map
    await loadMapData(newMapId)
  }
}, { immediate: true })


// Lắng nghe broadcast khi có sự kiện, sự cố
watch(() => incidentMonitor.broadcastDateTime, async (newValue, oldValue) => {
 
  if(newValue != oldValue){

    // Lấy danh sách loại sự kiện
    await mapStore.fetchEventTypeData();

    // Lấy danh sách vùng zone xảy ra sự kiện sự cố.
    await mapStore.fetchIncidentZoneDataExistInTrafficInfo() 

    // Kiểm tra danh sách các vùng zone có sự kiện sự cố
    // Nếu có lấy id các vùng zone lưu vào state.listIdZoneInEventType
    // if(mapStore.incidentZoneDataExistInTrafficInfoList && mapStore.incidentZoneDataExistInTrafficInfoList.length > 0){
    //     const listDataIncidentZone = mapStore.incidentZoneDataExistInTrafficInfoList.map((item : any) => {
    //         if(item.zoneId){
    //           return item.zoneId
    //         }         
    //     }).filter(item => item != undefined)
    //     state.listIdZoneInEventType = [...listDataIncidentZone]
    // }else{
    //   state.listIdZoneInEventType = []
    // }       
    //console.log("mapStore.incidentZoneDataExistInTrafficInfoList", mapStore.incidentZoneDataExistInTrafficInfoList)
  }
  // Refresh lại map
  if(state.mapId){
    await loadMapData(state.mapId)
  }  
})

// Lắng nghe broadcast khi có trigger hẹn giờ
watch(() => vmsMonitor.isVmsUpdate, async (newValue, oldValue) => {

 if(newValue != oldValue)
 {  

  console.log("Socket in VMS FE")
  await mapStore.fetchVmsCurrentListGet()

  // Render again VMS
  // Kiểm tra url đang là màn hình traffic info hay tmsMapLocation
  const isLastNameUrlOrEmpty = props.lastNameUrl == "mapSample" || props.lastNameUrl == ''

  // Loop từng marker và cập nhật lại
  state.geoJsonData.features.forEach(async (feature: any) => 
  { 
      if (feature.geometry.type === 'Point') 
      {
        renderMarkerVMS(isLastNameUrlOrEmpty, feature)   
      }
  })
 }

})


/**
 * Updates marker position in GeoJSON data
 */
 const updateMarkerPositionInGeoJSON = (id: string, newLatLng: L.LatLng): void => {
  
  // state.markersLayer.eachLayer((layer: any) => {
  //     if (layer instanceof L.Marker) { 
  //       // Do something with the marker, e.g.,
  //       //////console.log(layer.getLatLng());
  //     }
  //   })
  ////console.log("updateMarkerPositionInGeoJSON")
  const feature = state.geoJsonData.features.find((f: any) => 
    f.geometry.type === 'Point' && f.properties?.id === id
  );
  if (feature) {
    feature.geometry.coordinates = [newLatLng.lng, newLatLng.lat];
  }
};

// ===== Change Tracking =====
/**
 * Marks a feature as having unsaved changes
 */
 const handleMarkUnsaved = (id: string) => {
  state.unsavedChanges.add(id);
  renderGeoJson({activeLayerId:id});   
};

// ===== Feature Editing =====
/**
 * Shows the edit modal for a feature
 */
//  const showEditModal = (layer: L.Layer, id: string, type: string): void => {
//   state.editFeature = {
//     id,
//     status: state.editFeature.status,
//     strokeColor: (layer as any).options?.strokeColor || themeConfig.themeConfig.primary,
//     strokeWidth: (layer as any).options?.strokeWidth || 1,
//     strokeOpacity: (layer as any).options?.strokeOpacity || 1,
//     fillOpacity: (layer as any).options?.fillOpacity || 1,
//     type,
//     layer,
//   };
//   state.editDialogVisible = true
//   modalEditRef.value?.showModal()
// };

// Enhanced getItemDetails function
interface ItemDetails {
  name: string;
  iconUrl: string;
  unit?: string;
  measurement?: number;
  type?: string;
  additionalInfo?: any;
}


const handleStartEditing = (row: any) => { 
  // Implementation
  // Clear any existing editing mode first
  if (state.currentMode) {
    finishEditing();
  }

  state.currentMode = 'edit';
  state.activeFeatureId = row.id;
  
  const feature = state.geoJsonData.features.find((f: any) => f.properties?.id === row.id);

  
  if (!feature || !state.map) return;  

  // Find the corresponding layer
  let targetLayer: L.Layer | null = null;
  state.polygonsLayer.eachLayer((layer: any) => {

   
    if (layer.feature?.properties?.id === row.id || layer.options?.id === row.id) {
      targetLayer = layer;
    }
  });
  if (targetLayer && state.map) {
    if (feature.geometry.type === 'Polygon') {

      // Store original coordinates before editing
      state.originalCoordinates = JSON.parse(JSON.stringify(feature.geometry.coordinates));
      

      // Enable editing with specific styling for edit points
      (targetLayer as any).pm.enable({
        allowSelfIntersection: false,
        preventMarkerRemoval: true,
        mode: 'Edit',
        vertexStyle: {
          color: '#ff4444',
          fillColor: '#ff4444',
          fillOpacity: 1,
          radius: 6,
          weight: 2
        },
        middleMarkerStyle: {
          color: '#4444ff',
          fillColor: '#4444ff',
          fillOpacity: 1,
          radius: 4,
          weight: 2
        }
      });

      // Store reference to the editing layer
      state.editingLayer = targetLayer;

      // Listen for vertex changes
      (targetLayer as any).on('pm:vertexadded pm:vertexremoved pm:vertexclick pm:markerdragend', (e: any) => {
      
        const updatedCoords = e.target.getLatLngs()[0].map((latLng: L.LatLng) => [latLng.lng, latLng.lat]);
        feature.geometry.coordinates = [updatedCoords];
        state.currentCoordinates = [updatedCoords];
        handleMarkUnsaved(row.id);
       
      });

    
      // Pan to the feature's center without changing zoom
      const bounds = (targetLayer as any).getBounds();
      state.map.panTo(bounds.getCenter());
    }
  }
}


/**
 * handleStartMoving
 */
const handleStartMoving = (row: any) => {

  // Implementation
   // Clear any existing editing mode first
  if (state.currentMode) {        
    finishEditing();
  }

  state.currentMode = 'move';
  state.activeFeatureId = row.id;

  const feature = state.geoJsonData.features.find(f => f.properties?.id === row.id);
  if (!feature || !state.map) return;

  // Store original coordinates before moving
  state.originalCoordinates = JSON.parse(JSON.stringify(feature.geometry.coordinates));
 
  // Find the corresponding layer
  let targetLayer: L.Layer | null = null;
  if (feature.geometry.type === 'Point') {
    state.markersLayer.eachLayer((layer: any) => {
     
      if (layer.feature?.properties?.id === row.id || layer.options?.id === row.id) {
        targetLayer = layer;
      }
    });  
  } 
  else {
    state.polygonsLayer.eachLayer((layer: any) => {
     
      if (layer.feature?.properties?.id === row.id || layer.options?.id === row.id) {
        targetLayer = layer;
      }
    });   
  }

  if (targetLayer) {   
    if (feature.geometry.type === 'Polygon') {
      // Get the bounds of the feature
      const bounds = (targetLayer as any).getBounds?.() || 
                    L.latLngBounds((targetLayer as any).getLatLng());                  
     

      // Pan to the feature without changing zoom
      state.map.panTo(bounds.getCenter(), { 
        animate: true,
        duration: 1
      });

      // Enable dragging for polygon
      (targetLayer as any).pm.enable({
        draggable: true,
        allowSelfIntersection: false,
        preventMarkerRemoval: true,       
        snappable: false,
        snapDistance: 0,
        tooltips: false,
        requireSnapToFinish: false,
        allowEditing: false,
        allowRemoval: false,
        allowRotation: false,
        allowCutting: false,
        allowSplitting: false,
        addVertexOn: 'none',
        removeVertexOn: 'none',
        removeVertexPolygon: false
      });
      //state.map.pm.toggleGlobalDragMode()

      const isEnableDragMode =  state.map.pm.globalDragModeEnabled()

      
       // Ensure the layer is added to the map before attaching the event listener
      if (state.map.hasLayer(targetLayer)) {        
          if (state.polygonsLayer && state.polygonsLayer.eachLayer) 
          {
            state.polygonsLayer.eachLayer((layer:any) => {
            if (layer.feature?.properties?.id === row.id || 
                layer.options?.id === row.id)
           {          
              layer?.pm?.enableLayerDrag();
              layer.on('pm:dragend', (e: any) => {         
                    const updatedCoords = e.target.getLatLngs()[0].map((latLng: L.LatLng) => [latLng.lng, latLng.lat]);
                    feature.geometry.coordinates = [updatedCoords];
                    state.currentCoordinates = [updatedCoords];
                    handleMarkUnsaved(row.id);
                    });
                }         
                })
            } 
      } 
      else {
          console.error('Layer is not added to the map');
      } 
    } 
    else if (feature.geometry.type === 'Point') {
      if (state.map.hasLayer(targetLayer)) {        
          if (state.markersLayer && state.markersLayer.eachLayer) 
          {
            state.markersLayer.eachLayer((layer:any) => {
            if (layer.feature?.properties?.id === row.id || 
                layer.options?.id === row.id)
            {          
                  
                  // Enable dragging for marker
                  layer.dragging?.enable();
                  // Add drag event listener
                  layer.on('dragend', (e: any) => {
                    const position = e.target.getLatLng();
                    feature.geometry.coordinates = [position.lng, position.lat];
                    state.currentCoordinates = [position.lng, position.lat];       
                    handleMarkUnsaved(row.id);
                  });
                  state.editingLayer = layer;     
                  
                  var latlngMarkerLayer = layer.getLatLng();

                  // Location item
                  state.map?.setView([latlngMarkerLayer.lat, latlngMarkerLayer.lng], state.map?.getZoom())

                  // Add highlight on layer          
                  state.highlightLayer = L.circle([latlngMarkerLayer.lat, latlngMarkerLayer.lng], {
                      color: 'red',
                      fillColor: '#f03',
                      fillOpacity: 0.5,
                      radius: 500
                  }).addTo(state.map as any);
                  const currentZoom = state.map?.getZoom();

                  // Xóa highlight sau 500ms
                  setTimeout(() => {
                    clearHighlight();
                  }, 200)
            }         
          })
        } 
      } 
      else {
          console.error('Layer is not added to the map');
      }
    }
  } 
}

/**
 * Clears all unsaved changes tracking
 */
 const clearUnsavedChanges = () => {
  state.unsavedChanges.clear();
  renderGeoJson();
};

/**
 * Handle submit lưu dữ liệu
 */
const handleSave = async(item:{geoJson: string, status:number, maxZoom: number, minZoom: number, longtitude: number, latitude:number}) => {
  
  try {
    // Make sure to finish any active editing before updating
    if (state.currentMode) {
      finishEditing();
     }

    // Save current map view state
    if (state.map) {
      let center = state.map.getCenter();
      let zoom = state.map.getZoom();

      console.log("center", center)

      // Check zoom dfault
      if(zoom < item.minZoom)
      {
         zoom = item.minZoom
      }

      // Check maxZoom
      if(item.maxZoom <= item.minZoom){
        item.maxZoom = item.minZoom + 1
      }

      // Check minZoom
      if(item.minZoom >= item.maxZoom){
        item.minZoom = item.maxZoom - 1
      } 

      // Check longtitude 
      if(item.longtitude){
        center.lng = item.longtitude
      }

      // Check latitude
      if(item.latitude){
        center.lat = item.latitude
      }

      // Assign to mapViewState
      state.mapViewState = {
        center: [center.lat, center.lng],
        zoom : zoom,
        maxZoom: item.maxZoom,
        minZoom: item.minZoom
      };    

      console.log("handleSave -  state.mapViewState",  state.mapViewState)

      // Update map location data
      state.ruleForm = {       
        mapId: state.mapId,
        name: state.mapId,
        status: 1,
        config: JSON.stringify(state.mapViewState)
      };

      console.log("handleSave -  state.ruleForm",  state.ruleForm)

      // Kiểm tra đang có filter hay không
      const geoJsonDataToSave = JSON.parse(JSON.stringify(state.geoJsonData))    
      console.log("handleSave -  geoJsonDataToSave",  geoJsonDataToSave)
      if(item.geoJson)
      {      
        console.log("handleSave -  Có đang filter",  item.geoJson)
        if(state.previousFeatureGeoJsonData.length > 0)
        {            
          console.log("handleSave -  Có đang filter 2")
          geoJsonDataToSave.features = JSON.parse(JSON.stringify([...state.geoJsonData.features, ...state.previousFeatureGeoJsonData]))  
        }
        // Check nếu zone được filter 
        if(state.previousFeatureGeoJsonDataZone.length > 0)
        {  
          console.log("handleSave -  Có đang filter 2")
          geoJsonDataToSave.features.push(...state.previousFeatureGeoJsonDataZone) 
        }
        console.log("handleSave -  Có đang filter 3")
        state.ruleForm.geoJson = JSON.stringify(geoJsonDataToSave)
      }    
      await locationEditorRef.value.ruleFormRef?.validate()
      state.ruleForm.id = state.tmsLocationMapId;

      console.log("handleSave -   state.ruleForm",  state.ruleForm)
      await getAPI(TmsMapLocationApi).apiTmsTmsmaplocationUpdatePost(state.ruleForm);    
      ReturnGeoDataJsonToComponentIndex();  
      clearUnsavedChanges();
      ElMessage.success($t('lz.message.base.saveSuccess'));
    }
  } 
  catch (error) 
  {
    if (error instanceof Error) {
      ElMessage.error($t('lz.message.base.saveError'));
      console.error('Error updating:', error);
    }
  }
}

/**
 * Handle add item trên map
 */
const handleAddItem = async (item: { id: string; group: string; geometryType: string} ) => {
    if (!state.map) return
    
    const center = state.map.getCenter()

    try{      
      if (!item.id) {
        ElMessage.warning( $t('lz.message.tmsLocation.warningPleaseSelectItem') );
        return;
      }

      const iconUrlItemDetail = mapStore.getItemDetails(item.id, item.group)?.iconUrl
      const customIcon = L.icon({
        iconUrl: iconUrlItemDetail == '' ? Image :iconUrlItemDetail,
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32]
      });

      const marker = L.marker(state.map.getCenter(), { 
        icon: customIcon, 
        draggable: true 
      }).addTo(state.map as any);

      const geoJson = marker.toGeoJSON();
      geoJson.properties = {
        id: item.id,
        itemGroup: item.group
    };
    state.geoJsonData.features.push(geoJson);
    state.markersLayer.addLayer(marker);
    
    // Clear the selection after adding
    locationEditorRef.value?.handleResetTypeIdEqualNull();

    // Add click handler for editing
    // Thêm sự kiện on click show modal
    // if(props.lastNameUrl && props.lastNameUrl == "mapSample" && props.lastNameUrl == ''){
    //     marker.on('click', () => showEditModal(marker, item.id, 'Point'));
    // }
 

    // Add drag handler
    marker.on('dragend', (event: L.DragEndEvent) => {
      const position = event.target.getLatLng();
      updateMarkerPositionInGeoJSON(item.id, position);
      handleMarkUnsaved(item.id);
    });

    // Refresh the item list to update disabled states
    locationEditorRef.value?.handleItemGroupChange();
        
    // Add drag handler
    // marker.on('dragend', (event: L.DragEndEvent) => {
    //   const position = event.target.getLatLng();         
    //   updateMarkerPositionInGeoJSON(item.id, position, item.group, event.target);
    //   event.target.setIcon(customIcon);
    //   handleMarkUnsaved(item.id);
    // });

    // Refresh the item list to update disabled states
    //handleEquipmentTypeChange();

    //   if (item.geometryType === 'Point') {
    //   // Add point at map center
    //   const newFeature = {
    //     type: 'Feature',
    //     properties: {
    //       id: item.id,
    //       itemGroup: item.group
    //     },
    //     geometry: {
    //       type: 'Point',
    //       coordinates: [center.lng, center.lat]
    //     }
    //   }
    //   state.geoJsonData.features.push(newFeature)
    // } else {  
    //   // Start polygon drawing mode
    //   state.map.pm.enableDraw('Polygon', {
    //     snappable: true,
    //     snapDistance: 20,
    //     templineStyle: { color: '#3388ff' },
    //     hintlineStyle: { color: '#3388ff', dashArray: '5,5' },
    //     pathOptions: {
    //       color: '#3388ff',
    //       fillColor: '#3388ff',
    //       fillOpacity: 0.2
    //     }
    //   })
      
    //   // Store the item details for when drawing completes
    //   state.drawingItem = item

    //   renderGeoJson()
    // }
  }
  catch (error) {
    console.error('Error adding marker:', error);
  }

}

/**
 * handleSaveEditModal 
 */
 const handleSaveEditModal = () => {

  const { id, type, layer, ...props } = state.editFeature;
  const feature = state.geoJsonData.features.find((f) => f.properties?.id === id);
  if (feature) {
    Object.assign(feature.properties, props);
    
    // If we have current coordinates from editing, use those
    if (state.currentCoordinates && feature.geometry.type === 'Polygon') {
      feature.geometry.coordinates = state.currentCoordinates;
    }
    
    if (type === 'Polygon') {
      const polygonLayer = layer as L.Polygon;
      polygonLayer.setStyle({
        color: props.strokeColor,
        weight: props.strokeWidth,
        opacity: props.strokeOpacity,
        fillOpacity: props.fillOpacity,
      });
    }
    if (type === 'Point') {
      const marker = layer as L.Marker;
      const status = props.status;
    }

    state.editDialogVisible = false;
    renderGeoJson();
  }

 }

 /**
 * handleRemoveFeatureModal 
 */
 const handleRemoveFeatureModal = () => {
  //////console.log("handleRemoveFeatureModal")
  const { layer, id, type } = state.editFeature;
  if (type === 'Polygon') {
    state.polygonsLayer.removeLayer(layer as L.Polygon);
  } else if (type === 'Point') {
    state.markersLayer.removeLayer(layer as L.Marker);
  }

  state.geoJsonData.features = state.geoJsonData.features.filter((feature) => feature.properties.id !== id);

  state.editDialogVisible = false;
  renderGeoJson();
 }

/**
 * Handle draw zone trên map
 */
const handleStartDrawingPolygon = async(item: {typeId: string, group: string}) => {
  if (!state.map) return;

  const selectedItemId = item.typeId;
  if (!selectedItemId) {
    ElMessage.warning($t('lz.label.tmsMapLocation.warningDrawPolygon'));
    return;
  }

  state.map.pm.enableDraw('Polygon', {
    snappable: true,
    snapDistance: 20,
  })
 

}

/**
 * Get GeoJsonData
 */
const handleGetGeoJsonData = () => {
  return state.geoJsonData.features;
}

/**
 * Get ZoneList
 */
 const handleGetZoneListData = () => {  
  return mapStore.zoneList;
}

/**
 * Get EquipmentList
 */
 const handleEquipmentListData = () => {
  return mapStore.equipmentList;
}

/**
 * Get Unit List
 */
 const handleGetUnitListData = () => {
  return mapStore.workUnitList;
}

/**
 * Get Current Mode
 */
const handleGetCurrentMode = () => {
  return state.currentMode
}

/**
 * Get Geo Json Data From Leaflet
 */
 const handleGetGeoJsonDataFromLeaflet = () => {
  return state.geoJsonData
}


defineExpose({
  zoomIn,
  zoomOut,
  saveViewState,
  handleGetGeoJsonData,
  handleGetZoneListData,
  handleEquipmentListData,
  handleGetUnitListData,
  handleGetCurrentMode,
  handleGetGeoJsonDataFromLeaflet
})


</script>

<style scoped>
.text-dark{
  color: black
}

.map-container {
  position: relative;
  width: 100%;
  height: 100%;
  z-index: 0;
}

#map {
  width: 100%;
  height: 100%;
  min-height: 500px;
}


.finish-button-container {
  position: absolute;
  bottom: 10px;
  left: 10px;
  z-index: 1000;
  display: flex;
  gap: 10px;
}

.finish-button-container .el-button {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 12px 20px;
  font-weight: 600;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
}

.finish-button-container .el-icon {
  margin-right: 4px;
}

.custom-stack-icon {
  position: relative;
  width: 50px;
  height: 50px;
}
.custom-stack-icon img {
  position: absolute;
  width: 40px;
  height: 40px;
}

</style> 