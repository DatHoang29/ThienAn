<template>
    <div class="rpt-carbone-demo-container">
      <el-card shadow="hover" :body-style="{ padding: '5px 5px 0 5px', display: 'flex', width: '100%', height: '100%', alignItems: 'start' }">
        <el-form :model="state.queryParams" ref="queryForm" :show-message="false" :inlineMessage="true" label-width="auto" style="flex: 1 1 0%">
          <el-row :gutter="10">
            <el-col class="mb5" :xs="24" :sm="12" :md="8" :lg="6" :xl="6">
              <el-form-item label="Name" prop="name">
                <el-input v-model="state.queryParams.name" placeholder="Name" clearable @keyup.enter.native="handleQuery" />
              </el-form-item>
            </el-col>
            <el-col class="mb5" :xs="24" :sm="12" :md="8" :lg="6" :xl="6">
              <el-form-item label="Description" prop="description">
                <el-input v-model="state.queryParams.description" placeholder="Description" clearable @keyup.enter.native="handleQuery" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
  
        <el-divider style="height: calc(100% - 5px); margin: 0 10px" direction="vertical" />
  
        <el-row>
          <el-col>
            <el-row justify="center">
              <el-button type="primary" icon="ele-Search" @click="handleQuery" v-auth="'rptDemo:list'" :loading="state.loading">Search</el-button>
              <el-button icon="ele-Refresh" @click="resetQuery" :loading="state.loading">Reset</el-button>
            </el-row>
          </el-col>
        </el-row>
      </el-card>
  
      <el-card class="full-table" shadow="hover" style="margin-top: 5px">
        <el-header>
          <div class="export-container">
            <el-select v-model="state.exportFormat" placeholder="Select format" class="export-select">
              <el-option label="PDF" value="pdf"></el-option>
              <el-option label="Excel (XLSX)" value="xlsx"></el-option>
            </el-select>
            <el-button type="primary" icon="ele-Download" @click="handleExport" :loading="state.exporting">Export file</el-button>
          </div>
        </el-header>
        <div class="pdf-container text-center">
          <div v-for="page in state.pages" :key="page">
              <VuePDF :pdf="state.pdf" :page="page" :scale="1.25" fit-parent />
          </div>
        </div>
      </el-card>
    </div>
  </template>
  
  <script lang="ts" setup name="rptCarboneDemo">
  import { reactive, ref } from 'vue';
  import { ElMessage } from 'element-plus';
  import { getAPI } from '/@/utils/axios-utils';
  // import { CarboneDemoApi } from '/@/api-services/reportDemo';
  import {SampCategoryCReportApi} from '/@/api-services/sampleReport';
  import { useDateFormat, useNow } from '@vueuse/core'
  import { VuePDF, usePDF } from '@tato30/vue-pdf'
  import { saveAs } from 'file-saver';
  
  const state = reactive({
    queryParams: {
      name: undefined,
      description: undefined,
    },
    loading: false,
    exporting: false,
    pdfUrl: '',
    pdf: undefined,
    pages: null,
    reportDataId: '',
    exportFormat: 'pdf' // Default export format
  });
  
  // Query operation
  const handleQuery = async () => {
    state.loading = true;
    try {
      state.reportDataId = generateDataId();
      const response = await getAPI(SampCategoryCReportApi).apiSampreportSampcategorycreportRenderPost(state.queryParams.name,state.queryParams.description, state.reportDataId, { responseType: 'blob' });
      const { pdf, pages } = usePDF(URL.createObjectURL(new Blob([response.data])));
      console.log(pdf, pages);
      state.pdf = pdf;
      state.pages = pages;
      // state.pdfUrl = URL.createObjectURL(new Blob([response.data]));
    } catch (error) {
      console.error('Error fetching PDF:', error);
      ElMessage.error('Failed to fetch PDF');
    } finally {
      state.loading = false;
    }
  };
  
  // Reset operation
  const resetQuery = () => {
    state.queryParams.title = undefined;
    state.pdfUrl = '';
  };
  
  // Function to generate string in the format yyyyMMdd_Guid without hyphens
  const generateDataId = () => {
  const dateStr = useDateFormat(useNow(), 'YYYYMMDD'); // yyyyMMdd
  const guidStr = 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
  return `${dateStr.value}_${guidStr}`;
};
  
  // Export operation
  const handleExport = async () => {
    state.exporting = true;
    try {
      const response = await getAPI(SampCategoryCReportApi).apiSampreportSampcategorycreportExportPost(
        state.exportFormat, state.queryParams.name,state.queryParams.description, state.reportDataId, 
        { responseType: 'blob' }
      );
  
      // Get the filename from the Content-Disposition header
      const contentDisposition = response.headers['content-disposition'];
      let filename = `report.${state.exportFormat}`; // Use the selected format for the filename
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="?(.+)"?/i);
        if (filenameMatch) {
          filename = filenameMatch[1];
        }
      }
  
      // Use FileSaver to save the file
      saveAs(new Blob([response.data], { type: response.headers['content-type'] }), filename);
  
      ElMessage.success('Export successful');
    } catch (error) {
      if(error.response.status === 0) {
        return;
      } else {
        console.error('Error exporting file:', error);
        ElMessage.error('Failed to export file');
      }
    } finally {
      state.exporting = false;
    }
  };
  </script>
  
  <style scoped>
  .rpt-demo-container {
    height: 100%;
    display: flex;
    flex-direction: column;
  }
  
  .full-table {
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
  
  .pdf-container {
    flex: 1;
    overflow: auto;
  }
  
  :deep(.vue-office-pdf) {
    width: 100%;
    height: 100%;
  }
  .export-container {
    display: flex;
    align-items: center; /* Align items vertically in the center */
  }
  
  .export-select {
    width: 120px; /* Set a fixed width for the dropdown */
    margin-right: 10px; /* Add some space between the dropdown and the button */
  }
  
  </style>
  