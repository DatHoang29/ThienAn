<template>
    <div class="tms-lichsu-tuanduong-container">
      <el-card shadow="hover"
        :body-style="{ padding: '5px 5px 0 5px', display: 'flex', width: '100%', height: '100%', alignItems: 'start' }">
        <el-form :model="state.queryParams" ref="queryForm" :show-message="false" :inlineMessage="true"
          label-width="auto" style="flex: 1 1 0%">
          <el-row :gutter="10">
            <el-col class="mb5" :xs="24" :sm="12" :md="8" :lg="6" :xl="6">
              <el-form-item label="Nhân viên" prop="employee">
                <el-select v-model="state.queryParams.employee" filterable clearable class="w100" placeholder="Chọn nhân viên">
                  <el-option v-for="item in state.employeeList" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col class="mb5" :xs="24" :sm="12" :md="8" :lg="6" :xl="6">
              <el-form-item label="Ngày từ" prop="fromDate">
                <el-date-picker v-model="state.queryParams.fromDate" type="date" placeholder="Từ ngày" class="w100" />
              </el-form-item>
            </el-col>
            <el-col class="mb5" :xs="24" :sm="12" :md="8" :lg="6" :xl="6">
              <el-form-item label="Ngày đến" prop="toDate">
                <el-date-picker v-model="state.queryParams.toDate" type="date" placeholder="Đến ngày" class="w100" />
              </el-form-item>
            </el-col>
            <el-col class="mb5" :xs="24" :sm="12" :md="8" :lg="6" :xl="6">
              <el-form-item label="Ca" prop="shift">
                <el-select v-model="state.queryParams.shift" filterable clearable class="w100" placeholder="Chọn ca">
                  <el-option v-for="item in state.shiftList" :key="item.id" :label="item.name" :value="item.id" />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-divider style="height: calc(100% - 5px); margin: 0 10px" direction="vertical" />
        <el-row>
          
          <SearchButton @search="handleQuery" @reset="resetQuery" :loading="options.loading" />
       
        </el-row>
      </el-card>
      <el-card class="full-table" shadow="hover" style="margin-top: 5px">
        <template v-if="!state.calendarView">
          <vxe-grid ref="xGrid" class="xGrid-style custom-grid" v-bind="options"
            :row-config="{ height: 75 }">
            <template #toolbar_buttons>
                <!-- <el-select v-model="state.selectedWeek" style="margin-left: 10px; width: 180px;margin-bottom: 10px;" @change="handleQuery">
                <el-option v-for="week in state.weekOptions" :key="week.value" :label="week.label" :value="week.value" />
                </el-select> -->
                <el-button style="margin-left: 10px" @click="state.calendarView = !state.calendarView" type="info">
                    {{ state.calendarView ? 'Xem dạng bảng' : 'Xem dạng lịch' }}
                </el-button>
            </template>
            <template #toolbar_tools>
                <el-button type="primary" @click="handleAdd" style="margin-bottom: 10px;margin-right: 10px;">Đăng ký mới</el-button>
                <el-button v-show="state.hasChange" type="success" @click="handleSaveChange" style="margin-left: 10px; margin-bottom: 10px;">Lưu thay đổi</el-button>
            
            </template>
            <template #employee_cell="{ row }">
              <draggable
                :list="row.employees"
                :group="'employees'"
                item-key="id"
                :clone="cloneEmployee"
                @end="(evt: any) => onDragEnd(evt, row)"
                @move="(evt: any) => canMoveEmployee(evt, row)"
                style="display: flex; gap: 4px; min-height: 32px"
              >
                <template #item="{ element }">
                  <el-tag :key="element.id" style="margin-right: 4px">{{ element.name }}</el-tag>
                </template>
              </draggable>
            </template>
            <template #tasks_cell="{ row }">
              <div>
                <el-tag v-for="(task, idx) in row.tasks" :key="idx" type="info" style="margin: 2px">{{ task }}</el-tag>
              </div>
            </template>
            <template #row_buttons="{ row }">
              <el-tooltip content="Sửa" placement="top">
                <el-button icon="ele-Edit" text type="primary" @click="handleEdit(row)"> </el-button>
              </el-tooltip>
              <el-tooltip content="Xóa" placement="top">
                <el-button icon="ele-Delete" text type="danger" @click="handleDelete(row)"> </el-button>
              </el-tooltip>
            </template>
            <template #empty>
              <el-empty :image-size="200" />
            </template>
          </vxe-grid>
        </template>
        <template v-else>
            <div>
                <el-button style="margin-left: 10px" @click="state.calendarView = !state.calendarView" type="info">
                    {{ state.calendarView ? 'Xem dạng bảng' : 'Xem dạng lịch' }}
                </el-button>
            </div>
          <el-calendar v-model="state.calendarDate">
            
            <template #date-cell="{ data }">
              <div>
                <div>{{ data.day.split('-').reverse().join('/') }}</div>
                <div v-for="item in getTasksByDate(data.day)" :key="item.id" style="margin-bottom: 2px">
                  <el-tag size="small" type="info">{{ item.tasks.join(', ') }}</el-tag>
                  <el-tooltip placement="top">
                    <template #content>
                      <div v-for="emp in item.employees" :key="emp.id">{{ emp.name }}</div>
                    </template>
                    <el-tag size="small" type="success" style="margin-left: 2px">{{ item.time }}</el-tag>
                  </el-tooltip>
                </div>
              </div>
            </template>
          </el-calendar>
        </template>
      </el-card>
      <EditLichSuTuanDuong ref="editLichSuTuanDuongRef" :title="state.title" :operateType="state.operateType" @handleQuery="handleQuery" />
    </div>
  </template>
  
  <script lang="ts" setup name="tmsLichSuTuanDuong">
  import { onMounted, reactive, ref, defineAsyncComponent } from 'vue';
  import { VxeGridInstance, VxeGridPropTypes } from 'vxe-table';
  import { useVxeTable } from '/@/hooks/useVxeTableOptionsHook';
  import draggable from 'vuedraggable';
  const SearchButton = defineAsyncComponent(() => import('/@/components/advanced/search-button-operation.vue'));
  const EditLichSuTuanDuong = defineAsyncComponent(() => import('./component/editBaoTri.vue'));
  
  const xGrid = ref<VxeGridInstance>();
  const editLichSuTuanDuongRef = ref();
  
  const state = reactive({
    queryParams: {
      employee: undefined,
      fromDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1), // tuần đầu tháng này
      toDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0), // tuần cuối tháng này
      shift: undefined,
    },
    employeeList: [
      { id: 1, name: '[cuonglv] Lê Văn Cường' },
      { id: 2, name: '[nhattv] Trần Văn Nhật' },
      { id: 3, name: '[tuanha] Hoàng Anh Tuấn' },
    ],
    shiftList: [
      { id: 1, name: 'Ca 1' },
      { id: 2, name: 'Ca 2' },
      { id: 3, name: 'Ca 3' },
    ],
    title: '',
    operateType: 'add',
    data: [],
    selectedWeek: '' as string,
    weekOptions: [] as Array<{label: string, value: string}>,
    hasChange: false,
    calendarView: false,
    calendarDate: new Date(),
  });
  
  const options = useVxeTable<any>(
    {
      id: 'lichSuTuanDuong',
      name: 'LichSuTuanDuong',
      columns: [
        { field: 'week', title: 'Tuần', minWidth: 70, showOverflow: 'tooltip', sortable: true },
        { field: 'date', title: 'Ngày', minWidth: 80, showOverflow: 'tooltip', sortable: true },
        { field: 'time', title: 'Thời gian', minWidth: 100, showOverflow: 'tooltip', sortable: true },
        { field: 'tasks', title: 'Công việc', minWidth: 250, showOverflow: 'tooltip', slots: { default: 'tasks_cell' } },
        { field: 'employees', title: 'Nhân viên', minWidth: 400, showOverflow: 'tooltip', slots: { default: 'employee_cell' } },
        { title: 'Thao tác', fixed: 'right', width: 100, showOverflow: true, slots: { default: 'row_buttons' } },
      ],
    },
    {
      proxyConfig: { autoLoad: true, ajax: { query: ({ page, sort }) => handleQueryApi(page, sort) } },
      toolbarConfig: { export: false },
      rowConfig: { height: 40 },
    }
  );
  
  // Tạo danh sách tuần duy nhất từ dữ liệu mẫu
  function getAllWeeksFromData(data: any[]) {
    const weeks = Array.from(new Set(data.map(item => item.week)));
    return weeks.map(week => ({ label: `Tuần ${week}`, value: week }));
  }
  
  const mockData = [
    { id: 1, week: '24/2025', time: '10:00 - 12:00', date: '03/06/2025', tasks: ['Kiểm tra máy bơm', 'Bảo dưỡng van'], employees: [ { id: 1, name: '[cuonglv] Lê Văn Cường' }, { id: 2, name: '[nhattv] Trần Văn Nhật' } ] },
    { id: 2, week: '24/2025', time: '13:00 - 15:00', date: '03/06/2025', tasks: ['Vệ sinh hệ thống'], employees: [ { id: 3, name: '[cuonglv] Lê Văn Cường' } ] },
    { id: 3, week: '24/2025', time: '15:00 - 16:00', date: '03/06/2025', tasks: ['Kiểm tra điện'], employees: [ { id: 1, name: '[tuanha] Hoàng Anh Tuấn' } ] },
    { id: 1, week: '24/2025', time: '10:00 - 12:00', date: '04/06/2025', tasks: ['Bảo dưỡng van'], employees: [ { id: 1, name: '[cuonglv] Lê Văn Cường' }, { id: 2, name: '[nhattv] Trần Văn Nhật' } ] },
    { id: 2, week: '24/2025', time: '13:00 - 15:00', date: '04/06/2025', tasks: ['Kiểm tra máy bơm'], employees: [ { id: 3, name: '[cuonglv] Lê Văn Cường' } ] },
    { id: 3, week: '24/2025', time: '15:00 - 16:00', date: '04/06/2025', tasks: ['Vệ sinh hệ thống'], employees: [ { id: 1, name: '[tuanha] Hoàng Anh Tuấn' } ] },
    { id: 1, week: '24/2025', time: '10:00 - 12:00', date: '05/06/2025', tasks: ['Kiểm tra điện'], employees: [ { id: 1, name: '[cuonglv] Lê Văn Cường' }, { id: 2, name: '[nhattv] Trần Văn Nhật' } ] },
    { id: 2, week: '24/2025', time: '13:00 - 15:00', date: '05/06/2025', tasks: ['Bảo dưỡng van'], employees: [ { id: 3, name: '[cuonglv] Lê Văn Cường' } ] },
    { id: 3, week: '24/2025', time: '15:00 - 16:00', date: '05/06/2025', tasks: ['Kiểm tra máy bơm'], employees: [ { id: 1, name: '[tuanha] Hoàng Anh Tuấn' } ] },
    { id: 4, week: '25/2025', time: '10:00 - 12:00', date: '10/06/2025', tasks: ['Vệ sinh hệ thống'], employees: [ { id: 2, name: '[nhattv] Trần Văn Nhật' } ] },
    { id: 5, week: '25/2025', time: '13:00 - 15:00', date: '10/06/2025', tasks: ['Kiểm tra điện'], employees: [ { id: 1, name: '[cuonglv] Lê Văn Cường' }, { id: 3, name: '[tuanha] Hoàng Anh Tuấn' } ] },
    { id: 6, week: '25/2025', time: '15:00 - 16:00', date: '10/06/2025', tasks: ['Bảo dưỡng van'], employees: [ { id: 2, name: '[nhattv] Trần Văn Nhật' } ] },
    { id: 7, week: '26/2025', time: '10:00 - 12:00', date: '17/06/2025', tasks: ['Kiểm tra máy bơm'], employees: [ { id: 1, name: '[cuonglv] Lê Văn Cường' } ] },
    { id: 8, week: '26/2025', time: '13:00 - 15:00', date: '17/06/2025', tasks: ['Vệ sinh hệ thống'], employees: [ { id: 2, name: '[nhattv] Trần Văn Nhật' }, { id: 3, name: '[tuanha] Hoàng Anh Tuấn' } ] },
    { id: 9, week: '27/2025', time: '10:00 - 12:00', date: '24/06/2025', tasks: ['Kiểm tra điện'], employees: [ { id: 3, name: '[tuanha] Hoàng Anh Tuấn' } ] },
    { id: 10, week: '27/2025', time: '15:00 - 16:00', date: '24/06/2025', tasks: ['Bảo dưỡng van'], employees: [ { id: 1, name: '[cuonglv] Lê Văn Cường' } ] },
  ];
  window.mockData = mockData;
  
  state.weekOptions = getAllWeeksFromData(mockData);
  state.selectedWeek = state.weekOptions.length > 0 ? state.weekOptions[0].value : '';
  
  const handleQueryApi = async (page: VxeGridPropTypes.ProxyAjaxQueryPageParams, sort: VxeGridPropTypes.ProxyAjaxQuerySortCheckedParams) => {
    // Lọc dữ liệu mock theo điều kiện tìm kiếm
    let filtered = mockData.filter(item => {
      let match = true;
      if (state.selectedWeek) {
        match = match && item.week === state.selectedWeek;
      }
      if (state.queryParams.employee) {
        match = match && item.employees.some(e => e.id === state.queryParams.employee);
      }
      return match;
    });
    // Cập nhật lại danh sách tuần nếu có bản ghi mới
    state.weekOptions = getAllWeeksFromData(mockData);
    return { data: { result: { records: filtered, total: filtered.length } } };
  };
  
  const handleQuery = async () => {
    options.loading = true;
    await xGrid.value?.commitProxy('query');
    options.loading = false;
  };
  
  const resetQuery = async () => {
    state.queryParams.employee = undefined;
    state.queryParams.fromDate = undefined;
    state.queryParams.toDate = undefined;
    state.queryParams.shift = undefined;
    await xGrid.value?.commitProxy('reload');
  };
  
  const handleEdit = (row: any) => {
    state.title = 'Sửa lịch tuần đường';
    state.operateType = 'edit';
    editLichSuTuanDuongRef.value?.openDialog(row);
  };
  
  const handleDelete = (row: any) => {
    // Xử lý xóa dữ liệu mock (chỉ demo)
    const idx = mockData.findIndex(item => item.id === row.id);
    if (idx !== -1) {
      mockData.splice(idx, 1);
      handleQuery();
    }
  };
  
  const handleAdd = () => {
    state.title = 'Đăng ký lịch tuần đường';
    state.operateType = 'add';
    editLichSuTuanDuongRef.value?.openDialog({
      week: state.selectedWeek,
      date: '',
      shift: '',
      employees: [],
      multi: true, // truyền props để modal biết là đăng ký nhiều ngày/ca
    });
  };
  
  function cloneEmployee(employee: any) {
    return { ...employee };
  }
  
  function onDragEnd(evt: any, targetRow: any) {
    state.hasChange = true;
  
    const draggedEmpId = evt.item.__vueParentComponent.props.element.id;
    // Nếu nhân sự đã tồn tại trong ca-ngày này trước khi kéo, hủy thao tác
    const count = targetRow.employees.filter((e: any) => e.id === draggedEmpId).length;
    if (count > 1 || (count === 1 && evt.from !== evt.to)) {
      // Xóa nhân sự vừa thêm (undo drag)
      targetRow.employees = targetRow.employees.filter((e: any, idx: number, arr: any[]) => e.id !== draggedEmpId || arr.findIndex((x: any) => x.id === draggedEmpId) === idx);
      return;
    }
    // Đảm bảo không trùng nhân viên trong cùng 1 ca
    targetRow.employees = targetRow.employees.reduce((acc: any[], emp: any) => {
      if (!acc.find((e: any) => e.id === emp.id)) acc.push(emp);
      return acc;
    }, []);
    // Xóa nhân viên khỏi ca nguồn nếu khác ca đích
    if (evt.from !== evt.to) {
      const fromRow = findRowByEmployeeId(draggedEmpId, targetRow);
      if (fromRow && fromRow !== targetRow) {
        fromRow.employees = fromRow.employees.filter((e: any) => e.id !== draggedEmpId);
      }
    }
  }
  
  function findRowByEmployeeId(empId: number, exceptRow: any) {
    // Tìm ca chứa nhân viên này, trừ ca đích
    return mockData.find(row => row !== exceptRow && row.employees.some(e => e.id === empId));
  }
  
  function handleSaveChange() {
    // Ở đây có thể gọi API lưu hoặc cập nhật lại dữ liệu thực tế
    state.hasChange = false;
    // Có thể show thông báo thành công
  }
  
  function canMoveEmployee(evt: any, targetRow: any) {
    const draggedEmpId = evt.draggedContext.element.id;
    // Nếu đã có nhân sự này trong ca-ngày, không cho phép kéo
    if (targetRow.employees.some((e: any) => e.id === draggedEmpId)) {
      return false;
    }
    return true;
  }
  
  function getTasksByDate(dateStr: string) {
    // dateStr: yyyy-mm-dd
    const [year, month, day] = dateStr.split('-');
    const d = `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`;
    return mockData.filter(item => item.date === d);
  }
  </script>
  
  <style scoped>
  .tms-lichsu-tuanduong-container {
    padding: 10px;
  }
  :deep(.el-calendar-day){
  height: 120px!important;
}
  </style>
  