<template>
    <Teleport to="body">
        <div 
            v-if="state.isShowDialog" 
            class="drag-modal-wrapper"
            :style="{ zIndex: state.zIndex }"
            @mousedown.stop
        >
            <vue-draggable-resizable
                :initW="675"
                :initH="450"
                :minW="450"
                :minH="300"
                :x="state.position.x"
                :y="state.position.y"
                :draggable="true"
                :resizable="true"
                :parent="true"
                :parentLimitation="true"
                :parentW="parentSize.width"
                :parentH="parentSize.height"
                :minTop="100"
                :class="['floating-modal', { 'modal-active': state.isActive }]"
                @activated="bringToFront"
                @dragstop="onDragStop"
                @resizestop="onResizeStop"
                @mousedown.stop="bringToFront"
            >
                <div class="modal-header" style="padding: 0;">
                    <el-tabs v-model="state.activeTab" class="header-tabs" style="padding-right: 30px;" >
                        <el-tab-pane label="Info" name="occupancy" style="color:white" />
                        <el-tab-pane label="Chart" name="volume" />
                        <el-tab-pane label="Description" name="speed" />

                    </el-tabs>
                    <div class="close-actions">
                        <el-dropdown 
                            trigger="hover" 
                            @command="handleCloseCommand"
                            class="close-dropdown"
                        >
                            <div class="close-btn">
                                <el-icon><Close /></el-icon>
                            </div>
                            <template #dropdown>
                                <el-dropdown-menu>
                                    <el-dropdown-item command="close">Close</el-dropdown-item>
                                    <el-dropdown-item command="closeOthers">Close Others</el-dropdown-item>
                                    <el-dropdown-item command="closeAll">Close All</el-dropdown-item>
                                </el-dropdown-menu>
                            </template>
                        </el-dropdown>
                    </div>
                </div>

                <div class="modal-content">
                    <div class="content-wrapper">
                        <div v-show="state.activeTab === 'occupancy'" class="chart-container">
                            <div class="content-text">
                               <div v-if="state.workUnitInfo">
                                    <table class="table-data">
                                        <tr style="border-bottom: thin solid 2px;">
                                            <td colspan="2">
                                                <h3 class="text-uppercase">{{ state.workUnitInfo?.name }}</h3>
                                                <br>
                                            </td>
                                        </tr>
                                        <tr class="border-bottom--dashed">
                                            <th>{{ $t('entity.tmsWorkUnit.Type') }}:</th>
                                            <td>{{ state.workUnitTypeList?.find(et => et.id == state.workUnitInfo?.equipmentTypeId)?.name }}</td>
                                        </tr>
                                        <tr class="border-bottom--dashed">
                                            <th>{{ $t('entity.base.phone') }}:</th>
                                            <td>{{ state.workUnitInfo?.phone }}</td>
                                        </tr>
                                        <tr class="border-bottom--dashed">
                                            <th>{{ $t('entity.base.address') }}:</th>
                                            <td>{{ state.workUnitInfo?.address }}</td>
                                        </tr>
                                        <tr class="border-bottom--dashed">
                                            <th>{{ $t('entity.base.info') }}:</th>
                                            <td>{{ state.workUnitInfo?.info }}</td>
                                        </tr>
                                        <tr class="border-bottom--dashed">
                                            <th>{{ $t('entity.base.status') }}:</th>
                                            <td>
                                                <el-tag :type="(state.workUnitInfo?.status == 1 ? 'success' : 'danger')">{{ state.statusList?.find(wu => wu.code == state.workUnitInfo?.status)?.name }}
                                                </el-tag>
                                            </td>
                                        </tr>
                                        <tr class="border-bottom--dashed">
                                            <th style="width: 120px;">{{ $t('entity.base.remark') }}:</th>
                                            <td>{{ state.workUnitInfo?.remark }}</td>
                                        </tr>
                                    </table>
                                </div>
                                <div v-else>
                                    <el-empty :image-size="100" />
                                </div>
                            </div>
                        </div>
                        <div v-show="state.activeTab === 'volume'" class="chart-container">
                            <img src="../../../../assets/chart.png" alt="Volume" class="content-image" />
                        </div>
                        <div v-show="state.activeTab === 'speed'" class="chart-container">
                        </div>
                        <div v-show="state.activeTab === 'headway'" class="chart-container">
                        </div>
                        <div v-show="state.activeTab === 'gap'" class="chart-container">
                        </div>
                    </div>
                </div>
            </vue-draggable-resizable>
        </div>
    </Teleport>
</template>

<script setup lang="ts" name="equipmentModal">
import { reactive, ref, onMounted, onUnmounted } from 'vue'
import VueDraggableResizable from 'vue3-draggable-resizable' //pnpm install vue3-draggable-resizable
import 'vue3-draggable-resizable/dist/Vue3DraggableResizable.css'
import { Close } from '@element-plus/icons-vue'
import { ElDropdown, ElDropdownMenu, ElDropdownItem } from 'element-plus'
// Begin add by Khoa 
import { getAPI } from '/@/utils/axios-utils';

import { TmsWorkContactApi, TmsWorkUnitApi } from '/@/api-services/tms';
import { SysConfigDataApi } from '/@/api-services/cfgSystem';
// End add by Khoa
const BASE_Z_INDEX = 100 // Higher base z-index


const emits = defineEmits(['activated', 'closed', 'closeOthers', 'closeAll'])

const state = reactive({
    isShowDialog: false,
    isActive: false,
    activeTab: 'occupancy',
    position: {
        x: 100,
        y: 100
    },
    zIndex: BASE_Z_INDEX,
    data: null,
    isLoading: false,
	statusList: [],
	workUnitInfo: [],
	workUnitTypeList: []
})

const modalId = ref('')

const parentSize = reactive({
    width: 0,
    height: 0
})

// Update parent size on mount and window resize
const updateParentSize = () => {
    const container = document.querySelector('.visualizing-traffic-info')
    if (container) {
        parentSize.width = container.clientWidth
        parentSize.height = container.clientHeight
    }
}

// Begin add by Khoa 

    const loadData = async() => {
		let response = await getAPI(SysConfigDataApi).apiCfgsystemSysconfigdataDatalistCodeGet('status_type');
		state.statusList = response.data.result ? response.data.result : [{code: '0', name: 'Disable'}, {code: '1', name: 'Enable'}];

		response = await getAPI(SysConfigDataApi).apiCfgsystemSysconfigdataDatalistCodeGet('work_unit_type');
		state.workUnitTypeList = response.data.result;
	}

// End add by Khoa


onMounted(() => {
    updateParentSize();
    loadData();
    window.addEventListener('resize', updateParentSize)
})

onUnmounted(() => {
    window.removeEventListener('resize', updateParentSize)
})

const bringToFront = () => {
    const newZIndex = getHighestZIndex() + 1
    state.zIndex = Math.max(newZIndex, BASE_Z_INDEX)
    state.isActive = true
    emits('activated', modalId.value)
}

// Get highest z-index
const getHighestZIndex = () => {
    const elements = document.getElementsByClassName('drag-modal-wrapper')
    let highest = BASE_Z_INDEX
    for (const element of elements) {
        const zIndex = parseInt(window.getComputedStyle(element).zIndex)
        if (zIndex > highest) highest = zIndex
    }
    return highest
}

// Position and size handling
const onDragStop = (x: number, y: number) => {
    // Ensure position stays within bounds
    state.position.x = Math.max(0, Math.min(x, parentSize.width - 675))
    state.position.y = Math.max(100, Math.min(y, parentSize.height - 450))
}

const onResizeStop = () => {
    // Trigger chart resize if needed
}

// Dialog methods
const openDialog = (data: any) => {
    if (!state.isShowDialog) {
        state.isShowDialog = true
        // Calculate random position within bounds
        state.position = {
            x: Math.max(0, Math.min(Math.random() * (parentSize.width - 675), parentSize.width - 675)),
            y: Math.max(100, Math.min(Math.random() * (parentSize.height - 450), parentSize.height - 450))
        }
    }
    bringToFront()
    state.data = data

}

const setActive = (isActive: boolean) => {
    state.isActive = isActive
    if (!isActive) {
        state.zIndex = BASE_Z_INDEX
    }
}

// Set modal id
const setModalId = (id: string) => {
    modalId.value = id
}

const cancel = () => {
    state.isShowDialog = false
    emits('closed', modalId.value)
}

const handleCloseCommand = (command: string) => {
    switch (command) {
        case 'close':
            cancel()
            break
        case 'closeOthers':
            emits('closeOthers', modalId.value)
            break
        case 'closeAll':
            emits('closeAll')
            break
    }
}

defineExpose({ openDialog, setActive, setModalId, itemId: modalId,cancel })
</script>

<style scoped>
	/* Table */
	.table-data{
		width: 100%;
		max-height: 100%;
		max-width: 100%;
	}

	.table-data th,
	.table-data td{
		text-align: left;
		font-weight: normal;
		padding: 5px;
	}

	.table-data th{
		text-align: right;
	}

	.table-data .border-bottom--dashed td,
	.table-data .border-bottom--dashed th{
		border-bottom: thin dashed #E5E5E5;
	}

    /* Simple Popup */
	.simple-popup{
		position: absolute;
		top: 0px;
		left: 0px;
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 1080 !important;
		background-color: rgba(0, 0, 0, 0.5);
		width: 100%;
		height: 100%;
	}

	.simple-popup--container{
		display: flex;
		flex-direction: column;
		overflow: hidden;
		width: fit-content;
		height: 80%;
		min-width: 40%;
		min-height: 80%;
		max-width: 80%;
		max-height: 80%;
		background-color: white;
		border-radius: 5px;
	}

	.simple-popup--container .panel-header{
		height: 40px;
		max-height: 40px;
	}

	.simple-popup--container .panel-body{
		flex-grow: 1;
	}

    /* Button close */
	.button-close{
		position: absolute;
		top: 5px;
		right: 5px;
	}

	.button-close::before{
		display: block;
		position: absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		content: '\00d7';
		font-weight: lighter;
		font-size: 20px;
	}

	/* Position */
	.pos-relative{
		position: relative;
	}

	.pos-absolute{
		position: absolute
	}

	/* Style */
	.top-right{
		top: 0px;
		right: 0px;
		z-index: 1080 !important;
	}

	.flex-inline{
		display: flex;
		gap: 10px;
	}

	.text-uppercase{
		text-transform: uppercase;
	}

	.padding-5px{
		padding: 5px;
	}

	.padding-10px{
		padding: 10px;
	}

	.margin-5px{
		margin: 5px;
	}

	.overflow-auto{
		overflow: auto;
	}
</style>


<style scoped lang="scss">
$background-color: #1a1a1a;
$active-color: #10e610;
$hover-color: #07a107;
.drag-modal-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw; // Change to full viewport width
    height: 100vh; // Change to full viewport height
    pointer-events: none;
}

.floating-modal {
    background: $background-color;
    border: 1px solid #333;
    border-radius: 3px;
    transition: border-color 0.3s, box-shadow 0.3s;
    pointer-events: auto;
    display: flex !important;
    flex-direction: column !important;
    
    &.modal-active {
        border: 2px solid $active-color !important;
        box-shadow: 0 0 10px rgba(229, 255, 0, 0.2) !important;
    }

    .modal-header {
        position: relative;
        background: $background-color;
        flex: 0 0 auto;
        width: 100%;
        z-index: 2;
        color: #fff;
        .close-btn {
            position: absolute;
            color: #fff;
            right: 3px;
            // top: 10px;
            cursor: pointer;
            z-index: 2;
        }

        :deep(.el-tabs__item) {
            color: rgba(255, 255, 255, 0.8) !important;
            
            &.is-active {
                color: $active-color!important;
                font-weight: bold;
            }

            &:hover {
                color: $hover-color !important;
            }
        }

        :deep(.el-tabs__nav-wrap::after) {
            background-color: transparent;
        }

        :deep(.el-tabs__active-bar) {
            background-color: $active-color;
        }
    }

    .modal-content {
        flex: 1;
        position: relative;
        background: $background-color;
        overflow: hidden;
        
        .content-wrapper {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            overflow-y: auto;
            overflow-x: hidden;
            
            .chart-container {
                padding: 10px;
                width: 100%;
                
                .content-text {
                    width: 100%;
                    white-space: normal;
                    word-wrap: break-word;
                }

                .content-image {
                    width: 100%;
                    height: auto;
                    display: block;
                }
            }
        }
    }
}

:deep(.vdr-container) {
    display: flex !important;
    flex-direction: column !important;
}

:deep(.vdr-handle) {
    background-color: $active-color;
    
    &:hover {
        background-color: $hover-color;
    }
}

.close-actions {
    position: absolute;
    right: 10px;
    top: 10px;
    z-index: 2;

    .close-dropdown {
        .close-btn {
            cursor: pointer;
            padding: 4px;
            border-radius: 4px;
            transition: background-color 0.3s;
            
            &:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }
        }
    }
}

:deep(.el-dropdown-menu) {
    background: #2a2a2a;
    border: 1px solid #333;
    
    .el-dropdown-menu__item {
        color: #fff;
        
        &:hover {
            background-color: #333;
            color: $active-color;
        }
        
        &:not(:last-child) {
            border-bottom: 1px solid #333;
        }
    }
}

</style>