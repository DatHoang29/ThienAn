<!-- <template>
    <Teleport to="body">
        <div 
            v-if="state.isShowDialog" 
            class="drag-modal-wrapper"
            :style="{ zIndex: state.zIndex }"
            @mousedown.stop
        >
            <vue-draggable-resizable
                :initW="675"
                :initH="450"
                :minW="450"
                :minH="300"
                :x="state.position.x"
                :y="state.position.y"
                :draggable="true"
                :resizable="true"
                :parent="true"
                :parentLimitation="true"
                :parentW="parentSize.width"
                :parentH="parentSize.height"
                :minTop="100"
                :class="['floating-modal', { 'modal-active': state.isActive }]"
                @activated="bringToFront"
                @dragstop="onDragStop"
                @resizestop="onResizeStop"
                @mousedown.stop="bringToFront"
            >
                <div class="modal-content-wrapper">
                    <div v-if="state.type === 'toll'">
                        <TollModal ref="tollModalRef" 
                            @closed="cancel" 
                            @closeAll="handleCloseCommand('closeAll')"
                            @closeOthers="handleCloseCommand('closeOthers')"
                        />
                    </div>
                    <div v-if="state.type === 'wos'" style="height: 100%;">
                        <WosModal ref="wosModalRef" 
                            @closed="cancel"
                            @closeAll="handleCloseCommand('closeAll')"
                            @closeOthers="handleCloseCommand('closeOthers')"
                        />
                    </div>
                    <div v-if="state.type === 'unit'" style="height: 100%;">
                        <UnitModal ref="unitModalRef" 
                            @closed="cancel"
                            @closeAll="handleCloseCommand('closeAll')"
                            @closeOthers="handleCloseCommand('closeOthers')"
                        />
                    </div>
                </div>
            </vue-draggable-resizable>
        </div>
    </Teleport>
</template>

<script setup lang="ts" name="unitModal">
import {computed, reactive, ref, onMounted, onUnmounted, watch, nextTick} from 'vue'
import VueDraggableResizable from 'vue3-draggable-resizable' //pnpm install vue3-draggable-resizable
import 'vue3-draggable-resizable/dist/Vue3DraggableResizable.css'


//Import device info component
import TollModal from './unit/tollInfo.vue';
import WosModal from './unit/wosInfo.vue';
import UnitModal from './unit/index.vue';

import { TmsWorkContactApi, TmsWorkUnitApi } from '/@/api-services/tms';
import { getAPI } from '/@/utils/axios-utils';


const tollModalRef = ref<InstanceType<typeof TollModal>>();
const wosModalRef = ref<InstanceType<typeof WosModal>>();
const unitModalRef = ref<InstanceType<typeof UnitModal>>();

const BASE_Z_INDEX = 100 // Higher base z-index


const emits = defineEmits(['activated', 'closed', 'closeOthers', 'closeAll'])


const state = reactive({
    isShowDialog: false,
    isActive: false,
    activeTab: 'info',
    position: {
        x: 100,
        y: 100
    },
    zIndex: BASE_Z_INDEX,
    data: null as any,
    type: null as 'toll' | 'wos' | 'unit' | null,
    unitListData: [] as any ,
    workContactList: [] as any ,
    unit: null as any,
    editFeature: {
		equipmentTypeCode:'',
	},
})

const modalId = ref('')

const parentSize = reactive({
    width: 0,
    height: 0
})

// Update parent size on mount and window resize
const updateParentSize = () => {
    const container = document.querySelector('.visualizing-traffic-info')
    if (container) {
        parentSize.width = container.clientWidth
        parentSize.height = container.clientHeight
    }
}

onMounted( async () => {
    updateParentSize()
    window.addEventListener('resize', updateParentSize);
    
})

onUnmounted(() => {
    window.removeEventListener('resize', updateParentSize)

})


// Get highest z-index
const getHighestZIndex = () => {
    const elements = document.getElementsByClassName('drag-modal-wrapper')
    let highest = BASE_Z_INDEX
    for (const element of elements) {
        const zIndex = parseInt(window.getComputedStyle(element).zIndex)
        if (zIndex > highest) highest = zIndex
    }
    return highest
}
const bringToFront = () => {
        const newZIndex = getHighestZIndex() + 1
        state.zIndex = Math.max(newZIndex, BASE_Z_INDEX)
        state.isActive = true
        emits('activated', modalId.value)
    }
// Position and size handling
const onDragStop = (x: number, y: number) => {
    // Ensure position stays within bounds
    state.position.x = Math.max(0, Math.min(x, parentSize.width - 675))
    state.position.y = Math.max(100, Math.min(y, parentSize.height - 450))
}

const onResizeStop = () => {
    // Trigger chart resize if needed
}
	
// Dialog methods
const openDialog = async (data: any) => {
    if (!state.isShowDialog) {
        state.isShowDialog = true
        // Calculate random position within bounds
        state.position = {
            x: Math.max(0, Math.min(Math.random() * (parentSize.width - 675), parentSize.width - 675)),
            y: Math.max(100, Math.min(Math.random() * (parentSize.height - 450), parentSize.height - 450))
        }

        await loadModalInfo(data)
    }
    bringToFront()
    state.data = data
}


const loadModalInfo = async (data: any) => {
    let response = await getAPI(TmsWorkUnitApi).apiTmsTmsworkunitListGet();
    state.unitListData = response?.data?.result ?? null;
    state.unit = state.unitListData?.find((item: any) => item.id == data.itemId) ?? null;
    console.log(state.unit)
    //TODO enum
    switch(state.unit?.type){
        case 'toll':
            state.type = 'toll';
            await nextTick();
            tollModalRef.value?.openInfo(state.unit);
            break;
        case 'wos':
            state.type = 'wos';
            await nextTick();
            wosModalRef.value?.openInfo(state.unit);
            break;
        default:
            state.type = 'unit';
            await nextTick();
            unitModalRef.value?.openInfo(state.unit);
            break;


    }
}




const setActive = (isActive: boolean) => {
    state.isActive = isActive
    if (!isActive) {
        state.zIndex = BASE_Z_INDEX
    }
}

// Set modal id
const setModalId = (id: string) => {
    modalId.value = id
}

const cancel = () => {
    state.isShowDialog = false
    emits('closed', modalId.value)
}

const handleCloseCommand = (command: string) => {
    switch (command) {
        case 'close':
            cancel()
            break
        case 'closeOthers':
            emits('closeOthers', modalId.value)
            break
        case 'closeAll':
            emits('closeAll')
            break
    }
}

defineExpose({ openDialog, setActive, setModalId, itemId: modalId,cancel })
</script>

<style lang="scss">
.custom-label-color .el-form-item__label{
    color: #fff !important;
}
</style>
////- End - Add By KhoaND
<style  lang="scss">
$background-color: #1a1a1a;
$active-color: #10e610;
$hover-color: #07a107;
.drag-modal-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw; // Change to full viewport width
    height: 100vh; // Change to full viewport height
    pointer-events: none;
}

.floating-modal {
    background: $background-color;
    border: 1px solid #333;
    border-radius: 3px;
    transition: border-color 0.3s, box-shadow 0.3s;
    pointer-events: auto;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    
    &.modal-active {
        border: 2px solid $active-color !important;
        box-shadow: 0 0 10px rgba(229, 255, 0, 0.2) !important;
    }
}

.modal-inner-container {
    height: 100%;
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.modal-content-wrapper {
    height: 100%;
    width: 100%;
    overflow: hidden;
}

:deep(.vdr-container) {
    height: 100% !important;
}

:deep(.vdr-content) {
    height: 100% !important;
}

:deep(.vdr-handle) {
    background-color: $active-color;
    
    &:hover {
        background-color: $hover-color;
    }
}

.close-actions {
    position: absolute;
    right: 10px;
    top: 10px;
    z-index: 2;
    color: #fff!important;
    .close-dropdown {
        .close-btn {
            cursor: pointer;
            padding: 4px;
            border-radius: 4px;
            transition: background-color 0.3s;
            color: #fff!important;
            &:hover {
                background-color: rgba(255, 255, 255, 0.1);
            }
        }
    }
}


//========
/* Table */

.preview {
  border: 1px solid #ccc;
  overflow: hidden;
}
.design-container, .preview-content {
  border: 1px solid #ccc;
  margin: 0 auto;
  overflow: hidden;
}
.text-content {
  padding: 10px;
}

:deep(.el-form-item__content) {
  justify-content: flex-start;
}

/* Image simple select */
.simple-img_select{
  max-height: 50vh;
  overflow-y: auto;
  padding: 5px; 
}

.simple-img_preview,
.simple-img_select li {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px !important; /* Important!!! */
  height: auto !important; /* Important!!! */
  max-height: 70px;
}

.simple-img_select li{
  border-bottom: thin dashed #E5E5E5;
}

.simple-img_preview {
  border: thin solid #E5E5E5;
  border-radius: 5px;
}

.simple-img_preview img,
.simple-img_select li img{
  max-height: 50px !important; /* Important!!! */
  max-width: 100% !important; /* Important!!! */
}
/* Template library */
.template-designer {
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.element-group {
  margin-bottom: 20px;
}

.element-content {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.element-position-size {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 10px;
}

.input-group {
  display: flex;
  align-items: center;
}

.input-label {
  margin-right: 5px;
  font-weight: bold;
}

.design-area, .preview {
  width: 100%;
}

.design-container, .preview-content {
  border: 1px solid #ccc;
  margin: 0 auto;
  overflow: hidden;
}

.element {
  position: absolute;
  box-sizing: border-box;
}

.element:hover {
  border-color: #3a8ee6;
}

.element-content {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.element-label {
  position: absolute;
  top: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.5);
  color: white;
  font-size: 12px;
  padding: 2px 4px;
}

.element-info {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: rgba(0, 0, 0, 0.5);
  color: white;
  font-size: 12px;
  padding: 2px 4px;
  text-align: center;
}

.element-actions {
  position: absolute;
  top: 0;
  right: 0;
  display: flex;
  gap: 4px;
}

.element-actions button {
  background-color: white;
  border: 1px solid #3a8ee6;
  color: #3a8ee6;
  cursor: pointer;
  padding: 2px;
  font-size: 12px;
}

.element-actions button.active {
  background-color: #3a8ee6;
  color: white;
}

.element-control {
  margin-bottom: 20px;
}

.element-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.add-remove-controls {
  margin-top: 20px;
}

.image-uploader {
  width: 100%;
}

.uploaded-image-preview {
  display: flex;
  align-items: center;
  margin-top: 10px;
  padding: 10px;
  background-color: #f0f0f0;
  border-radius: 4px;
}

.uploaded-image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  margin-right: 10px;
  border-radius: 4px;
}

.import-export {
  margin-top: 20px;
}

.import-upload {
  display: inline-block;
  margin-left: 10px;
}

</style> -->
