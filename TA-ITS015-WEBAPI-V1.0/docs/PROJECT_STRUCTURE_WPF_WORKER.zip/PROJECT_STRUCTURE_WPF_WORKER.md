# Cấu trúc .NET gọn nhẹ cho WPF và Worker Service

## 1. Mục tiêu

Tài liệu này đề xuất cấu trúc **bốn project** cho hệ thống chỉ có hai chương trình chạy chính:

- **WPF**: giao diện vận hành, cấu hình, tra cứu và gửi lệnh.
- **Worker Service**: chạy nền liên tục, kết nối thiết bị, xử lý dữ liệu, database, NATS, Socket và tác vụ định kỳ.

Mục tiêu là giữ solution gọn, tên thư mục dễ nhớ và dễ custom, nhưng vẫn tách được:

1. **Phần gọi chung** từ WPF/Worker (`Contracts`).
2. **Nền tảng**: entity, model, enum, constant (`Shared/Core`).
3. **Xử lý nghiệp vụ** (`Shared/Application`).
4. **Hạ tầng kỹ thuật**: DB, log, NATS, Socket, SDK thiết bị (`Shared/Infrastructure`).

Không đưa Web API, module web hoặc kiến trúc nhiều package vào cấu trúc mặc định.

**Target framework khuyến nghị**

- `Product.Contracts`, `Product.Shared`, `Product.Worker`: `net10.0`.
- `Product.Wpf`: `net10.0-windows` với `<UseWPF>true</UseWPF>`.

## 2. Cấu trúc solution chốt

Thay `Product` bằng tên thực tế, ví dụ `DeviceMonitor`, `VmsControl` hoặc `TrafficCollector`.

```text
Product.sln
│  Directory.Build.props
│  Directory.Packages.props
├─docs/
│  PROJECT_STRUCTURE_WPF_WORKER.md
├─src/
│  ├─Product.Contracts/       # Ranh giới gọi chung cho WPF và Worker
│  ├─Product.Shared/          # Core + Application + Infrastructure
│  ├─Product.Wpf/             # WPF executable
│  └─Product.Worker/          # Worker executable
└─tests/                       # Tạo khi bắt đầu có logic quan trọng
   └─Product.Shared.Tests/
```

| Project | Vai trò |
|---|---|
| `Product.Contracts` | Chứa request, response, event, `I...Service`, result và enum công khai. Đây là phần WPF/Worker gọi vào. |
| `Product.Shared` | Chứa toàn bộ implementation chung, chia bằng thư mục `Core`, `Application`, `Infrastructure`. |
| `Product.Wpf` | UI WPF: View, ViewModel, dialog, navigation, resource và UI dispatcher. |
| `Product.Worker` | Background Service: polling, subscribe message, job định kỳ và health. |

Cấu trúc này chủ động **không tách** `Core`, `Application`, `Infrastructure` thành ba project riêng. Chúng nằm trong một DLL `Product.Shared` để giảm project reference, nhưng vẫn được phân ranh rõ bằng folder, namespace và access modifier.

## 3. Dependency giữa các project

```text
Product.Contracts
        ▲
        │
Product.Shared
        ▲
        │
 ┌──────┴──────┐
 │             │
Product.Wpf  Product.Worker
```

| Project | Được tham chiếu |
|---|---|
| `Product.Contracts` | Không tham chiếu project nội bộ nào. |
| `Product.Shared` | `Product.Contracts`. |
| `Product.Wpf` | `Product.Contracts`, `Product.Shared`. |
| `Product.Worker` | `Product.Contracts`, `Product.Shared`. |

Quy tắc bắt buộc:

1. `Product.Contracts` **không được tham chiếu** `Product.Shared`; nếu không sẽ tạo circular dependency.
2. `Product.Contracts` không chứa entity database, SqlSugar, NATS, Socket, logging, SDK thiết bị hoặc WPF type.
3. `Product.Shared` tham chiếu `Contracts` để hiện thực các `I...Service` công khai.
4. WPF/Worker chỉ gọi interface trong `Contracts`; không gọi trực tiếp repository, NATS client, socket client hoặc class implementation trong `Shared`.
5. Chỉ file khởi động (`App.xaml.cs`, `Program.cs`) được gọi method đăng ký DI từ `Shared`.

## 4. `Product.Contracts` — cổng gọi chung

`Contracts` là ranh giới công khai giữa WPF/Worker và phần implementation. Project này phải nhỏ, ổn định và không phụ thuộc hạ tầng.

```text
Product.Contracts/
├─Requests/
│  ├─Device/
│  ├─Alarm/
│  └─Sync/
├─Responses/
│  ├─Device/
│  ├─Alarm/
│  └─Sync/
├─Events/
│  ├─DeviceStatusChanged.cs
│  └─DeviceAlarmRaised.cs
├─Services/
│  ├─IDeviceCommandService.cs
│  ├─IDeviceQueryService.cs
│  ├─IAlarmService.cs
│  └─ISyncService.cs
├─Results/
│  ├─ServiceResult.cs
│  └─ServiceResultOfT.cs
└─Enums/                         # Chỉ enum dùng trực tiếp ở WPF/Worker
```

### Chứa gì?

- Request từ WPF/Worker: `DeviceCommandRequest`, `SyncRequest`.
- Response trả về cho WPF/Worker: `DeviceStatusResponse`, `AlarmResponse`.
- Event/message DTO: `DeviceStatusChanged`, `DeviceAlarmRaised`.
- Interface service: `IDeviceCommandService`, `IDeviceQueryService`, `ISyncService`.
- `ServiceResult`/`ServiceResult<T>` để host nhận kết quả và lỗi thống nhất.
- Enum là một phần của contract công khai, ví dụ `DeviceState` nếu WPF cần binding trực tiếp.

### Không chứa gì?

- `Device` entity SqlSugar hoặc mapping bảng.
- `IRepository`, `IDeviceClient`, `IEventBus` nội bộ.
- NATS/Socket payload vendor-specific, connection string, logging, file system hoặc UI model.
- Business rule hoặc implementation service.

Ví dụ service mà WPF và Worker cùng gọi:

```csharp
public interface IDeviceCommandService
{
    Task<ServiceResult<DeviceCommandResponse>> SendAsync(
        DeviceCommandRequest request,
        CancellationToken cancellationToken = default);
}
```

`Contracts` không dùng `Result<T>` từ `Shared/Core`, vì điều đó sẽ làm `Contracts` phải tham chiếu ngược vào `Shared`. `ServiceResult<T>` nằm trong `Contracts` để dependency luôn một chiều.

## 5. `Product.Shared` — implementation dùng chung

`Product.Shared` chỉ có một project nhưng được chia thành ba phần rõ ràng:

```text
Product.Shared/
├─Core/
│  ├─Entities/
│  ├─Models/
│  ├─Enums/
│  ├─Constants/
│  └─Common/
├─Application/
│  ├─Logic/
│  ├─Handlers/
│  ├─Interfaces/
│  │  ├─Database/
│  │  ├─Devices/
│  │  ├─Messaging/
│  │  ├─Files/
│  │  └─Time/
│  ├─Validation/
│  └─Mapping/
├─Infrastructure/
│  ├─Config/
│  │  ├─Options/
│  │  └─Validation/
│  ├─Database/
│  │  ├─SqlSugar/
│  │  ├─Repositories/
│  │  ├─Mappings/
│  │  └─Migrations/
│  ├─Logging/
│  ├─Messaging/
│  │  ├─Nats/
│  │  ├─Socket/
│  │  └─Serialization/
│  ├─Devices/
│  │  ├─ProtocolA/
│  │  ├─ProtocolB/
│  │  └─Common/
│  └─External/
│     ├─Http/
│     └─Files/
└─DependencyInjection/
   └─ServiceCollectionExtensions.cs
```

### 5.1. `Shared/Core` — nền tảng

| Thư mục | Chứa gì |
|---|---|
| `Entities` | Entity nghiệp vụ/persistence như `Device`, `DeviceAlarm`, `DeviceHistory`. |
| `Models` | Value object, model nội bộ, trạng thái kết nối hoặc dữ liệu đã chuẩn hóa. |
| `Enums` | Enum nội bộ không cần expose cho WPF/Worker. |
| `Constants` | Constant dùng nội bộ; không chứa connection string, topic/channel thay đổi theo môi trường. |
| `Common` | Base entity và helper thuần C# không phụ thuộc UI/database/network. |

`Core` không biết WPF, Worker, SqlSugar, NATS, Socket hay SDK thiết bị.

### 5.2. `Shared/Application` — xử lý logic

| Thư mục | Chứa gì |
|---|---|
| `Logic` | Hiện thực các interface trong `Contracts/Services`, điều phối workflow và business rule. |
| `Handlers` | Xử lý event/message: cập nhật trạng thái, ghi lịch sử, phát cảnh báo. |
| `Interfaces/Database` | `IDeviceRepository`, `IAlarmRepository`, transaction abstraction. |
| `Interfaces/Devices` | `IDeviceClient`, `IDeviceSession`, abstraction giao thức thiết bị. |
| `Interfaces/Messaging` | `IEventBus`, `IRealtimeClient`, abstraction publish/subscribe. |
| `Interfaces/Files`, `Time` | File storage, clock hoặc dependency kỹ thuật khác mà logic cần. |
| `Validation` | Validation input và rule nghiệp vụ. |
| `Mapping` | Chuyển đổi giữa Contract DTO, Core entity/model và dữ liệu tích hợp. |

`Application` được phép gọi `Core` và `Contracts`, nhưng chỉ gọi database/NATS/Socket/thiết bị thông qua interface ở `Application/Interfaces`.

Ví dụ implementation nội bộ:

```csharp
internal sealed class DeviceCommandService : IDeviceCommandService
{
    // Inject IDeviceRepository, IDeviceClient, IEventBus.
    // Đây là nơi xử lý workflow, không phải ViewModel hoặc BackgroundService.
}
```

### 5.3. `Shared/Infrastructure` — hạ tầng kỹ thuật

| Thư mục | Chứa gì |
|---|---|
| `Config` | Options, binding `appsettings`, validate endpoint, timeout, topic/channel. |
| `Database` | SqlSugar scope/client, repository implementation, transaction, mapping bảng, migration. |
| `Logging` | NLog/Serilog adapter và enrich `DeviceId`, `MessageId`, correlation id. |
| `Messaging/Nats` | Connect, publish, subscribe, reconnect; implementation `IEventBus`. |
| `Messaging/Socket` | SocketCluster/WebSocket client và real-time reconnect. |
| `Devices` | SDK vendor, TCP/UDP/serial protocol; implementation `IDeviceClient`. |
| `External` | HTTP client, file, certificate hoặc tích hợp ngoài không thuộc thiết bị/message/DB. |

`Infrastructure` hiện thực interface của `Application`. Các class kỹ thuật nên để `internal` khi WPF/Worker không cần gọi trực tiếp.

### 5.4. `Shared/DependencyInjection` — điểm đăng ký duy nhất

Expose một extension method công khai để hai host dùng chung:

```csharp
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddProductShared(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Register Application services.
        // Register SqlSugar, logging, NATS, Socket and device clients.
        return services;
    }
}
```

Implementation cụ thể nằm trong `Shared`; WPF và Worker chỉ cần gọi `AddProductShared(configuration)` khi khởi động.

## 6. `Product.Wpf` — giao diện desktop

```text
Product.Wpf/
├─App.xaml
├─App.xaml.cs
├─appsettings.json
├─Views/
│  ├─Device/
│  ├─Alarm/
│  └─Settings/
├─ViewModels/
│  ├─Device/
│  ├─Alarm/
│  └─Settings/
├─Presentation/
│  ├─Dialogs/
│  ├─Navigation/
│  ├─Notifications/
│  └─Dispatcher/
├─Resources/
└─DependencyInjection/
```

- `ViewModel` chỉ inject `I...Service` từ `Product.Contracts.Services`.
- Không inject `SqlSugarDeviceRepository`, `NatsEventBus`, `SocketRealtimeClient` hoặc SDK thiết bị vào ViewModel.
- `Presentation` là nơi đặt dialog, navigation, notification, converter và UI dispatcher — các phần chỉ WPF mới có.
- `App.xaml.cs` build Generic Host, gọi `AddProductShared(configuration)`, đăng ký WPF service rồi mở `MainWindow`.
- Sự kiện real-time phải marshal về UI dispatcher trước khi cập nhật ViewModel.

## 7. `Product.Worker` — tiến trình chạy nền

```text
Product.Worker/
├─Program.cs
├─appsettings.json
├─appsettings.Development.json
├─Workers/
│  ├─DevicePollingWorker.cs
│  ├─MessageSubscriptionWorker.cs
│  └─SyncWorker.cs
├─Jobs/
├─Health/
└─DependencyInjection/
```

- `BackgroundService` chỉ quản lý vòng lặp, cancellation, lịch chạy hoặc subscription.
- Worker inject các `I...Service` trong `Product.Contracts.Services`; không query SqlSugar hoặc parse protocol phức tạp trực tiếp trong worker.
- Worker có thể cài Windows Service; WPF đóng không ảnh hưởng đến kết nối thiết bị hoặc job nền.
- Mọi loop phải nhận `CancellationToken`; connection DB/NATS/Socket/thiết bị phải được dispose khi host dừng.

## 8. Luồng gọi chuẩn

### 8.1. WPF gửi lệnh

```text
View
  → ViewModel
  → Product.Contracts.Services (IDeviceCommandService)
  → Product.Shared.Application.Logic (DeviceCommandService)
  → Product.Shared.Application.Interfaces
  → Product.Shared.Infrastructure (Database / NATS / Socket / Device SDK)
  → ServiceResult<Response> trả về ViewModel
```

### 8.2. Worker chạy nền

```text
BackgroundService
  → Product.Contracts.Services (ISyncService hoặc IDeviceCommandService)
  → Product.Shared.Application.Logic
  → Product.Shared.Infrastructure
```

Ví dụ `DevicePollingWorker` chỉ quyết định **khi nào** poll. `DevicePollingService` trong `Shared/Application/Logic` quyết định **poll cái gì**, validate dữ liệu thế nào, lưu DB ra sao và có publish event hay không.

### 8.3. NATS/Socket nhận message

```text
NATS / Socket message
  → Shared/Infrastructure/Messaging nhận và deserialize
  → Shared/Application/Handlers xử lý nghiệp vụ
  → Database / publish event / cập nhật trạng thái
  → WPF nhận notification qua service real-time nếu cần
```

Event/message DTO dùng chung đặt trong `Contracts/Events`; cách kết nối, reconnect và serialize thuộc `Shared/Infrastructure/Messaging`.

## 9. Khởi tạo host và DI

WPF và Worker đều dùng Generic Host; mỗi host có `appsettings.json` riêng để dùng connection string, NATS endpoint hoặc feature flag phù hợp môi trường của mình.

### WPF

```csharp
services
    .AddProductShared(configuration)
    .AddWpfPresentation();
```

### Worker

```csharp
services
    .AddProductShared(configuration)
    .AddHostedService<DevicePollingWorker>()
    .AddHostedService<MessageSubscriptionWorker>();
```

Không tự `new` repository, NATS connection, socket client hoặc service implementation trong ViewModel/Worker. DI quản lý lifetime và dừng kết nối đúng cách khi host shutdown.

## 10. Custom mà không làm cấu trúc phình to

### Thêm chức năng mới

Ví dụ thêm `Alarm`, tạo folder tương ứng trong các phần cần thiết:

```text
Product.Contracts/Requests/Alarm/
Product.Contracts/Responses/Alarm/
Product.Contracts/Services/IAlarmService.cs
Product.Contracts/Events/AlarmRaised.cs

Product.Shared/Core/Entities/Alarm.cs
Product.Shared/Application/Logic/Alarm/
Product.Shared/Application/Interfaces/Database/IAlarmRepository.cs
Product.Shared/Infrastructure/Database/Repositories/AlarmRepository.cs

Product.Wpf/Views/Alarm/
Product.Wpf/ViewModels/Alarm/
Product.Worker/Workers/AlarmSyncWorker.cs       # Chỉ khi cần chạy nền
```

Không tách `Product.Alarm.*` chỉ vì thêm một chức năng.

### Thêm hạ tầng hoặc protocol

- Database mới: thêm implementation ở `Shared/Infrastructure/Database`; interface Application không đổi.
- NATS/Socket/MQTT: thêm adapter ở `Shared/Infrastructure/Messaging`; event chung vẫn ở `Contracts/Events`.
- Protocol/SDK thiết bị mới: thêm `Shared/Infrastructure/Devices/ProtocolX`; hiện thực `IDeviceClient` mới được chọn qua configuration/DI.

### Khi nào nên tách thêm project?

Chỉ tách `Infrastructure` hoặc adapter thành project riêng nếu có ít nhất một lý do:

- SDK vendor/driver có dependency nặng, native DLL, COM hoặc xung đột phiên bản.
- Muốn chạy hoặc phát hành adapter độc lập.
- Một phần được dùng lại ở solution khác và đã ổn định.
- `Product.Shared` đã đủ lớn khiến folder không còn giúp tìm code hiệu quả.

Nếu chưa có các lý do trên, giữ bốn project này.

## 11. Quy ước để giữ ranh giới khi chung một DLL

Vì `Core`, `Application`, `Infrastructure` cùng nằm trong `Product.Shared`, cần giữ các quy ước sau:

- Namespace theo đúng folder: `Product.Shared.Core`, `Product.Shared.Application`, `Product.Shared.Infrastructure`.
- Class Infrastructure và Logic implementation dùng `internal` khi không cần host gọi trực tiếp.
- Chỉ interface/DTO/event/result trong `Product.Contracts` là public boundary cho WPF/Worker.
- Không dùng thư mục `Misc`, `Helper`, `Utils` làm nơi chứa mọi thứ. Helper thuần C# đặt `Shared/Core/Common`; helper DB/NATS/UI đặt trong phần kỹ thuật tương ứng.
- Không dùng chung entity DB, request/response WPF và payload NATS nếu mục đích của chúng khác nhau.
- Dùng cùng tên chức năng ở mọi nơi: `Device`, `Alarm`, `Sync`, `Monitoring`; không đổi tên khái niệm tùy project.

## 12. Quy tắc vận hành Worker

- Mọi `BackgroundService` nhận `CancellationToken`; shutdown phải dừng poll, subscription và dispose connection.
- Retry chỉ dành cho lỗi transient, có backoff và giới hạn retry; không nuốt exception.
- Job/message phải idempotent để chạy lại không ghi trùng dữ liệu.
- Không để WPF giữ kết nối thiết bị lâu dài; WPF đóng thì Worker vẫn tiếp tục vận hành.
- Log nên có `DeviceId`, `MessageId` hoặc correlation id; không log secret/connection string.
- Connection NATS/Socket/thiết bị có timeout, reconnect policy và health state rõ ràng.

## 13. Tham chiếu từ các dự án đã khảo sát

- ACS010 cho thấy giá trị của việc tách config, controller/logic, database, logging, SocketCluster, Windows Service và desktop UI. Cấu trúc mới giữ các ranh giới đó trong `Contracts`, `Shared`, `Wpf`, `Worker` với tên dễ tìm hơn.
- TAC WebAPI cung cấp cách đăng ký DI bằng extension method. Mô hình mới chỉ kế thừa `AddProductShared(...)`, không mang module/API/web vào solution.

## 14. Checklist bắt đầu dự án

1. Tạo bốn project theo mục 2 và reference theo mục 3.
2. Tạo `Contracts` trước: request, response, `I...Service`, event và `ServiceResult<T>`.
3. Tạo `Shared/Core` cho entity/model/enums; không để Contracts phụ thuộc Shared.
4. Hiện thực service tại `Shared/Application/Logic`, interface DB/device/message tại `Shared/Application/Interfaces`.
5. Hiện thực SqlSugar, logging, NATS, Socket và SDK thiết bị tại `Shared/Infrastructure`.
6. Tạo `AddProductShared(configuration)` tại `Shared/DependencyInjection`.
7. WPF/Worker chỉ gọi Contracts; UI và vòng lặp nền không chứa business rule.
8. Chỉ tách thêm project khi có lý do kỹ thuật rõ ràng.

## 15. Kết luận

Bốn project `Contracts`, `Shared`, `Wpf`, `Worker` là cấu trúc gọn nhẹ phù hợp cho desktop vận hành và service nền. `Contracts` tạo ranh giới gọi chung rõ ràng; `Shared` giữ entity/model, logic và hạ tầng bằng folder; WPF và Worker chạy độc lập nhưng dùng cùng service contract và implementation. Cấu trúc này đủ linh hoạt để thay DB, logging, NATS, Socket hoặc protocol thiết bị mà chưa cần tách nhiều project ngay từ đầu.
